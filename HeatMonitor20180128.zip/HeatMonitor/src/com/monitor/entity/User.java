package com.monitor.entity;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "user", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = { "username" }) })
public class User implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 3650041511569569773L;
	private Integer id;
	private String username;
	private String password;
	private String role;
	private Date onlinedate;
	private Integer isonline;
	private Integer isactive;


	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	/*
	 * private String company_add_position ; private String company_name;
	 * private String companyid;
	 */
	// 主键 ：@Id 主键生成方式：strategy = "increment"
	// 映射表中id这个字段，不能为空，并且是唯一的
	@GenericGenerator(name = "generator", strategy = "increment")
	@GeneratedValue(generator = "generator")
	@Column(name = "userid", unique = true, nullable = false)
	@Id
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}
	
	// 映射username字段，长度为20
	@Column(name = "username", length = 50)
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	@Column(name = "password", length = 50)
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "online_date")
	public Date getOnlinedate() {
		return onlinedate;
	}

	public void setOnlinedate(Date onlinedate) {
		this.onlinedate = onlinedate;
	}

	@Column(name = "role")
	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	@Column(name = "isonline", length = 1)
	public Integer getIsonline() {
		return isonline;
	}
	public void setIsonline(Integer isonline) {
		this.isonline = isonline;
	}
	@Column(name = "isactive", length = 1)
	public Integer getIsactive() {
		return isactive;
	}

	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}


	@Override
	public String toString() {
		return "User [id=" + id + ", username=" + username + ", password="
				+ password + ", role=" + role + ", onlinedate=" + onlinedate
				+ ", isonline=" + isonline + ", isactive=" + isactive + "]";
	}

	public User() {
		super();
	}

	public User(Integer id) {
		// TODO Auto-generated constructor stub
		super();
		this.id = id;
	}

	public User(Integer id, String username, String password, String role,
			Date onlinedate, Integer isonline, Integer isactive) {
		super();
		this.id = id;
		this.username = username;
		this.password = password;
		this.role = role;
		this.onlinedate = onlinedate;
		this.isonline = isonline;
		this.isactive = isactive;
	}
	
}
