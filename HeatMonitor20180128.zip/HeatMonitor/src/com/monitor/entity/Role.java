package com.monitor.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "s_role", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = {"name" }) })

public class Role {
	private Integer id;
	private String name;
	private String des;
	private Integer active;
	@GenericGenerator(name = "generator", strategy = "increment")
	@GeneratedValue(generator = "generator")
	@Column(name = "id", unique = true, nullable = false)
	@Id
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(name = "name", length = 50)
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Column(name = "des", length = 500)
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	@Column(name = "active")
	public Integer getActive() {
		return active;
	}
	public void setActive(Integer active) {
		this.active = active;
	}
	@Override
	public String toString() {
		return "Role [id=" + id + ", name=" + name + ", des=" + des
				+ ", active=" + active + "]";
	}
	public Role(Integer id, String name, String des, Integer active) {
		super();
		this.id = id;
		this.name = name;
		this.des = des;
		this.active = active;
	}
	public Role(Integer id, String name) {
		super();
		this.id = id;
		this.name = name;
	}
	public Role(Integer id) {
		super();
		this.id = id;
	}
	public Role(String name) {
		super();
		this.name = name;
	}
	public Role(String name, String des) {
		super();
		this.name = name;
		this.des = des;
	}
	public Role() {
		super();
	}
	
	
}
