package com.monitor.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "datainfo", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
public class Datainfo {
			private Integer id;
			private String equipmentid;
			private String status1;
			private String status2;
			private String status3;
			private String status4;
			private String status5;
			private String status6;
			private String status7;
			private String status8;
			private String status9;
			private String status10;
			private Double status11;
			private Double status12;
			private Double status13;
			private Double status14;
			private Double status15;
			private Double status16;
			private Double status17;
			private Double status18;
			private Double status19;
			private Double status20;
			private Date data_date;
			private Integer status;
			@GenericGenerator(name = "generator", strategy = "increment")
			@GeneratedValue(generator = "generator")
			@Column(name = "id", unique = true, nullable = false)
			@Id
			public Integer getId() {
				return id;
			}
			public void setId(Integer id) {
				this.id = id;
			}
			@Column(name = "equipmentid", length = 100)
			public String getEquipmentid() {
				return equipmentid;
			}
			public void setEquipmentid(String equipmentid) {
				this.equipmentid = equipmentid;
			}
			@Column(name = "status1", length = 50)
			public String getStatus1() {
				return status1;
			}
			public void setStatus1(String status1) {
				this.status1 = status1;
			}
			@Column(name = "status2", length = 50)
			public String getStatus2() {
				return status2;
			}
			public void setStatus2(String status2) {
				this.status2 = status2;
			}
			@Column(name = "status3", length = 50)
			public String getStatus3() {
				return status3;
			}
			public void setStatus3(String status3) {
				this.status3 = status3;
			}
			@Column(name = "status4", length = 50)
			public String getStatus4() {
				return status4;
			}
			public void setStatus4(String status4) {
				this.status4 = status4;
			}
			@Column(name = "status5", length = 50)
			public String getStatus5() {
				return status5;
			}
			public void setStatus5(String status5) {
				this.status5 = status5;
			}
			@Column(name = "status6", length = 50)
			public String getStatus6() {
				return status6;
			}
			public void setStatus6(String status6) {
				this.status6 = status6;
			}
			@Column(name = "status7", length = 50)
			public String getStatus7() {
				return status7;
			}
			public void setStatus7(String status7) {
				this.status7 = status7;
			}
			@Column(name = "status8", length = 50)
			public String getStatus8() {
				return status8;
			}
			public void setStatus8(String status8) {
				this.status8 = status8;
			}
			@Column(name = "status9", length = 50)
			public String getStatus9() {
				return status9;
			}
			public void setStatus9(String status9) {
				this.status9 = status9;
			}
			@Column(name = "status10", length = 50)
			public String getStatus10() {
				return status10;
			}
			public void setStatus10(String status10) {
				this.status10 = status10;
			}
			@Column(name = "status11", length = 50)
			public Double getStatus11() {
				return status11;
			}
			public void setStatus11(Double status11) {
				this.status11 = status11;
			}
			@Column(name = "status12", length = 50)
			public Double getStatus12() {
				return status12;
			}
			public void setStatus12(Double status12) {
				this.status12 = status12;
			}
			@Column(name = "status13", length = 50)
			public Double getStatus13() {
				return status13;
			}
			public void setStatus13(Double status13) {
				this.status13 = status13;
			}
			@Column(name = "status14", length = 50)
			public Double getStatus14() {
				return status14;
			}
			public void setStatus14(Double status14) {
				this.status14 = status14;
			}
			@Column(name = "status15", length = 50)
			public Double getStatus15() {
				return status15;
			}
			public void setStatus15(Double status15) {
				this.status15 = status15;
			}
			@Column(name = "status16", length = 50)
			public Double getStatus16() {
				return status16;
			}
			public void setStatus16(Double status16) {
				this.status16 = status16;
			}
			@Column(name = "status17", length = 50)
			public Double getStatus17() {
				return status17;
			}
			public void setStatus17(Double status17) {
				this.status17 = status17;
			}
			@Column(name = "status18", length = 50)
			public Double getStatus18() {
				return status18;
			}
			public void setStatus18(Double status18) {
				this.status18 = status18;
			}
			@Column(name = "status19", length = 50)
			public Double getStatus19() {
				return status19;
			}
			public void setStatus19(Double status19) {
				this.status19 = status19;
			}
			@Column(name = "status20", length = 50)
			public Double getStatus20() {
				return status20;
			}
			public void setStatus20(Double status20) {
				this.status20 = status20;
			}
			
			@Column(name = "data_date", updatable=false)
			public Date getData_date() {
				return data_date;
			}
			public void setData_date(Date data_date) {
				this.data_date = data_date;
			}

			@Column(name="STATUS",updatable=false)
			public Integer getStatus() {
				return status;
			}
			public void setStatus(Integer status) {
				this.status = status;
			}
			@Override
			public String toString() {
				return "Datainfo [id=" + id + ", equipmentid=" + equipmentid
						+ ", status1="
						+ status1 + ", status2=" + status2 + ", status3="
						+ status3 + ", status4=" + status4 + ", status5="
						+ status5 + ", status6=" + status6 + ", status7="
						+ status7 + ", status8=" + status8 + ", status9="
						+ status9 + ", status10=" + status10 + ", status11="
						+ status11 + ", status12=" + status12 + ", status13="
						+ status13 + ", status14=" + status14 + ", status15="
						+ status15 + ", status16=" + status16 + ", status17="
						+ status17 + ", status18=" + status18 + ", status19="
						+ status19 + ", status20=" + status20 + ", data_date="
						+ data_date + ", status=" + status + "]";
			}
			public Datainfo() {
				super();
			}
			public Datainfo(Integer id) {
				super();
				this.id = id;
			}
						
		}

