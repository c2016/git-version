package com.monitor.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "area", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
public class Area {
	private Integer areaid;
	private String areaname;
	private Integer pid;
	@GenericGenerator(name = "generator", strategy = "assigned")
	@GeneratedValue(generator = "generator")
	@Column(name = "id", unique = true, nullable = false)
	@Id
	public Integer getAreaid() {
		return areaid;
	}
	public void setAreaid(Integer areaid) {
		this.areaid = areaid;
	}
	@Column(name = "name", length = 50)
	public String getAreaname() {
		return areaname;
	}
	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}
	@Column(name = "pid")
	public Integer getPid() {
		return pid;
	}
	public void setPid(Integer pid) {
		this.pid = pid;
	}
	@Override
	public String toString() {
		return "Area [areaid=" + areaid + ", areaname=" + areaname + ", pid="
				+ pid + "]";
	}
	public Area(Integer areaid) {
		super();
		this.areaid = areaid;
	}
	public Area(String areaname) {
		super();
		this.areaname = areaname;
	}
	public Area(Integer areaid, Integer pid) {
		super();
		this.areaid = areaid;
		this.pid = pid;
	}
	public Area(Integer areaid, String areaname) {
		super();
		this.areaid = areaid;
		this.areaname = areaname;
	}
	public Area() {
		super();
	}
	
	
}
