package com.monitor.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "company", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = { "id" }) })
public class Company {
	private Integer id;
	private String companyid;
	private String companyname;
	//private Address fulladdress;
	private String mobilephone;
	private String fixedphone;
	private String fax;
	private String position;
	private String provincename;
	private String cityname;
	private String regionname;
	private Integer area_id;
	private String address;
	private Integer provinceid;
	private Integer cityid;
	private Integer regionid;
	@GenericGenerator(name = "generator", strategy = "increment")
	@GeneratedValue(generator = "generator")
	@Column(name = "id", unique = true, nullable = false)
	@Id
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	@Column(name = "companyid", length = 50, nullable = false, updatable =false)
	public String getCompanyid() {
		return companyid;
	}
	public void setCompanyid(String companyid) {
		this.companyid = companyid;
	}
	@Column(name = "companyname", length = 100)
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	@Column(name = "mobilephone", length = 20)
	public String getMobilephone() {
		return mobilephone;
	}
	public void setMobilephone(String mobilephone) {
		this.mobilephone = mobilephone;
	}
	@Column(name = "fixedphone", length = 20)
	public String getFixedphone() {
		return fixedphone;
	}
	public void setFixedphone(String fixedphone) {
		this.fixedphone = fixedphone;
	}
	@Column(name = "fax", length = 20)
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	@Column(name = "position", length = 100)
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	
	@Column(name = "provincename", length = 50)
	public String getProvincename() {
		return provincename;
	}
	public void setProvincename(String provincename) {
		this.provincename = provincename;
	}
	
	@Column(name = "cityname", length = 50)
	public String getCityname() {
		return cityname;
	}
	public void setCityname(String cityname) {
		this.cityname = cityname;
	}
	
	@Column(name = "regionname", length = 50)
	public String getRegionname() {
		return regionname;
	}
	public void setRegionname(String regionname) {
		this.regionname = regionname;
	}
	@Column(name = "areaid", length = 11)
	public Integer getArea_id() {
		return area_id;
	}
	public void setArea_id(Integer area_id) {
		this.area_id = area_id;
	}
	public String getAddress() {
		return address;
	}
	@Column(name = "address", length = 200)
	public void setAddress(String address) {
		this.address = address;
	}
	public Company(Integer id) {
		super();
		this.id = id;
	}
	public Company(String companyid) {
		super();
		this.companyid = companyid;
	}
	public Company(String companyname, boolean isName) {
		super();
		this.companyname = companyname;
	}
	@Transient
	public Integer getProvinceid() {
		return provinceid;
	}
	public void setProvinceid(Integer provinceid) {
		this.provinceid = provinceid;
	}
	@Transient
	public Integer getCityid() {
		return cityid;
	}
	public void setCityid(Integer cityid) {
		this.cityid = cityid;
	}
	@Transient
	public Integer getRegionid() {
		return regionid;
	}
	public void setRegionid(Integer regionid) {
		this.regionid = regionid;
	}
	public Company() {
		super();
	}
	@Override
	public String toString() {
		return "Company [id=" + id + ", companyid=" + companyid
				+ ", companyname=" + companyname + ", mobilephone="
				+ mobilephone + ", fixedphone=" + fixedphone + ", fax=" + fax
				+ ", position=" + position + ", provincename=" + provincename
				+ ", cityname=" + cityname + ", regionname=" + regionname
				+ ", area_id=" + area_id + ", address=" + address
				+ ", provinceid=" + provinceid + ", cityid=" + cityid
				+ ", regionid=" + regionid + "]";
	}
	
}
