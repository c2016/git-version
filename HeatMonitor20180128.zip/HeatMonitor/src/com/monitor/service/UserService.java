package com.monitor.service;

import java.util.List;
import java.util.Map;

import com.monitor.entity.Menu;
import com.monitor.entity.Role;
import com.monitor.entity.User;
import com.monitor.model.RoleModel;
import com.monitor.model.UserModel;
import com.monitor.util.AjaxResult;
import com.monitor.util.page.PageResultSet;

public interface UserService {
	public User getUserByName(String username);
	public AjaxResult updatePassword(UserModel user, String password);	//OK
	//***********************

	public void saveUser(User user);
	public void updateUser(User user);
	public void deleteUser(User user);
	public void saveRole(Role role);
	//public void updateRole(Role role);
	//public void deleteRole(Role role);
	public AjaxResult addUser(UserModel user);
	public AjaxResult updateUser(UserModel user);//OK
	public AjaxResult deleteUser(String[] user_ids);//OK	
	public AjaxResult checkUser(UserModel user);	

	public List<User> findAllUserList();
	//public List<User> findUserListByCondition(UserModel userModel);
	public User findUserByByCondition(UserModel userModel);
	public User getUserById(int id);
	public UserModel getUserModelById(int id);
	public PageResultSet<User> findPageUserList(UserModel userModel, int page,
			int pageSize);

	
	//**************
	public UserModel getLoginuser(String userName);
	public Map<String, Object> getLoginuser(UserModel user);
	public UserModel updateLoginuser(User user);	
	public Integer updateOperatorStatus(Integer userid, boolean isOnline);
	
	
	//2017
	public boolean checkUserRole(User user0);
	public List<Menu> findMenuList(UserModel user);
	public boolean checkUserRole(UserModel user0);

	public Map<String, Object> getUserListByPage(int page, int pz);
	public Map<String, Object> getRoleListByPage(Role role, int page,int pageSize);
	

	 public Map<String, Object> getUserListByPage(int page, int pagesize, UserModel user);
	//-------------------2017-8-22
	///public AjaxResult listAllRoles();
	public AjaxResult checkRole(Role role);
	Role getRoleById(RoleModel role);
	Role getRoleById(int id);
	Role getRoleById(Role role);
	public AjaxResult addRole(Role role);
	public AjaxResult updateRole(RoleModel role);
	public AjaxResult updateRole(Role role);
	public AjaxResult deleteRole(String role_id);
	int deleteRoleById(String[] roleIds);	//s_role
	int deleteRoleMenu(Role role);			//s_role_menu
    int deleteRoleUserById(String role_id);	//s_user_role
    int deleteUserRole(String[] user_ids);	// triggered when doing authorization
	//int insertRoleMenu(Role role);
	int insertRoleMenu(RoleModel role);
	int insertRole(Role role);
    public int addUserRole(UserModel userModel);
    List<RoleModel> listAllMenus();
	List<RoleModel> listRoleMenusById(RoleModel role);

	public AjaxResult saveAuthorizeMenu(String role_id, String menu_id);
	public AjaxResult saveAuthorizeRole(String role_id, String user_id, String role_type);
	
	public List<UserModel> getUserRole(UserModel user);
	public List<RoleModel> listAllRoles();//AjaxResult
// from IuserDao	
	//public boolean addUser(UserTable userTable);//addUser(UserModel)
    //public List<UserTable> getUser(UserTable userTable);//
	//public boolean updateUser(UserTable userTable);//AjaxResult updateUser(User user, boolean b);
    //public List<UserTable> checkUser(UserTable userTable);//public List<User> checkUser(UserModel user);
    //public List<UserTable> getUserRole(UserTable userTable);
    
	//public int deleteUser(String[] user_ids);//public AjaxResult deleteUser(String[] user_ids);
	
	//public int updatePassword(UserTable usertable);
	
	//int updateRoleBaseInfo(Role role);
	
	//public List<Role> checkRole(Role role);
	
	 List<Role> listAllRoles(int page, int pagesize);
	 //public Map<String, Object> getUserPage(UserTable userTable, int page, int pagesize);
	public AjaxResult checkUser(String username);
		
}
