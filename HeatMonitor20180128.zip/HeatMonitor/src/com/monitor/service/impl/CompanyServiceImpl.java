package com.monitor.service.impl;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.monitor.entity.Company;
import com.monitor.model.CompanyModel;
import com.monitor.model.UserModel;
import com.monitor.service.CompanyService;
import com.monitor.util.AjaxResult;
@Service("companyService")
public class CompanyServiceImpl implements CompanyService {

	@Override
	public void saveCompany(Company o) {
		// TODO Auto-generated method stub

	}

	@Override
	public void updateCompany(Company o) {
		// TODO Auto-generated method stub

	}

	@Override
	public void deleteCompany(Company o) {
		// TODO Auto-generated method stub

	}

	@Override
	public AjaxResult addCompany(CompanyModel o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult updateCompany(CompanyModel o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult deleteCompany(String[] o_ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult checkCompany(CompanyModel o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Company> listCompanies(UserModel user, String provinceid,
			String cityid, String areaid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<String> listCompanyIDs(UserModel user, String provinceid,
			String cityid, String areaid) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Company getCompanyById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult checkCompanyName(Company company) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> getCompanyListByPage(int page, int pz) {
		// TODO Auto-generated method stub
		return null;
	}

}
