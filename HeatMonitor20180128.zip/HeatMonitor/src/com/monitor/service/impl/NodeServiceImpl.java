package com.monitor.service.impl;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.monitor.dao.BaseDAO;
import com.monitor.entity.Node;
import com.monitor.model.NodeModel;
import com.monitor.model.UserModel;
import com.monitor.service.NodeService;
import com.monitor.util.AjaxResult;

@Service("nodeService")
public class NodeServiceImpl implements NodeService {
	@Resource
	BaseDAO<Node> nodeDao;
	@Resource
	BaseDAO<String> stringDao;

	@Override
	public void saveNode(Node o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateNode(Node o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void deleteNode(Node o) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public AjaxResult addNode(NodeModel o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult updateNode(NodeModel o) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult deleteNode(String[] o_ids) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult checkNode(NodeModel o) {
		// TODO Auto-generated method stub
		return null;
	}
	/*地图加载获得站点完整信息*/
	@Override
	public AjaxResult listNodes(String areaid, String companyid, String nodeid) {
/*		//hql
 		StringBuilder hql = new StringBuilder();
		hql.append("from Node t where 1 = 1 ");
		if(!StringUtils.isBlank(areaid))
			hql.append(" and t.areaid = " + areaid);
		if(!StringUtils.isBlank(companyid))
			hql.append(" and t.companyid = " + companyid);
		List<Node> list = nodeDao.find(hql.toString());*/
		StringBuilder sql = new StringBuilder();
		sql.append("select d.areaname, d.areaid, b.nodeid, b.nodepkid, b.nodename,b.address, ");
		sql.append("b.telephone, b.start_date, b.gpspos ");
		//sql.append(" , c.companycode, c.companyname ");  
		sql.append(" from node b, area d where 1=1 ");//, company c
		//sql.append("##and b.nodeid in (select nodeid from node)");
		sql.append(" and d.AREAID =b.AREAID ");
		//sql.append(" and b.COMPANYID = c.COMPANYID ");
		//sql.append("#and c.COMPANYID in (select companyid from company) ");
		if(!StringUtils.isBlank(areaid))
			sql.append(" and t.areaid = " + areaid);
		//if(!StringUtils.isBlank(companyid))
		//	sql.append(" and t.companyid = " + companyid);
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and t.nodepkid = " + nodeid);
		//sql.append(" and b.isactive = 1 "); // 此条件影响地图加载节点
		sql.append(" group by b.nodepkid order by b.nodepkid, b.nodename  asc  ");
		List<NodeModel> list = nodeDao.findBySQL(sql.toString());

		if(list.size()> 0)
			return new AjaxResult(1, "储热节点已获取", list);
		else{
			return new AjaxResult("该区域未找到储热节点");
		}
		//return new AjaxResult("加载储热节点失败，请联系管理员");
	}
	@Override
	public List<Node> listNodes(String areaid, String companyid) {
		StringBuilder hql = new StringBuilder("select new Node(t.nodepkid, t.nodename) from Node t where 1 = 1 and t.isactive = 1 ");
		if(!StringUtils.isBlank(areaid))
			hql.append(" and t.areaid = " + areaid);
		/*if(!StringUtils.isBlank(companyid))
			hql.append(" and t.companyid = " + companyid);*/
		return nodeDao.find(hql.toString());
	}

	@Override
	public List<String> listNodeIDs(UserModel user, String provinceid,
			String cityid, String areaid) {
		return null;
	}

	@Override
	public Node getNodeById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public AjaxResult checkNodeName(Node node) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Map<String, Object> getNodeListByPage(int page, int pz) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Node> listNodes(UserModel user, String provinceid,
			String cityid, String areaid) {
		// TODO Auto-generated method stub
		return null;
	}


}
