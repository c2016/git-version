package com.monitor.service.impl;

//import net.sf.json.JSONArray;
//import net.sf.json.JSONObject;


import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SessionFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.monitor.dao.BaseDAO;
import com.monitor.entity.Menu;
import com.monitor.entity.Role;
import com.monitor.entity.User;
import com.monitor.model.RoleModel;
import com.monitor.model.UserModel;
import com.monitor.service.UserService;
import com.monitor.util.AjaxResult;
import com.monitor.util.Util;
import com.monitor.util.page.Page;
import com.monitor.util.page.PageResultSet;

@Service("userService")
public class UserServiceImpl implements UserService {

	@Resource
	private BaseDAO<Object> userDao;
	@Resource
	private BaseDAO<Menu> menuDao;
	@Resource 
	private BaseDAO<User> opDao;
	@Resource
	private BaseDAO<Role> roleDao;
	
	private SessionFactory sessionFactory;
	
	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	@Override
	public void saveUser(User user) {
		opDao.save(user);
	}

	@Override
	public void updateUser(User user) {
		opDao.update(user);
	}

	@Override
	public void deleteUser(User user) {
		opDao.delete(user);
	}
	@Override
	public void saveRole(Role role) {
		roleDao.save(role);
	}

	@Override
	public List<User> findAllUserList() {

		return opDao.find("from User u order by u.onlinedate desc");
	}
	@Override
	public UserModel getLoginuser(String userName) {
		/*User user = opDao.get(" from User A where A.username = ? ", new Object[]{userName});
		System.out.println(user);
			return user;*/
		UserModel user = null;
		User user0 = this.getUserByName(userName);
		if(user0 == null) return null;		
		user = new UserModel(user0);	
		this.updateOperatorStatus(user0.getId(), true);
		System.out.println("usermodel: "+ user);			
		return user;
	}
	
	@Override
	public UserModel updateLoginuser(User user){
		return null;
	}
	
	@Override
	public Map<String, Object> getLoginuser(UserModel user) {
		System.out.println(Util.encryptMD5("admin"));
		HashMap<String, Object> map = new HashMap<String, Object>();
		String userName = user.getUsername();
		if("admin".equals(userName) || "administrator".equals(userName)){//administrator 
			//user0 = this.findUserByByCondition(user);
			User user0 = this.getUserByName(userName);
			
			if(user0 != null){
				user = new UserModel(user0);				
				user.setArea_id(-1);
				/*user.setProvince_name("all");
				user.setCity_name("name");
				user.setRegion_name("all");*/
				map.put("user_entity", user0);
				map.put("user_model", user);
				return map;
			}
			else
				return null;
		}
		//非管理员
		return null;			
	}
	@Override
	public Integer updateOperatorStatus(Integer userid, boolean isOnline) {//update isonline true:online
			// TODO Auto-generated method stub
			//String sql ="update OPERATOR  set  ISONLINE = "+ isOnline.trim() +",  LAST_ONLINE_DATE = sysdate  where OP_ID = " + user.getOp_id().trim();
			String sql ="";
			if(isOnline)
				sql = "update user  set  ISONLINE = '1',  ONLINE_DATE = now()  where userid = " + userid;
			else
				sql = "update user  set  ISONLINE = '0'  where userid = " + userid;

System.out.println("updateOpertorStatus_date: " + sql);			
			return userDao.updateObjectBySQL(sql);
		}

/*	@Override
	public List<User> findUserListByCondition(UserModel userModel) {
		StringBuffer hql = new StringBuffer("from User u where 1=1");
		List<Object> paramList = new ArrayList<Object>();
		if (userModel.getUser_id() != null) {
			hql.append(" and u.id = ?");
			paramList.add(userModel.getUser_id());
		}
		if (!StringUtils.isBlank(userModel.getUsername())) {
			hql.append(" and u.username = ?");
			paramList.add(userModel.getUsername());
		}

		if (!StringUtils.isBlank(userModel.getPassword())) {
			hql.append(" and u.password = ?");
			paramList.add(userModel.getPassword());
		}
		return opDao.find(hql.toString(), paramList);
	}*/

	@Override
	public User findUserByByCondition(UserModel userModel) {
		StringBuffer hql = new StringBuffer("from User u where 1=1");
		List<Object> paramList = new ArrayList<Object>();
		if (userModel.getUser_id() != null) {
			hql.append(" and u.id = ?");
			paramList.add(userModel.getUser_id());
		}
		if (!StringUtils.isBlank(userModel.getUsername())) {
			hql.append(" and u.username = ?");
			paramList.add(userModel.getUsername());
		}

		if (!StringUtils.isBlank(userModel.getPassword())) {
			hql.append(" and u.password = ?");
			paramList.add(userModel.getPassword());
		}
		return opDao.get(hql.toString(), paramList.toArray());
	}

	@Override
	public User getUserById(int id) {
		return opDao.get(User.class, id);
	}
	@Override
	public UserModel getUserModelById(int id) {
		User user0 =  opDao.get(User.class, id);
		return new UserModel(user0);
	}

	@Override
	public PageResultSet<User> findPageUserList(UserModel userModel, int page,
			int pageSize) {//未使用

		StringBuffer hql = new StringBuffer("from User u where 1=1");
		List<Object> paramList = new ArrayList<Object>();		
		if (!StringUtils.isBlank(userModel.getUsername())) {
			hql.append(" and u.username = ?");
			paramList.add(userModel.getUsername());
		}
		if (!StringUtils.isBlank(userModel.getPassword())) {
			hql.append(" and u.password = ?");
			paramList.add(userModel.getPassword());
		}	
		//hql.append(" order by u.onlinedate desc");
		hql.append(" order by u.username asc");
		Long totalRow = userDao.count(hql.toString(), paramList);
		Page pages = new Page(totalRow.intValue(), pageSize, page);
		// 这里用到了Page类中的获取首页和分页大小的方法
		List<User> list = opDao.find(hql.toString(), paramList, page,pageSize);
		PageResultSet<User> pageResultSet = new PageResultSet<User>();
		pageResultSet.setList(list);
		pageResultSet.setPage(pages);
		return pageResultSet;
	}

	// ---20170714
	@Override
	public boolean checkUserRole(User user0) {
		StringBuilder sql = new StringBuilder("select A.id, A.usid, A.rid from s_user_role A where 1=1 ");
		sql.append(" and A.USID='"+ user0.getId() +"'");
		List<Object> list= userDao.findObjectBySQL(sql.toString());
		//Object[] obj = (Object[]) userDao.findObjectBySQL(sql.toString());//没有权限
		if( list !=null && list.size() > 0 )
			return true;
		return false;
	}

	@Override
	public boolean checkUserRole(UserModel user0) {
		StringBuilder sql = new StringBuilder("select A.id, A.usid, A.rid from s_user_role A where 1=1 ");
		sql.append(" and A.USID='"+ user0.getUser_id() +"'");
		List<Object> list= userDao.findObjectBySQL(sql.toString());
		//Object[] obj = (Object[]) userDao.findObjectBySQL(sql.toString());//没有权限
		if( list !=null && list.size() > 0 )
			return true;
		return false;
	}

	@Override
	public User getUserByName(String username) {
/*		StringBuilder sql = new StringBuilder("select A.userid, A.username, A.password, A.role, A.online_date, a.isactive, a.isonline from user A where 1 = 1 ");
		sql.append(" and A.username='"+username+"'");
		User u = (User) opDao.getBySQL(sql.toString(), User.class);
System.out.println(u);*/			
		StringBuilder hql = new StringBuilder();
		hql.append("select new User(A.id, A.username, A.password, A.role, A.onlinedate, A.isonline, A.isactive) ");
		hql.append(" from User A where 1=1 ");
		hql.append(" and A.username = ?0");
		User u0 = (User) opDao.get4(hql.toString(), new Object[]{username});
		return u0;
	}
	
	@Override
	public List<Menu> findMenuList(UserModel user) {
		Pattern pattern = Pattern.compile("administrator");
		Matcher matcher = pattern.matcher(user.getUsername());

		StringBuilder sql = new StringBuilder("");
		if (matcher.find()){//(user.getUsername().equals.("admin")){
			sql.append("select A.ID, A.NAME, A.MTYPE,A.URL, A.DESCRIPTION, A.PID, A.SORT, A.FINISH, A.ACTIVE ");
			sql.append("from s_menu A where 1=1 and A.active <>'9' order by A.PID, A.SORT ");
		}else{
			//select DISTINCT MID from (select RID from s_user_role where usid = '1')  A, s_role_menu  B where A.rid = B.rid ;
			//select * from s_menu  S,(select DISTINCT M.MID from s_role_menu  M, (select RID from s_user_role where USID='1') R, s_role O where  M.rid = R.RID and O.ID= R.RID and O.active <>'9') A where A.mid = S.id and  S.active <> '9' order by S.pid,S.sort
			sql.append(" select * from s_menu  S, ");
			sql.append(" (select DISTINCT M.MID from s_role_menu  M, (select RID from s_user_role where USID='"+ user.getUser_id() +"') R, s_role O ");
			sql.append(" where M.RID = R.RID  and O.ID= R.RID and O.active <>'9') A ");
			sql.append(" where A.MID = S.id and  S.ACTIVE <> '9' order by S.PID, S.SORT ");

		}
		 
		//return menuDao.findListBySQL(sql.toString(), Menu.class);
		List<Menu> list = menuDao.findListBySQL(sql.toString(), Menu.class);
System.out.println("menu: "+ list);		

		return list;
	}


	@Override
	public AjaxResult updatePassword(UserModel user,  String password) {
		// TODO Auto-generated method stub
		//User user = opDao.get(User.class, user_id);
		String sql="update user set " +
				" PASSWORD='"+ Util.encryptMD5(password)+"' "+
						" where userid="+ user.getUser_id() +"";
		int i =  opDao.updateBySQL(sql);
		if(i < 1){
			return new AjaxResult("密码设置失败，请联系管理员");
		}
		else{
			return new AjaxResult(1, "密码设置成功");
		}
	}
/*分页查询*/
	@Override
	public Map<String, Object> getUserListByPage(int page, int pagesize, UserModel user) {
		// TODO Auto-generated method stub
		
		Map<String, Object> map = new HashMap<String, Object>();
		StringBuilder sql = new StringBuilder("");
		if(user.getUsername().equalsIgnoreCase("superadmin")){		
				sql.append("select t.ID, t.USERNAME, t.ROLETYPE, t.PASSWORD, t.user_tel, t.last_ONLINE_DATE, t.NAME from user t where id>0");
		}else{
			sql.append("select t.ID, t.USERNAME, t.ROLETYPE, t.PASSWORD, t.user_tel, t.last_ONLINE_DATE, t.NAME from user t where id>0");
			sql.append(" and t.area_id = " + user.getArea_id());
		}
		List<Object> lCount=userDao.findObjectBySQL(sql.toString());		
System.out.println("All companyies: "+lCount);
		if(lCount != null && lCount.size()>0) 
			map.put("total", lCount.size());
		else
			return null;		
		List<Object> list = userDao.findObjectBySQL(sql.toString(), (page-1)*pagesize, pagesize);
		List<UserModel> list1=new ArrayList<UserModel>();
		for(int i=0;i<list.size();i++)
		{
			Object[] obj =(Object[]) list.get(i);
			UserModel o = new UserModel();
			String id =obj[0].toString();
			String uname =obj[1].toString();
			String roletype = obj[2]==null?"0": obj[2].toString();
			String password =obj[3].toString();
			String tel =obj[4]==null?null:obj[4].toString();
			String date = obj[5]==null ? null : obj[5].toString();
			String name = obj[6]==null ? null : obj[6].toString();
			o.setPassword(password);
			o.setUser_id(Integer.valueOf(id));
			o.setUsername(uname);
			o.setsRoletype(roletype);
			java.util.Date uDate;
			if(date!=null){
				try {
					uDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
		System.out.println(new java.sql.Date(uDate.getTime()));
					o.setOnlinedate(new java.sql.Date(uDate.getTime())); 
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}

			list1.add(o);
		}
		
		map.put("rows", list1);
		/*map.put("firstPage", 1);
		int p = lCount.size()/pagesize;
		int q = lCount.size()/pagesize;
		map.put("lastPage", q==0 ? p : (p+1));*/
		return map;
	}
	@Override
	public Map<String, Object> getUserListByPage(int page, int pagesize) {
		// TODO Auto-generated method stub
		
		Map<String, Object> map = new HashMap<String, Object>();
		StringBuilder sql = new StringBuilder("");
		sql.append("select t.ID, t.USERNAME, t.ROLETYPE, t.PASSWORD, t.user_tel, t.last_ONLINE_DATE, t.NAME from user t where id>0");
		
		List<Object> lCount=userDao.findObjectBySQL(sql.toString());		
		if(lCount != null && lCount.size()>0) 
			map.put("total", lCount.size());
		else
			return null;		
		List<Object> list = userDao.findObjectBySQL(sql.toString(), (page-1)*pagesize, pagesize);
		List<UserModel> list1=new ArrayList<UserModel>();
		for(int i=0;i<list.size();i++)
		{
			Object[] obj =(Object[]) list.get(i);
			UserModel o = new UserModel();
			String id =obj[0].toString();
			String uname =obj[1].toString();
			String roletype = obj[2]==null?"0": obj[2].toString();
			String password =obj[3].toString();
			String tel =obj[4]==null?null:obj[4].toString();
			String date = obj[5]==null ? null : obj[5].toString();
			String name = obj[6]==null ? null : obj[6].toString();
			o.setPassword(password);
			o.setUser_id(Integer.valueOf(id));
			o.setUsername(uname);
			o.setsRoletype(roletype);
			java.util.Date uDate;
			if(date!=null){
				try {
					uDate = new SimpleDateFormat("yyyy-MM-dd").parse(date);
		System.out.println(new java.sql.Date(uDate.getTime()));
					o.setOnlinedate(new java.sql.Date(uDate.getTime())); 
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
			list1.add(o);
		}
		
		map.put("rows", list1);
		/*map.put("firstPage", 1);
		int p = lCount.size()/pagesize;
		int q = lCount.size()/pagesize;
		map.put("lastPage", q==0 ? p : (p+1));*/
		return map;
	}
	@Override
	public AjaxResult checkUser(UserModel user) {
		//List<User> list= this.findUserListByCondition(user);	
		List list = opDao.find(" from User u where u.username = " + user.getUsername());
		if(list.size() >=1 )
		/*User user0= opDao.get4(" from User u where u.username = ?0", new Object[]{user.getUsername()});
		if(user0 != null)*/
			return new AjaxResult(0, "登录用户名已存在！");
		else
			return new AjaxResult(1, "用户名可用");
	}
	@Override
	public AjaxResult checkUser(String username) {
		//List<User> list= this.findUserListByCondition(user);	
		//List list = opDao.find(" from User u where u.username = " + user.getUsername());
		//if(list.size() >=1 )
		User user0= opDao.get4(" from User u where u.username = ?0", new Object[]{username});
		if(user0 != null)
			return new AjaxResult(0, "登录用户名已存在！");
		else
			return new AjaxResult(1, "用户名可用");
	}
	@Override
	@Transactional
	public AjaxResult addUser(UserModel user) {
		if( user.getUser_id() != null) return  this.updateUser(user);//用户存在进行修改更新
		String roleType = user.getsRoletype();
		if( roleType == null)		roleType = "0";
		if(user.getPassword() == null)
			user.setPassword(Util.encryptMD5("111111"));
		
		StringBuilder sql= new StringBuilder("insert into user(USERNAME ,PASSWORD, ROLE) ");
		sql.append(" values('"+user.getUsername()+"', '"+ user.getPassword()+"', '"+ roleType +"')");
		int i= opDao.updateObjectBySQL(sql.toString());     
		
		if(i>0)
			return new AjaxResult(1, "添加成功");
        else
        	return new AjaxResult("添加用户失败");
	}

	@Override
	@Transactional
	public AjaxResult updateUser(UserModel user) {
		// TODO Auto-generated method stub
		/*String roleType = user.getRoletype();
		if( roleType == null || "".equals(roleType))
			roleType = "0";
		StringBuilder sql = new StringBuilder("update user set ");
		sql.append("USERNAME='"+user.getUsername() +
				"',USER_TEL='"+user.getTel()+"', NAME='"+user.getName()+"', ROLETYPE='"+ roleType +"'" +
				" where id="+user.getId()+"");
		int i= opDao.updateObjectBySQL(sql.toString());*/
		System.out.println(user.getUser_id());
		User user0 = (User) opDao.get(User.class,user.getUser_id());

		if (user0 != null){			
			//	user0.setRoletype(user.getRoletype());			
			int i = userDao.update(user0);
			if(i<1 )
				return new AjaxResult("修改失败，请联系管理员");
			else
				return new AjaxResult(1, "修改成功");
		}
		return new AjaxResult("Invalid User");
	}

	@Override
	@Transactional
	public AjaxResult deleteUser(String[] user_ids) {	
		// TODO Auto-generated method stub
		String result= "InvalidUser";		
		StringBuilder sql= new StringBuilder(" delete from user ") ;
		if(user_ids.length>0){
			sql.append(" where id in ('") ;	
			for(int i=0;i<user_ids.length;i++)
			{
				if(user_ids[i]!=null&&!"".equals(user_ids[i]))
					sql.append(user_ids[i]+"','");
			}
			sql.append("') ");
		
			int i = opDao.updateBySQL(sql.toString());	
			if(i<1 )
				result="删除失败，请联系管理员";
			else{			
				this.deleteUserRole(user_ids);
				return new AjaxResult(1, "删除成功");
			}
		}
		return new AjaxResult(result);
	}

	public int deleteUserRole(String[] user_ids) {		//delete from s_user_role when delete a user or authorization
		String sql=" delete from s_user_role where usid in ('" ;
		for(int i=0;i<user_ids.length;i++)
		{
		if(user_ids[i]!=null&&!"".equals(user_ids[i]))
			sql=sql+user_ids[i]+"','";
		}
		if(user_ids.length>0)
			sql=sql+"') ";
		return userDao.updateObjectBySQL(sql);
	}
//*************************************************************
	@Override
	public AjaxResult checkRole(Role role) {
		StringBuilder sql = new StringBuilder("select r.name from s_role r where r.name= '" + role.getName()+"'");
		//Role obj = roleDao.getBySQL(sql.toString(), Role.class);//需要id
		String obj = (String)userDao.getObjectBySQL(sql.toString());
		if(obj != null )
			return new AjaxResult(0, "角色名已存在！");
		else
			return new AjaxResult(1, "角色名可用");
	}

	@Override
	public Role getRoleById(int id) {
		return roleDao.get(Role.class, id);
	}
	@Override
	@Transactional
	public AjaxResult addRole(Role role){
		//if( role.getId() != null) return  this.updateRole(role);//已存在进行修改更新 
		role.setActive(1);
		int i = roleDao.saveOrUpdate(role);
		if(i>0)
			return new AjaxResult(1, "添加成功");
		else
			return new AjaxResult("添加角色失败");		
	}
	@Override
	@Transactional
	public AjaxResult updateRole(Role role) {
		Role role0 = (Role) roleDao.get(Role.class, role.getId());
		if (role0 != null){	
			role0.setDes(role.getDes());			
			int i = roleDao.update(role0);
			if(i<1 )
				return new AjaxResult("修改失败，请联系管理员");
			else
				return new AjaxResult(1, "修改成功");
		}
		return new AjaxResult("Invalid Role");		
	}
	@Override
	@Transactional
	public AjaxResult updateRole(RoleModel role){
System.out.println("Updating role");
		return null;
	}

	@Override
	@Transactional
	public AjaxResult deleteRole(String role_id) {
		String[] role_ids = role_id.split(",");
		
		int i = this.deleteRoleById(role_ids);		//s_role
		for(int k=0;k<role_ids.length;k++)
		{
			this.deleteRoleUserById(role_ids[k]);	//s_user_role
			Role role=new Role();
			role.setId(Integer.parseInt(role_ids[k]));
			this.deleteRoleMenu(role);				//s_role_menu
		}
		if (i >= 1)
			return new AjaxResult(1, "删除成功");
		else
			return new AjaxResult("删除失败");
	}

	public int deleteRoleMenu(Role role) {//s_role
		String sql=" delete from s_role_menu where rid =  " ;
		sql=sql+ role.getId();		
		return userDao.updateObjectBySQL(sql);
	}
	public int deleteRoleUserById(String role_id) {//s_user_role
		String sql=" delete from s_user_role where rid =  " ;
		sql=sql+ role_id;		
		return userDao.updateObjectBySQL(sql);
	}
	public int deleteRoleById(String[] roleIds) {//s_role
		String sql=" delete from s_role  " ;
		if(roleIds.length>0)
		sql=sql+" where id in ('" ;		
		for(int i=0;i<roleIds.length;i++)
		{
		if(roleIds[i]!=null&&!"".equals(roleIds[i]))
			sql=sql+roleIds[i]+"','";
		}
		if(roleIds.length>0)
			sql=sql+"') ";
		return userDao.updateObjectBySQL(sql);
	}
	public int insertRole(Role role) {
		String sql="insert into s_role(name,des,active)" +
		"values('"+role.getName()+"','"+role.getDes()+"" +
		"','"+1 +"')";
        return userDao.updateObjectBySQL(sql);
	}

	public int insertRoleMenu(RoleModel role) {
		String sql="insert into s_role_menu(rid,mid) " +
		"values('"+role.getRole_id()+"','"+role.getMenu_id() +"')";
        return userDao.updateObjectBySQL(sql);
	}
	public int addUserRole(UserModel userModel) {
		// TODO Auto-generated method stub
		String sql="insert into s_user_role(usid,rid) " +
				"values('"+userModel.getUser_id()+"','"+userModel.getsRoletype() +"')";		
		//update operator's field—— role
		String sqlrole = "update user"+" set roletype='"+ userModel.getsRoletype() +"' where id='"+ userModel.getUser_id()+"'";//******************8
		userDao.updateObjectBySQL(sqlrole);		
		
		return userDao.updateObjectBySQL(sql);
	}
	//************************************************************************
	public List<RoleModel> listAllMenus() {
		String sql="select id menu_id ,name menu_name,pid menu_pid from s_menu where 1=1 and active <> '9'";
		List<Object> list=userDao.findObjectBySQL(sql);
		
		List<RoleModel> list1=new ArrayList<RoleModel>();
		for(int i=0;i<list.size();i++)
		{			
			Object[] obj =(Object[]) list.get(i);
			RoleModel role=new RoleModel();
			
			String menu_id =obj[0].toString();
			String menu_name =obj[1].toString();
			String menu_pid=obj[2].toString();
			role.setMenu_id(menu_id);
			role.setMenu_pid(menu_pid);
			role.setMenu_name(menu_name);
			
			list1.add(role);
		}
		 
		return  list1;
	}

	public List<RoleModel> listRoleMenusById(RoleModel role1) {
		String sql="select mid menu_id from s_role_menu where 1=1 ";
		if(role1.getRole_id()!=null&&!"".equals(role1.getRole_id()))
		{
			sql=sql+" and rid = " +role1.getRole_id();
		}
		List<Object> list=userDao.findObjectBySQL(sql);
		
		List<RoleModel> list1=new ArrayList<RoleModel>();
		if(list.size() > 1){
			for(int i=0;i<list.size();i++)
			{	
				Object obj =(Object) list.get(i);
				RoleModel role=new RoleModel();
				String menu_id =obj.toString();				
				role.setMenu_id(menu_id);
				
				list1.add(role);
			}
		}
		return  list1;
	}
	//**************************************************************
	@Override
	public AjaxResult saveAuthorizeMenu(String role_id, String menu_id){
		String[] menu_ids = menu_id.split(",");
		Role role=new Role(); 
		RoleModel rolemodel =  new RoleModel();
		role.setId(Integer.parseInt(role_id));
		rolemodel.setRole_id(role_id);
		int k =0;
		this.deleteRoleMenu(role);
		for(int i=0;i<menu_ids.length;i++)
		{
			rolemodel.setMenu_id(menu_ids[i]);
			k=this.insertRoleMenu(rolemodel);
		}
		if (k >= 1){
			return new AjaxResult(1, "授权成功");
		}
		return new AjaxResult("授权失败");
	}
	public AjaxResult saveAuthorizeRole(String role_id, String user_id, String role_type){
		String[] role_ids = role_id.split(",");
		String[] user_ids = user_id.split(",");		
		UserModel user=new UserModel();
		user.setUser_id(Integer.parseInt(user_id));
		int k =0;
		this.deleteUserRole(user_ids);
		for(int i=0;i<role_ids.length;i++)
		{		
			user.setsRoletype(role_type);//浏览用户				
			k=this.addUserRole(user);
		}
	
		if (k >= 1){
			return new AjaxResult(1, "角色设置成功");
		}
		else
			return new AjaxResult("角色设置失败");
	}
	@Override
	public List<UserModel> getUserRole(UserModel user){
		String sql=" select rid from s_user_role where 1=1 ";		
		if(user.getUser_id()!=null&&!"".equals(user.getUser_id()))
		{
			sql=sql+" and usid = " +user.getUser_id();
		}
		List<Object> list=userDao.findObjectBySQL(sql);			
		List<UserModel> list1=new ArrayList<UserModel>();
		for(int i=0;i<list.size();i++)
		{
			Object obj =(Object) list.get(i);
			UserModel user0=new UserModel();
			user0.setsRoletype((String)obj);
			list1.add(user0);
		}
		return  list1;
	}
//########################################################################
	@Override
	public List<RoleModel>  listAllRoles() {
		String sql="select id,name,des,active from s_role where 1=1 "; 
		List<Object> list=userDao.findObjectBySQL(sql);		
		List<RoleModel> list1=new ArrayList<RoleModel>();
		for(int i=0;i<list.size();i++)
		{
			Object[] obj =(Object[]) list.get(i);
			RoleModel role=new RoleModel();
			String role_id = obj[0].toString();
			String name =obj[1].toString();
			String des=obj[2].toString();
			String active=obj[3].toString();
			role.setRole_id(role_id);
			role.setName(name);
			role.setDes(des);
			role.setActive(active);
			
			list1.add(role);
		}		 
		return list1; //new AjaxResult(1, "返回所有角色", (Object)list1);
	}
	
	public Role getRoleById(Role role1) { return null;}
	@SuppressWarnings("unused")
	public RoleModel getRoleById_(RoleModel role1) {
		String sql=" select id role_id ,name,des,active from s_role where 1=1";
		if(role1.getRole_id()!=null&&!"".equals(role1.getRole_id()))
		{
			sql=sql+" and id = " +role1.getRole_id();
		}
		List<Object> list=userDao.findObjectBySQL(sql);
		RoleModel role = new RoleModel();
		for(int i=0;i<list.size();i++)
		{
			Object[] obj =(Object[]) list.get(i);
			String role_id =obj[0].toString();
			String name=obj[1].toString();
			String des=obj[2].toString();
			String active=obj[3].toString();
			role.setRole_id(role_id);
			role.setName(name);
			role.setDes(des);
			role.setActive(active);
			break;
		}
		return role;
	}
	
	public int updateRoleBaseInfo(Role role) { 
		return 0;
	}
	
	public int updateRoleBaseInfo_(RoleModel role) {
		String sql="update s_role set " +
		" name='"+role.getName()+"',des='"+role.getDes() +"'" +
				" where  id="+role.getRole_id()+"";
        int i= userDao.updateObjectBySQL(sql);
		return i;
	}
	
	public List<RoleModel> checkRole_(RoleModel role) {
		String sql="select o.ID,o.NAME  from s_role o where 1=1 ";
		if(role.getRole_id()!=null&&!"".equals(role.getRole_id()))
			sql=sql+" and o.ID !="+role.getRole_id();
		if(role.getName()!=null&&!"".equals(role.getName()))
			sql=sql+" and o.Name='"+role.getName()+"' ";
		List<Object> list=userDao.findObjectBySQL(sql);
		List<RoleModel> list1=new ArrayList<RoleModel>();
		for(int i=0;i<list.size();i++)
		{
			Object[] obj =(Object[]) list.get(i);
			RoleModel role1 = new RoleModel();
			String role_id =obj[0].toString();
			String name =obj[1].toString();
			role1.setRole_id(role_id);
			role1.setName(name);
			
			list1.add(role1);
		}
		return  list1;
	}
	@Override
	public List<Role> listAllRoles(int page, int pageSize) {
		String sql="select id role_id ,name,des,active from s_role where 1=1 ";
		List<Object> list=userDao.findObjectBySQL(sql, (page-1)*pageSize, pageSize);		
		List<Role> list1=new ArrayList<Role>();
		for(int i=0;i<list.size();i++)
		{
			Object[] obj =(Object[]) list.get(i);
			Role role=new Role();
			String role_id =obj[0].toString();
			String name =obj[1].toString();
			String des=obj[2].toString();
			String active=obj[3].toString();
			role.setId(Integer.parseInt(role_id));
			role.setName(name);
			role.setDes(des);
			role.setActive(Integer.parseInt(active));			
			list1.add(role);
		}
		 
		return  list1;
	}
	public PageResultSet<Role> findPageRoleList(Role role, int page,int pageSize) {return null;}//未使用
	
	public Map<String, Object> getRoleListByPage(Role role, int page,int pageSize) {
		Map<String, Object> map = new HashMap<String, Object>();
		StringBuffer hql = new StringBuffer("from Role u where 1=1");
		List<Object> paramList = new ArrayList<Object>();
		if (!StringUtils.isBlank(role.getName())) {
			hql.append(" and u.name = ?");
			paramList.add(role.getName());
		}
		if (!StringUtils.isBlank(role.getDes())) {
			hql.append(" and u.des = ?");
			paramList.add(role.getDes());
		}
		if (role.getActive() !=null) {
			hql.append(" and u.active = ?");
			paramList.add(role.getActive());
		}
		hql.append(" order by u.name asc");
		Long totalRow = userDao.count(hql.toString(), paramList);
		// 这里用到了Page类中的获取首页和分页大小的方法
		List<Role> list = roleDao.find(hql.toString(), paramList, page,	pageSize);
		map.put("total", totalRow);
		map.put("rows", list);		
		return map;
	}
	@Override
	public Role getRoleById(RoleModel role) {
		return roleDao.get(Role.class, Integer.parseInt(role.getRole_id()));
	}
	
}
