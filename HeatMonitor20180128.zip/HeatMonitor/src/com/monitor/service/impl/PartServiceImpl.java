package com.monitor.service.impl;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.monitor.dao.BaseDAO;
import com.monitor.service.PartService;
import com.monitor.util.AjaxResult;

@Service("partService")
public class PartServiceImpl implements PartService{
	@Resource
	BaseDAO<Object> userDao;
	@Override
	public AjaxResult  countParts(String nodepkid) {
		StringBuilder sql = new StringBuilder("select count(p.partstatusid) from partstatus p,node n, equipment e where 1 = 1 ");
		if(!StringUtils.isBlank(nodepkid))
			sql.append(" and n.nodepkid = " + nodepkid);
		sql.append(" and n.nodepkid = e.nodepkid and e.pkid = p.pkid ");
		long count = userDao.countBySQL(sql.toString());
		if(count>0){
			return new AjaxResult(1, "找到站点状态信息");
		}
		return new AjaxResult("站点尚未建设完成");		
	}

}
