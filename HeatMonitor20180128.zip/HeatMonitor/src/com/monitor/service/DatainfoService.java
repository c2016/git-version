package com.monitor.service;

import java.util.HashMap;
import java.util.List;

import com.monitor.entity.Datainfo;
import com.monitor.model.DatainfoModel;
import com.monitor.model.UserModel;
import com.monitor.util.AjaxResult;

public interface DatainfoService {
	//根据sql查找
		public List<Datainfo> findListBySQL(String sql);
		public Datainfo getBySQL(String sql);
		public Integer executeSQL(String sql);
		public Datainfo getByPKID(String id);
		public AjaxResult getNewEquipByID(String id);
		
}
