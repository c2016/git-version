package com.monitor.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import com.monitor.entity.Equipment;
import com.monitor.entity.Role;
import com.monitor.model.EquipStatusModel;
import com.monitor.util.AjaxResult;
import com.monitor.util.page.PageResultSet;

public interface EquipmentService {
	//public void saveEquipment(Equipment o);
	////public void updateEquipment(Equipment o);
	//public void deleteEquipment(Equipment o);

	//public AjaxResult addEquipment(Equipment o);
	//public AjaxResult updateEquipment(Equipment o);
	//public AjaxResult deleteEquipment(String[] o_ids);	
	//public AjaxResult checkEquipment(Equipment o);	

	//public List<Equipment> findAllEquipmentList();
	//public List<Equipment> findEquipmentListByCondition(Equipment oModel);
	//public Equipment findEquipmentByByCondition(Equipment oModel);
	//public Equipment getEquipmentById(int id);
	//public Equipment getEquipmentModelById(int id);
	//public PageResultSet<Equipment> findPageEquipmentList(Equipment oModel, int page,int pageSize);
	//public Map<String, Object> getEquipmentList(int page,int pageSize);
	public Map<String, Object> getEquipmentList(String[] pageInfo, String[] sortInfo);
	public List<String> selectpkid(String areaid);
	
	public HashMap<String, Object> findEquipStatusTableItems(String nodeid);
	public HashMap<String, Object> findEquipStatusTableItems(String nodeid, String[] pageInfo, String[] sortInfo);//20171211
	public HashMap<String, Object> findEquipStatusTableItems0(String nodeid, String[] pageInfo, String[] sortInfo);//20171211
	
	public List<EquipStatusModel> findEquipLatestStatusList(String nodeid);
	public List<EquipStatusModel> findEquipStatusList(String nodeid);
	public AjaxResult findDatainfoSet(String pkid, String beginTime, String endTime);
	public List<String> listEquipIDs(String areaid, String companyid, String nodeid);
	List<Equipment> listEquips(String areaid, String companyid, String nodeid);
	public HashMap<String,Object> groupStatusList(String nodeid);
	HashMap<String, Object> findRuntimeStatus(String nodeid);
	HashMap<String, Object> findRuntimeStatus0(String nodeid);
	public AjaxResult countEquips(String nodeid);
	HashMap<String, Object> getLatestInfo(String nodeid);

}
