package com.monitor.model;

import java.util.Date;

public class RuntimeStatusModel {
	private Integer runningstatus = 1;
	private Integer auto = 1;
	private Integer shifting = 1;
	private Integer partalarm=0;
	private Integer temperalarm=0;
	private Integer topdown = 0;
	
	private Double firstsupplytemper;
	private Double firstbacktemper;
	private Double secondsupplytemper;
	private Double secondbacktemp;

	private Double freq_primary1;
	private Double freq_assistant1;
	private Double freq_primary2;
	private Double freq_assistant2;
	
	private String nodepkid;
	//private Date data_date;
	private String data_date;//对应前端runtimeStatus.data_date
	
	
	public String getData_date() {
		return data_date;
	}
	public void setData_date(String data_date) {
		this.data_date = data_date;
	}
	public Integer getTopdown() {
		return topdown;
	}
	public void setTopdown(Integer topdown) {
		this.topdown = topdown;
	}
	public String getNodepkid() {
		return nodepkid;
	}
	public void setNodepkid(String nodepkid) {
		this.nodepkid = nodepkid;
	}
	public void setFreq_assistant1(Double freq_assistant1) {
		this.freq_assistant1 = freq_assistant1;
	}
	public Double getFreq_primary1() {
		return freq_primary1;
	}
	public void setFreq_primary1(Double freq_primary1) {
		this.freq_primary1 = freq_primary1;
	}
	public Double getFreq_assistant1() {
		return freq_assistant1;
	}
	public void setFreq_assitant1(Double freq_assistant1) {
		this.freq_assistant1 = freq_assistant1;
	}
	public Double getFreq_primary2() {
		return freq_primary2;
	}
	public void setFreq_primary2(Double freq_primary2) {
		this.freq_primary2 = freq_primary2;
	}
	public Double getFreq_assistant2() {
		return freq_assistant2;
	}
	public void setFreq_assistant2(Double freq_assistant2) {
		this.freq_assistant2 = freq_assistant2;
	}
	public Double getFirstsupplytemper() {
		return firstsupplytemper;
	}
	public void setFirstsupplytemper(Double firstsupplytemper) {
		this.firstsupplytemper = firstsupplytemper;
	}
	public Double getFirstbacktemper() {
		return firstbacktemper;
	}
	public void setFirstbacktemper(Double firstbacktemper) {
		this.firstbacktemper = firstbacktemper;
	}
	public Double getSecondsupplytemper() {
		return secondsupplytemper;
	}
	public void setSecondsupplytemper(Double secondsupplytemper) {
		this.secondsupplytemper = secondsupplytemper;
	}
	public Double getSecondbacktemp() {
		return secondbacktemp;
	}
	public void setSecondbacktemp(Double secondbacktemp) {
		this.secondbacktemp = secondbacktemp;
	}
	public Integer getRunningstatus() {
		return runningstatus;
	}
	public void setRunningstatus(Integer runningstatus) {
		this.runningstatus = runningstatus;
	}
	public Integer getAuto() {
		return auto;
	}
	public void setAuto(Integer auto) {
		this.auto = auto;
	}
	public Integer getShifting() {
		return shifting;
	}
	public void setShifting(Integer shifting) {
		this.shifting = shifting;
	}
	public Integer getPartalarm() {
		return partalarm;
	}
	public void setPartalarm(Integer partalarm) {
		this.partalarm = partalarm;
	}
	public Integer getTemperalarm() {
		return temperalarm;
	}
	public void setTemperalarm(Integer temperalarm) {
		this.temperalarm = temperalarm;
	}


	@Override
	public String toString() {
		return "RuntimeStatusModel [runningstatus=" + runningstatus + ", auto="
				+ auto + ", shifting=" + shifting + ", partalarm=" + partalarm
				+ ", temperalarm=" + temperalarm + ", firstsupplytemper="
				+ firstsupplytemper + ", firstbacktemper=" + firstbacktemper
				+ ", secondsupplytemper=" + secondsupplytemper
				+ ", secondbacktemp=" + secondbacktemp + "]";
	}
	
	
	
	public RuntimeStatusModel(Double firstsupplytemper,
			Double firstbacktemper, Double secondsupplytemper,
			Double secondbacktemp) {
		super();
		this.firstsupplytemper = firstsupplytemper;
		this.firstbacktemper = firstbacktemper;
		this.secondsupplytemper = secondsupplytemper;
		this.secondbacktemp = secondbacktemp;
	}
	public RuntimeStatusModel(Integer runningstatus, Integer auto,
			Integer shifting, Integer partalarm, Integer temperalarm,
			Double firstsupplytemper, Double firstbacktemper,
			Double secondsupplytemper, Double secondbacktemp) {
		super();
		this.runningstatus = runningstatus;
		this.auto = auto;
		this.shifting = shifting;
		this.partalarm = partalarm;
		this.temperalarm = temperalarm;
		this.firstsupplytemper = firstsupplytemper;
		this.firstbacktemper = firstbacktemper;
		this.secondsupplytemper = secondsupplytemper;
		this.secondbacktemp = secondbacktemp;
	}
	public RuntimeStatusModel(Integer runningstatus, Integer auto, Integer shifting,
			Integer partalarm, Integer temperalarm) {
		super();
		this.runningstatus = runningstatus;
		this.auto = auto;
		this.shifting = shifting;
		this.partalarm = partalarm;
		this.temperalarm = temperalarm;
	}
	public RuntimeStatusModel(){
		super();
	}
	public RuntimeStatusModel(Integer runningstatus, Integer auto,
			Integer shifting, Integer partalarm, Integer temperalarm,
			Double firstsupplytemper, Double firstbacktemper,
			Double secondsupplytemper, Double secondbacktemp,
			Double freq_primary1, Double freq_assistant1, Double freq_primary2,
			Double freq_assistant2) {
		super();
		this.runningstatus = runningstatus;
		this.auto = auto;
		this.shifting = shifting;
		this.partalarm = partalarm;
		this.temperalarm = temperalarm;
		this.firstsupplytemper = firstsupplytemper;
		this.firstbacktemper = firstbacktemper;
		this.secondsupplytemper = secondsupplytemper;
		this.secondbacktemp = secondbacktemp;
		this.freq_primary1 = freq_primary1;
		this.freq_assistant1 = freq_assistant1;
		this.freq_primary2 = freq_primary2;
		this.freq_assistant2 = freq_assistant2;
	}
	public void setFreqs(Double freq_primary1, Double freq_assistant1, Double freq_primary2,
			Double freq_assistant2){
		this.freq_primary1 = freq_primary1;
		this.freq_assistant1 = freq_assistant1;
		this.freq_primary2 = freq_primary2;
		this.freq_assistant2 = freq_assistant2;
	}

}
