package com.monitor.model;

import java.io.Serializable;
import java.util.Date;

import com.monitor.entity.User;

public class UserModel implements Serializable {

	private static final long serialVersionUID = 3833817133782807122L;
	private Integer user_id;
	private String username;
	private String password;
	private Date onlinedate;
	private String sRoletype;
	private String isactive;
	private Integer area_id;
	private String province_name;
	private String city_name;
	private String region_name;
	
	
	public Integer getArea_id() {
		return area_id;
	}
	public void setArea_id(Integer area_id) {
		this.area_id = area_id;
	}
	public String getProvince_name() {
		return province_name;
	}
	public void setProvince_name(String province_name) {
		this.province_name = province_name;
	}
	public String getCity_name() {
		return city_name;
	}
	public void setCity_name(String city_name) {
		this.city_name = city_name;
	}
	public String getRegion_name() {
		return region_name;
	}
	public void setRegion_name(String region_name) {
		this.region_name = region_name;
	}
	public UserModel(User user){
		user_id = user.getId();
		username = user.getUsername();
		password = user.getPassword();
		this.setOnlinedate(getOnlinedate());
		this.setsRoletype(user.getRole());
	}

	public Integer getUser_id() {
		return user_id;
	}

	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getOnlinedate() {
		return onlinedate;
	}

	public void setOnlinedate(Date onlinedate) {
		this.onlinedate = onlinedate;
	}
	

	public String getsRoletype() {
		return sRoletype;
	}
	public void setsRoletype(String sRoletype) {
		this.sRoletype = sRoletype;
	}
	public String getIsactive() {
		return isactive;
	}
	public void setIsactive(String isactive) {
		this.isactive = isactive;
	}
	public UserModel() {
		super();
	}

	public UserModel(Integer id) {
		super();
		this.user_id = id;
	}

	public UserModel(String username) {
		super();
		this.username = username;
	}

	public UserModel(Integer id, String username) {
		super();
		this.user_id = id;
		this.username = username;
	}
	

	
}
