package com.monitor.model;

import java.util.Date;

public class NodeModel {
	private String areaname;
	private String areaid;
	private Integer nodeid;
	private String nodename;
	private String address;
	private String telephone;
	private String gpspos;
	private Date start_date;
	private String companycode;
	private String companyname;
	private String nodepkid;
	
	public String getNodepkid() {
		return nodepkid;
	}
	public void setNodepkid(String nodepkid) {
		this.nodepkid = nodepkid;
	}
	public String getAreaname() {
		return areaname;
	}
	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}
	public String getAreaid() {
		return areaid;
	}
	public void setAreaid(String areaid) {
		this.areaid = areaid;
	}
	public Integer getNodeid() {
		return nodeid;
	}
	public void setNodeid(Integer nodeid) {
		this.nodeid = nodeid;
	}
	public String getNodename() {
		return nodename;
	}
	public void setNodename(String nodename) {
		this.nodename = nodename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public String getGpspos() {
		return gpspos;
	}
	public void setGpspos(String gpspos) {
		this.gpspos = gpspos;
	}
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	@Override
	public String toString() {
		return "NodeModel ["+nodepkid+" areaname=" + areaname + ", areaid=" + areaid
				+ ", nodeid=" + nodeid + ", nodename=" + nodename
				+ ", address=" + address + ", telephone=" + telephone
				+ ", gpspos=" + gpspos + ", start_date=" + start_date
				+ ", companycode=" + companycode + ", companyname="
				+ companyname + "]";
	}
	public NodeModel() {
		super();
	}
	public NodeModel(String nodename) {
		super();
		this.nodename = nodename;
	}
	public NodeModel(Integer node) {
		super();
		this.nodeid = node;
	}
	public NodeModel(String nodepkid, boolean b) {
		super();
		this.nodepkid = nodepkid;
	}
	public NodeModel(String areaname, String areaid, Integer nodeid,
			String nodename, String address, String telephone, String gpspos,
			Date start_date,String nodepkid) {
		super();
		this.areaname = areaname;
		this.areaid = areaid;
		this.nodeid = nodeid;
		this.nodename = nodename;
		this.address = address;
		this.telephone = telephone;
		this.gpspos = gpspos;
		this.start_date = start_date;
		this.nodepkid = nodepkid;
	}
	
	
}
