package com.monitor.model;

public class CompanyModel {

}
