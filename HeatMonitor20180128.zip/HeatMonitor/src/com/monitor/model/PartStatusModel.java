package com.monitor.model;

import java.util.Date;

public class PartStatusModel {	
	private String pkid;
	private String colcode;
	private String selfcode;
	private String usercode;
	private String partstatus;
	private Integer partid;//deprecated
	
	public String getPkid() {
		return pkid;
	}
	public void setPkid(String pkid) {
		this.pkid = pkid;
	}
	public String getColcode() {
		return colcode;
	}
	public void setColcode(String colcode) {
		this.colcode = colcode;
	}
	public String getSelfcode() {
		return selfcode;
	}
	public void setSelfcode(String selfcode) {
		this.selfcode = selfcode;
	}
	public String getUsercode() {
		return usercode;
	}
	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}
	public String getPartstatus() {
		return partstatus;
	}
	public void setPartstatus(String partstatus) {
		this.partstatus = partstatus;
	}
	public Integer getPartid() {
		return partid;
	}
	public void setPartid(Integer partid) {
		this.partid = partid;
	}
	@Override
	public String toString() {
		return "PartStatusModel [colcode=" + colcode + ", selfcode=" + selfcode
				+ ", usercode=" + usercode + ", partstatus=" + partstatus + "]";
	}
	public PartStatusModel(String pkid, String colcode, String selfcode, 
			String usercode, String partstatus) {
		super();
		this.pkid = pkid;
		this.colcode = colcode;
		this.selfcode = selfcode;
		this.usercode = usercode;
		this.partstatus = partstatus;

	}
	public PartStatusModel() {
		super();
	}
	
	
}
