package com.monitor.model;

import java.util.Date;

public class EquipConfModel {
	private Integer equipconfid;
	private String nodeid;
	private String pkid;
	private Date confdate;
	private Double upboundtemperature;
	private Double lowboundtemperature;
	private Double convertingtemperature;
	private Double idealtemperature;
	private Integer automatic_manual;
	private String parts_runningstatus;
	
	public String getPkid() {
		return pkid;
	}
	public void setPkid(String pkid) {
		this.pkid = pkid;
	}
	public Integer getEquipconfid() {
		return equipconfid;
	}
	public void setEquipconfid(Integer equipconfid) {
		this.equipconfid = equipconfid;
	}
	public String getNodeid() {
		return nodeid;
	}
	public void setNodeid(String nodeid) {
		this.nodeid = nodeid;
	}
	public Date getConfdate() {
		return confdate;
	}
	public void setConfdate(Date confdate) {
		this.confdate = confdate;
	}
	public Double getUpboundtemperature() {
		return upboundtemperature;
	}
	public void setUpboundtemperature(Double upboundtemperature) {
		this.upboundtemperature = upboundtemperature;
	}
	public Double getLowboundtemperature() {
		return lowboundtemperature;
	}
	public void setLowboundtemperature(Double lowboundtemperature) {
		this.lowboundtemperature = lowboundtemperature;
	}
	public Double getConvertingtemperature() {
		return convertingtemperature;
	}
	public void setConvertingtemperature(Double convertingtemperature) {
		this.convertingtemperature = convertingtemperature;
	}
	public Double getIdealtemperature() {
		return idealtemperature;
	}
	public void setIdealtemperature(Double idealtemperature) {
		this.idealtemperature = idealtemperature;
	}
	public Integer getAutomatic_manual() {
		return automatic_manual;
	}
	public void setAutomatic_manual(Integer automatic_manual) {
		this.automatic_manual = automatic_manual;
	}
	public String getParts_runningstatus() {
		return parts_runningstatus;
	}
	public void setParts_runningstatus(String parts_runningstatus) {
		this.parts_runningstatus = parts_runningstatus;
	}
	@Override
	public String toString() {
		return "EquipConfModel [equipconfid=" + equipconfid + ", nodeid="
				+ nodeid + ", pkid = "+pkid+", confdate=" + confdate + ", upboundtemperature="
				+ upboundtemperature + ", lowboundtemperature="
				+ lowboundtemperature + ", convertingtemperature="
				+ convertingtemperature + ", idealtemperature="
				+ idealtemperature + ", automatic_manual=" + automatic_manual
				+ ", parts_runningstatus=" + parts_runningstatus + "]";
	}
	public EquipConfModel(Integer equipconfid, String nodeid,String pkid, Date confdate,
			Double upboundtemperature, Double lowboundtemperature,
			Double convertingtemperature, Double idealtemperature,
			Integer automatic_manual, String parts_runningstatus) {
		super();
		this.equipconfid = equipconfid;
		this.nodeid = nodeid;
		this.pkid = pkid;
		this.confdate = confdate;
		this.upboundtemperature = upboundtemperature;
		this.lowboundtemperature = lowboundtemperature;
		this.convertingtemperature = convertingtemperature;
		this.idealtemperature = idealtemperature;
		this.automatic_manual = automatic_manual;
		this.parts_runningstatus = parts_runningstatus;
	}
	public EquipConfModel() {
		super();
	}
	public EquipConfModel(String nodeid, String pkid, Date date,
			Double uptemper, Double lowtemper, Double convertemper,
			Double idealtemper) {
		this.nodeid = nodeid;
		this.pkid = pkid;
		this.confdate = date;
		this.upboundtemperature = uptemper;
		this.lowboundtemperature = lowtemper;
		this.convertingtemperature = convertemper;
		this.idealtemperature = idealtemper;
	}
	
}
