package com.monitor.model;

import java.util.ArrayList;
import java.util.Date;

public class EquipmentStatusModel {
	private Date data_date;
	private String pkid;
	private Double temperature;
	private Double waterlevel;
	private String valvetop;
	private String valvebottom;
	private ArrayList partlist = new ArrayList();
	public Date getData_date() {
		return data_date;
	}
	public void setData_date(Date data_date) {
		this.data_date = data_date;
	}
	public String getPkid() {
		return pkid;
	}
	public void setPkid(String pkid) {
		this.pkid = pkid;
	}
	public Double getTemperature() {
		return temperature;
	}
	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}
	public Double getWaterlevel() {
		return waterlevel;
	}
	public void setWaterlevel(Double waterlevel) {
		this.waterlevel = waterlevel;
	}
	public String getValvetop() {
		return valvetop;
	}
	public void setValvetop(String valvetop) {
		this.valvetop = valvetop;
	}
	public String getValvebottom() {
		return valvebottom;
	}
	public void setValvebottom(String valvebottom) {
		this.valvebottom = valvebottom;
	}
	public ArrayList getPartlist() {
		return partlist;
	}
	public void setPartlist(ArrayList partlist) {
		this.partlist = partlist;
	}
	@Override
	public String toString() {
		return "EquipmentStatusModel [data_date=" + data_date + ", pkid="
				+ pkid + ", temperature=" + temperature + ", waterlevel="
				+ waterlevel + ", valvetop=" + valvetop + ", valvebottom="
				+ valvebottom + ", partlist=" + partlist + "]";
	}
	public EquipmentStatusModel(Date data_date, String pkid,
			Double temperature, Double waterlevel, String valvetop,
			String valvebottom, ArrayList partlist) {
		super();
		this.data_date = data_date;
		this.pkid = pkid;
		this.temperature = temperature;
		this.waterlevel = waterlevel;
		this.valvetop = valvetop;
		this.valvebottom = valvebottom;
		this.partlist = partlist;
	}
	public EquipmentStatusModel(Date data_date, String pkid,
			Double temperature, Double waterlevel, String valvetop,
			String valvebottom) {
		super();
		this.data_date = data_date;
		this.pkid = pkid;
		this.temperature = temperature;
		this.waterlevel = waterlevel;
		this.valvetop = valvetop;
		this.valvebottom = valvebottom;
	}
	public EquipmentStatusModel() {
		super();
	}
	
}
