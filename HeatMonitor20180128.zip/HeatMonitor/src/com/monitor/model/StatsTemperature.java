package com.monitor.model;

import java.util.Date;

public class StatsTemperature {
	private String pkid;
	private Double temperature;
	private Date data_date;
	public String getPkid() {
		return pkid;
	}
	public void setPkid(String pkid) {
		this.pkid = pkid;
	}
	public Double getTemperature() {
		return temperature;
	}
	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}
	public Date getData_date() {
		return data_date;
	}
	public void setData_date(Date data_date) {
		this.data_date = data_date;
	}
	@Override
	public String toString() {
		return "StatsTemperature [pkid=" + pkid + ", temperature="
				+ temperature + ", data_date=" + data_date + "]";
	}
	public StatsTemperature(String pkid, Double temperature, Date data_date) {
		super();
		this.pkid = pkid;
		this.temperature = temperature;
		this.data_date = data_date;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result
				+ ((data_date == null) ? 0 : data_date.hashCode());
		result = prime * result + ((pkid == null) ? 0 : pkid.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		StatsTemperature other = (StatsTemperature) obj;
		if (data_date == null) {
			if (other.data_date != null)
				return false;
		} else if (!data_date.equals(other.data_date))
			return false;
		if (pkid == null) {
			if (other.pkid != null)
				return false;
		} else if (!pkid.equals(other.pkid))
			return false;		
		return true;
	}
	public StatsTemperature() {
		super();
	}
	
}
