package com.monitor.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.monitor.entity.Role;
import com.monitor.entity.User;
import com.monitor.model.RoleModel;
import com.monitor.model.UserModel;//---------------------------------
import com.monitor.service.UserService;
import com.monitor.util.AjaxResult;
import com.monitor.util.AppUtil;
import com.monitor.util.Constants;
import com.monitor.util.Util;

@Controller
@RequestMapping("/user")
//@RequestMapping("user")
public class UserController {

	@Resource
	private UserService userService;

//*******************************************USER***********************************************
	/*由usermanage页面获取用户列表信息,转入userController*///**************************************
	@RequestMapping(value="/userList", method=RequestMethod.POST)
	public @ResponseBody String getUserList(HttpServletRequest request){
		System.out.println("goto usermanage.jsp page!");
		
		String pagesize = request.getParameter("pageSize");
		String sPage = request.getParameter("pageNo");
		int pz = 10;
		if(!StringUtils.isBlank(pagesize)){
			pz = Integer.valueOf(pagesize);
		}		
		int page = 1;
		if (!StringUtils.isBlank(sPage)) {
			page = Integer.parseInt(sPage);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		//map = userService.getUserListByPage(page, pz);
		//根据登录显示可管理用户
		map = userService.getUserListByPage(page, pz, (UserModel)request.getSession().getAttribute(Constants.SESSION_USER));  //userServiceImp
		//---------------返回全部
		//List<User> list = userService.findAllUserList();
		//String json = object2Json(list);
		String json = AppUtil.object2Json(map);
		return json;
	}
	/*更新，修改姓名，电话*/
	@ResponseBody
	@RequestMapping(value="/updateUser", method=RequestMethod.POST)
	public AjaxResult updateUser(UserModel user){	
		return userService.updateUser(user);
	}
	/*删除*/
	@ResponseBody
	@RequestMapping(value = "/delUser")
	public AjaxResult delUser(@RequestParam String user_id) {
		return userService.deleteUser(user_id.split(","));		
	}
	/*初始化密码*/
	@ResponseBody
	@RequestMapping(value = "/initPassword")
	public AjaxResult initPW(@RequestParam String user_id) {
		return userService.updatePassword(new UserModel(user_id), "111111");		
	}
	/*添加*/	
	@RequestMapping(value = "/addUser")
	public ModelAndView loadAddUser(HttpServletRequest request, ModelAndView mv) {
		String id = request.getParameter("user_id");
		if(id!= null && StringUtils.isNumeric(id)){
			mv.addObject("user", userService.getUserModelById(Integer.parseInt(id)));
			mv.setViewName("user/updateUser");
		}
		else
			mv.setViewName("user/addUser");
		return mv;
	}
	@ResponseBody
	@RequestMapping(value = "/saveUser")
	public AjaxResult saveUser(UserModel user) {		
		return userService.addUser(user);	
	}
	@ResponseBody
	@RequestMapping(value = "/checkusername", method = RequestMethod.GET)
	public AjaxResult checkUserName(@RequestParam String username) throws IOException {	
		//return userService.checkUser(new UserModel(username));
		return userService.checkUser(username);
	}
//*****************************************ROLE**************************************************
	@ResponseBody
	@RequestMapping(value = "/checkrolename", method = RequestMethod.GET)
	/*public AjaxResult checkRoleName(Role role) throws IOException {	
		return userService.checkRole(role);
	}*/
	public AjaxResult checkRoleName(@RequestParam String name) throws IOException {
		return userService.checkRole(new Role(name));//user defindes object cannot use sessionFactory, sessionFactory = null
	}
	@ResponseBody
	@RequestMapping(value = "/saveRole")
	public AjaxResult saveRole(Role role) {		
		return userService.addRole(role);	
	}
	/*添加角色*/	
	@RequestMapping(value = "/addRole")
	public ModelAndView loadAddRole(HttpServletRequest request, ModelAndView mv) {
		String id = request.getParameter("role_id");
		if(id!= null && Util.isNumber(id)){
			mv.addObject("role", userService.getRoleById(Integer.parseInt(id)));
			mv.setViewName("user/updateRole");
		}
		else
			mv.setViewName("user/addRole");
		return mv;
	}
	/*更新角色描述*/
	@ResponseBody
	@RequestMapping(value="/updateRole", method=RequestMethod.POST)
	public AjaxResult updateRole(Role role){	
		return userService.updateRole(role);
	}
	/*删除*/
	@ResponseBody
	@RequestMapping(value = "/delRole")
	public AjaxResult delRole(@RequestParam String role_id) {
		return userService.deleteRole(role_id);		
	}
	@RequestMapping(value="/roleList", method=RequestMethod.POST)
	public @ResponseBody String getRoleList(Role role, HttpServletRequest request){
		System.out.println("goto rolemanage.jsp page!");
		
		String pagesize = request.getParameter("pageSize");
		String sPage = request.getParameter("pageNo");
		int pz = 10;
		if(!StringUtils.isBlank(pagesize)){
			pz = Integer.valueOf(pagesize);
		}		
		int page = 1;
		if (!StringUtils.isBlank(sPage)) {
			page = Integer.parseInt(sPage);
		}
		Map<String, Object> map = new HashMap<String, Object>();
		//m = userService.findPageUserList(userModel, page, pageSize)
		map = userService.getRoleListByPage(role, page, pz);  //userServiceImp
		//---------------返回全部
		//List<User> list = userService.findAllRoleList();
		//String json = object2Json(list);
		String json = AppUtil.object2Json(map);
		return json;
	}
	@RequestMapping(value = "/authorizeRole")
	public ModelAndView authorizeRole(HttpServletRequest request, ModelAndView mv) {
		String role_id = request.getParameter("role_id");
		RoleModel role=new RoleModel(role_id);
		//role.setRole_id(role_id);
		//List<RoleModel> menulist = userService.listAllMenus();		
		//List<RoleModel> rolemenulist= userService.listRoleMenusById(role);		
		//ModelAndView mv = new ModelAndView();
		mv.setViewName("user/menuRole");
		mv.addObject("menulist", userService.listAllMenus());
		mv.addObject("rolemenulist", userService.listRoleMenusById(role));
		mv.addObject("role_id", role_id);
		return mv; 
	}
	@ResponseBody
	@RequestMapping(value = "/saveAuthorizeMenu")//save menu	
	public AjaxResult saveAuthorizeRoleMenu(@RequestParam String role_id, @RequestParam String menu_id){		
		return userService.saveAuthorizeMenu(role_id, menu_id);	
	}
	@ResponseBody
	@RequestMapping(value = "/saveAuthorizeRole")//save role permission
	public AjaxResult saveAuthorizeRole(@RequestParam String role_id,@RequestParam String user_id,@RequestParam String role_type){
		return userService.saveAuthorizeRole(role_id, user_id, role_type);
	}
	@RequestMapping(value = "/changeUserRole")
	public ModelAndView goRoleChange(HttpServletRequest request, ModelAndView mv) {
		String user_id = request.getParameter("user_id");
		//String user_roletype = request.getParameter("user_roletype");//--------------------

		UserModel user= userService.getUserModelById(Integer.parseInt(user_id));//new UserModel();
		//String user_roletype=user.getRoletype().toString();
		
		List<UserModel> userrolelist= userService.getUserRole(user);
		List<RoleModel> rolelist = userService.listAllRoles();

		mv.setViewName("user/changeUserRole");
		mv.addObject("roletype", user.getsRoletype());//user_roletype);//------------------------------------------
		mv.addObject("rolelist", rolelist);
		mv.addObject("userrolelist", userrolelist);
		mv.addObject("user", user);
		return mv; 
	}

}
