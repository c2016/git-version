package com.monitor.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.monitor.entity.Datainfo;
import com.monitor.model.UserModel;
import com.monitor.service.AreaService;
import com.monitor.service.DatainfoService;
import com.monitor.service.EquipmentService;
import com.monitor.service.UserService;
import com.monitor.util.AjaxResult;
import com.monitor.util.AppUtil;
import com.monitor.util.Constants;

@Controller
@RequestMapping("/equipment")
public class EquipmentController {
	@Resource
	UserService userService;
	@Resource
	AreaService areaService;
	@Resource
	EquipmentService equipmentService;
	@Resource
	DatainfoService datainfoService;
	@Resource
	EquipmentService equipStatusService;
	
	@RequestMapping(value="/getEquipmentTable",  method = {RequestMethod.GET, RequestMethod.POST})
	public  String  getEquipTable(HttpServletRequest request, Model model ){
		model.addAttribute(equipStatusService.findEquipLatestStatusList(request.getParameter("nodeid").toString()));
		return "node/equipStatusList";
	}
	@ResponseBody  /*Deprecated*/
	@RequestMapping(value="/getEquipmentDataTable",  method = {RequestMethod.GET, RequestMethod.POST})
	public  String getEquipmentDataTable(HttpServletRequest request, Model model ){
		HashMap<String, Object> map = null;
		//findEquipStatusTableItems  read from datainfo
		map = equipStatusService.findEquipStatusTableItems0(request.getParameter("nodeid").toString(),
				new String[]{request.getParameter("pageSize"), request.getParameter("pageNo")}, 
				new String[] {request.getParameter("sortName"), request.getParameter("sortOrder")});
		System.out.println(map);
		String json = AppUtil.object2Json(map);
		return json; 
	}
	@ResponseBody
	@RequestMapping(value="/getDatainfoSet",  method = {RequestMethod.GET, RequestMethod.POST})
	public  AjaxResult getEquipDataInfoSet(HttpServletRequest request, Model model ){
System.out.println(request.getParameter("pkid").toString());	
System.out.println(request.getParameter("beginTime").toString());
System.out.println(request.getParameter("endTime").toString());
		return equipmentService.findDatainfoSet(request.getParameter("pkid").toString(),
				request.getParameter("beginTime").toString(),
				request.getParameter("endTime").toString());
	}
	
	@ResponseBody
	@RequestMapping(value="/getEquipPKID",  method = {RequestMethod.GET, RequestMethod.POST})
	public  AjaxResult getEquipPKID(HttpServletRequest request){
System.out.println(request.getParameter("nodeid").toString());	
		List<String> list = equipmentService.listEquipIDs(null, null, request.getParameter("nodeid").toString());
		if(list.size()>0){
			return new AjaxResult(1,"找到设备列表", list);
		}else{
			return new AjaxResult("没找到设备");
		}
	}
	
	
	@RequestMapping(value="/loadEquipStatusList",  method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody String  getEquipStatusList(HttpServletRequest request, Model model ){
		String provID = (String)request.getParameter("provID");
		String cityID = (String)request.getParameter("cityID");
		String regionID = (String)request.getParameter("regionID");
		UserModel user = (UserModel)request.getSession().getAttribute(Constants.SESSION_USER); 
		HashMap<String, Object> map = null;//equipStatusService.findEquipStatusList(user, provID, cityID, regionID,
				//new String[]{request.getParameter("pageSize"), request.getParameter("pageNo")}, 
				//new String[] {request.getParameter("sortName"), request.getParameter("sortOrder")});  //userServiceImp

		String json = AppUtil.object2Json(map);
		return json; 
	}
	@RequestMapping("/getEquipList")	
	public @ResponseBody String  getEquipList(HttpServletRequest request){
	//public @ResponseBody Model  getEquipList(HttpServletRequest request, Model model){
		Map<String, Object> map = new HashMap<String, Object>();
		map = equipmentService.getEquipmentList(new String[]{request.getParameter("pageSize"), request.getParameter("pageNo")}, 
												new String[] {request.getParameter("sortName"), request.getParameter("sortOrder")});  //userServiceImp
		String json = AppUtil.object2Json(map);
		return json;		
	}
	@RequestMapping(value="/loadRunningStatus", method = RequestMethod.POST)	
	public  @ResponseBody Map<String,Object> loadStatus(HttpServletRequest request) throws IOException{
		Map<String, Object> map = new HashMap<String, Object>();		
		String pkid = request.getParameter("pkid");		
		Datainfo datainfo = datainfoService.getByPKID(pkid);
		if(datainfo != null){	
			map.put("status","found");	
			map.put("datainfo", datainfo);
		}
		else{
			map.put("status","not found");
		}
		return map;
	}
	@RequestMapping(value="/loadNewEquipment", method = RequestMethod.POST)	
	public  @ResponseBody AjaxResult loadNewEquipment(HttpServletRequest request) throws IOException{	
		String pkid = (String) request.getParameter("pkid");
		if(StringUtils.isBlank(pkid)){
			return new AjaxResult(0, "设备号不能为空");
		}else
			return datainfoService.getNewEquipByID(pkid);	
	}
	

	@ResponseBody
	@RequestMapping(value="/getCount", method=RequestMethod.GET)
	public AjaxResult getCount(HttpServletRequest request, HttpServletResponse response){
		System.out.println("count equipments!");
		String nodeid = request.getParameter("nodeid");
		return equipmentService.countEquips(nodeid);
	}
	/*equipStatusList.jsp table*/
	@ResponseBody
	@RequestMapping(value="/getEquipDataTable",  method = {RequestMethod.GET, RequestMethod.POST})
	public  String getEquipDataTable(HttpServletRequest request, Model model ){
		HashMap<String, Object> map = equipStatusService.findEquipStatusTableItems(request.getParameter("nodeid").toString(),
				new String[]{request.getParameter("pageSize"), request.getParameter("pageNo")}, 
				new String[] {request.getParameter("sortName"), request.getParameter("sortOrder")});
		return AppUtil.object2Json(map);
	}
}
