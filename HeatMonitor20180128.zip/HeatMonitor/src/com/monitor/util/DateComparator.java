package com.monitor.util;

import java.util.Comparator;

import com.monitor.model.StatsTemperature;

public class DateComparator implements Comparator<StatsTemperature> {
	public int compare(StatsTemperature o1, StatsTemperature o2){
		if(o1.getData_date().getTime()>o2.getData_date().getTime())
			return 1;
		return -1;		
	}
}
