package com.monitor.util;

public class Constants {

	public static String LOGIN_NORMAL_USER; // 登录用户
	public static String LOGIN_ADMIN_USER; // 登录管理员
	public static String LOGIN_TOURIST_USER;
	public static String LOGIN_USER = "username";
	public static String SESSION_USER = "loginuser";
	public final static int PAGE_SIZE = 10; // 分页 一页显示的行数

	public static String SESSION_SECURITY_CODE = "randCheckCode";
	public static String NO_INTERCEPTOR_PATH = ".*/((index)|(checkCode/*)|(plugins/*)).*";
	//public static String NO_INTERCEPTOR_PATH = ".*/((index)|(checkCode/*)|(plugins/*)|(css/*)|(img/*)|(js/*)).*";
}
