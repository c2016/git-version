package com.monitor.util;

import java.text.SimpleDateFormat;
import org.apache.commons.lang.StringUtils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

public class AppUtil {

	public static String object2Json(Object object) {
        ObjectMapper mapper = new ObjectMapper();
        String json = null;
        try {
			SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
			mapper.setDateFormat(fmt);  
            json = mapper.writeValueAsString(object);
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return json;
    }
	public static int[] setStartPage(String... p){
		int m =10, n =1;// m:numRows; n:firstRow
		if(!StringUtils.isBlank(p[0])){//p[0]:pagesize->numRows
			m = Integer.valueOf(p[0]);
		}		
		if (!StringUtils.isBlank(p[1])) {//p[1]:pageNo->firstRow
			n = (Integer.parseInt(p[1]) - 1)*m;
		}		
		return  new int[]{n, m};
	}	
	public static int[] setStartPage(int defaultSize, int defaultPage, String... p){
		int m =defaultSize, n =defaultPage;// m:numRows; n:firstRow
		if(!StringUtils.isBlank(p[0])){//p[0]:pagesize->numRows
			m = Integer.valueOf(p[0]);
		}		
		if (!StringUtils.isBlank(p[1])) {//p[1]:pageNo->firstRow
			n = (Integer.parseInt(p[1]) - 1)*m;
		}		
		return  new int[]{n, m};
	}
}
