function warningmessage(msg){
	console.log("warningmsg="  +  msg);
	$("#warningmsg span").html(msg);
	$("#warningmsg").css("display", "block");
}	
function closeWarning(){
	$("#warningmsg").css("display","none");
}