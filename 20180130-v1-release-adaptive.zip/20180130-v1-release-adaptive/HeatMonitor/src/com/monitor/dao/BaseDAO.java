package com.monitor.dao;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import org.hibernate.type.Type;


public interface BaseDAO<T> {
	public List<T> find4(String hql, Object[] param);
	public T get4(String hql, Object[] param);
	public T get4(String hql, List<Object> param);
	//****************************
	public Serializable save(T o);

	public int delete(T o);

	public int update(T o);

	public int saveOrUpdate(T o);

	public List<T> find(String hql);

	public List<T> find(String hql, Object[] param);

	public List<T> find(String hql, List<Object> param);

	public List<T> find(String hql, Object[] param, Integer page, Integer rows);

	public List<T> find(String hql, List<Object> param, Integer page,
			Integer rows);

	public T get(Class<T> c, Serializable id);

	public T get(String hql, Object[] param);

	public T get(String hql, List<Object> param);

	public Long count(String hql);

	public Long count(String hql, Object[] param);

	public Long count(String hql, List<Object> param);

	public Integer executeHql(String hql);

	public Integer executeHql(String hql, Object[] param);

	public Integer executeHql(String hql, List<Object> param);
	//使用原生sql
		public T getBySQL(String sql);					//需要写子类
		public List<T> findListBySQL(String sql);
		public Integer updateBySQL(String sql);
		
		public T getBySQL(String sql, Class<T> entity);	//不需要写子类
		public List<T> findListBySQL(String sql, Class<T> entity);
		public Integer updateBySQL(String sql, Class<T> entity);
		
		public T getObjectBySQL(String sql);
		public List<T> findObjectBySQL(String sql);
		public int updateObjectBySQL(String sql);
		public List<T> findObjectBySQL(String sql, int firstRow, int numRows);
		
		@SuppressWarnings("rawtypes")
		public List findBySQL(String sql);
		@SuppressWarnings("rawtypes")
		public List findListBySQL(String sql, Map<String, Type> types, int firstRow, int numRows);
		@SuppressWarnings("rawtypes")
		public List findBySQL(String sql, int firstRow, int numRows);
		
		public long countBySQL(String sql);
		;
}
