package com.monitor.dao.impl;

import java.io.Serializable;
import java.lang.reflect.ParameterizedType;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.transform.Transformers;
import org.hibernate.type.Type;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.monitor.dao.BaseDAO;

@SuppressWarnings("all")
@Repository
public class BaseDAOImpl<T> implements BaseDAO<T> {

	private SessionFactory sessionFactory;

	public SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	@Autowired
	public void setSessionFactory(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	private Session getCurrentSession() {
		return sessionFactory.getCurrentSession();
	}

	public Serializable save(T o) {
		return this.getCurrentSession().save(o);
	}

	public int delete(T o) {
		try{
			this.getCurrentSession().delete(o);
			return 1;
		}
		catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}

	public int update(T o) {
		try{
			this.getCurrentSession().update(o);
			return 1;
		}catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}

	public int saveOrUpdate(T o) {
		try{
			this.getCurrentSession().saveOrUpdate(o);
			return 1;
		}
		catch(Exception e){
			e.printStackTrace();
			return 0;
		}
	}

	public List<T> find(String hql) {
		return this.getCurrentSession().createQuery(hql).list();
	}
	//2017---begin
	public List<T> find4(String hql, Object[] param) {//Hibernate4
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				q.setParameter(String.valueOf(i), param[i]);
			}
		}
		return q.list();
	}
	public T get4(String hql, Object[] param) {
		/*List<T> l = this.find4(hql, param);
		if (l != null && l.size() > 0) {
			return l.get(0);
		} else {
			return null;
		}*/
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				q.setParameter(String.valueOf(i), param[i]);
			}
		}
		return (T)q.uniqueResult();
	}
	public T get4(String hql, List<Object> param) {
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.size() > 0) {
			for (int i = 0; i < param.size(); i++) {
				q.setParameter(String.valueOf(i), param.get(i));
			}
		}
		return (T)q.uniqueResult();
	}
	//2017--end
	public List<T> find(String hql, Object[] param) {
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				q.setParameter(i, param[i]);
			}
		}
		return q.list();
	}

	public List<T> find(String hql, List<Object> param) {
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.size() > 0) {
			for (int i = 0; i < param.size(); i++) {
				q.setParameter(i, param.get(i));
			}
		}
		return q.list();
	}

	public List<T> find(String hql, Object[] param, Integer page, Integer rows) {
		if (page == null || page < 1) {
			page = 1;
		}
		if (rows == null || rows < 1) {
			rows = 10;
		}
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				q.setParameter(i, param[i]);
			}
		}
		return q.setFirstResult((page - 1) * rows).setMaxResults(rows).list();
	}

	public List<T> find(String hql, List<Object> param, Integer page,
			Integer rows) {
		if (page == null || page < 1) {
			page = 1;
		}
		if (rows == null || rows < 1) {
			rows = 10;
		}
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.size() > 0) {
			for (int i = 0; i < param.size(); i++) {
				q.setParameter(i, param.get(i));
			}
		}
		return q.setFirstResult((page - 1) * rows).setMaxResults(rows).list();
	}

	public T get(Class<T> c, Serializable id) {
		return (T) this.getCurrentSession().get(c, id);
	}

	public T get(String hql, Object[] param) {
		List<T> l = this.find(hql, param);
		if (l != null && l.size() > 0) {
			return l.get(0);
		} else {
			return null;
		}
	}
	

	public T get(String hql, List<Object> param) {
		/*List<T> l = this.find(hql, param);
		if (l != null && l.size() > 0) {
			return l.get(0);
		} else {
			return null;
		}*/
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.size() > 0) {
			for (int i = 0; i < param.size(); i++) {
				q.setParameter(i, param.get(i));
			}
		}
		return (T)q.uniqueResult();
	}

	public Long count(String hql) {
		// return (Long)
		// this.getCurrentSession().createQuery(hql).uniqueResult();
		return new Long((long) this.getCurrentSession().createQuery(hql).list()
				.size());
	}

	public Long count(String hql, Object[] param) {
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				q.setParameter(i, param[i]);
			}
		}
		int size = q.list().size();
		return new Long((long) size);
	}

	public Long count(String hql, List<Object> param) {
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.size() > 0) {
			for (int i = 0; i < param.size(); i++) {
				q.setParameter(i, param.get(i));
			}
		}
		int size = q.list().size();
		return new Long((long) size);
	}

	public Integer executeHql(String hql) {
		return this.getCurrentSession().createQuery(hql).executeUpdate();
	}

	public Integer executeHql(String hql, Object[] param) {
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.length > 0) {
			for (int i = 0; i < param.length; i++) {
				q.setParameter(i, param[i]);
			}
		}
		return q.executeUpdate();
	}

	public Integer executeHql(String hql, List<Object> param) {
		Query q = this.getCurrentSession().createQuery(hql);
		if (param != null && param.size() > 0) {
			for (int i = 0; i < param.size(); i++) {
				q.setParameter(i, param.get(i));
			}
		}
		return q.executeUpdate();
	}
	//原生sql

		@Override
		public Integer updateBySQL(String sql) {
			// TODO Auto-generated method stub
			return this.getCurrentSession().createSQLQuery(sql).executeUpdate();
		}

		@Override
		public T getBySQL(String sql) {
			// TODO Auto-generated method stub
			List<T> l = this.findListBySQL(sql);
			if( l != null && l.size()  > 0)
				return l.get(0);
			return null;
		}

		@Override
		public List<T> findListBySQL(String sql) {
			// TODO Auto-generated method stub
			ParameterizedType p = (ParameterizedType) getClass().getGenericSuperclass();
			return this.getCurrentSession().createSQLQuery(sql).addEntity((Class)p.getActualTypeArguments()[0]).list();
			/*
			 * 	private Class entityT;	
			public BaseDAOImpl(){
			ParameterizedType p = (ParameterizedType) this.getClass().getGenericSuperclass();
			this.entityT = (Class) p.getActualTypeArguments()[0];
			}
			return this.getCurrentSession().createSQLQuery(sql).addEntity(entityT).list();
			 */
			
		}
		public T getBySQL(String sql, Class<T> entity) {
			// TODO Auto-generated method stub
			List<T> l = this.findListBySQL(sql, entity);
			if( l != null && l.size()  > 0)
				return l.get(0);
			return null;
		}
		public List<T> findListBySQL(String sql, Class<T> entity) {
			return this.getCurrentSession().createSQLQuery(sql).addEntity(entity).list();
		}

		@Override
		public Integer updateBySQL(String sql, Class<T> entity) {
			// TODO Auto-generated method stub
			return this.getCurrentSession().createSQLQuery(sql).addEntity(entity).executeUpdate();
		}
		
		public T getObjectBySQL(String sql) {
			// TODO Auto-generated method stub
			List<T> l=this.findObjectBySQL(sql);
			if(l != null && l.size()>0)
				return l.get(0);
			else
				return null;
		}
		public List<T> findObjectBySQL(String sql) {
			// TODO Auto-generated method stub
			return this.getCurrentSession().createSQLQuery(sql).list();
		}
		public int updateObjectBySQL(String sql) {
			// TODO Auto-generated method stub
			return this.getCurrentSession().createSQLQuery(sql).executeUpdate();
		}

		@Override
		public List findBySQL(String sql) {
			// TODO Auto-generated method stub
		System.out.println("findBySQL without page info");
			SQLQuery query = this.getCurrentSession().createSQLQuery(sql);
			query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			return query.list();
		}

		@Override
		public List findListBySQL(String sql,
				Map<String, org.hibernate.type.Type> types, int firstRow,
				int numRows) {
			// TODO Auto-generated method stub
			SQLQuery sqlQuery = this.getCurrentSession().createSQLQuery(sql);
			for (Map.Entry<String, Type> kvp : types.entrySet()) {
				sqlQuery.addScalar(kvp.getKey(), kvp.getValue());
			}		
			sqlQuery.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			
			if (firstRow >= 0 && numRows > 0) {
				sqlQuery.setFirstResult(firstRow);
				sqlQuery.setMaxResults(numRows);
			}
			
			return sqlQuery.list();
		}

		@Override
		public List<T> findBySQL(String sql, int firstRow, int numRows) {
			// TODO Auto-generated method stub
		System.out.println("findBySQL with page info: " + firstRow + ", " + numRows);
			SQLQuery query = this.getCurrentSession().createSQLQuery(sql);
			query.setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP);
			if(firstRow >= 0 && numRows > 0)
				query.setFirstResult(firstRow).setMaxResults(numRows);
			return query.list();
		}

		@Override
		public List<T> findObjectBySQL(String sql, int firstRow, int numRows) {
			// TODO Auto-generated method stub
			SQLQuery query = this.getCurrentSession().createSQLQuery(sql);		
			if(firstRow >= 0 && numRows > 0)
				query.setFirstResult(firstRow).setMaxResults(numRows);
			return query.list();
		}

		@Override
		public long countBySQL(String sql) {
			// TODO Auto-generated method stub
			return Long.parseLong((this.getCurrentSession().createSQLQuery(sql).uniqueResult()).toString());
		}
}
