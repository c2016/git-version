package com.monitor.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import com.monitor.model.UserModel;
import com.monitor.util.Constants;

public class LoginHandlerInterceptor extends HandlerInterceptorAdapter {
	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
		
		String path = request.getServletPath();
	System.out.println(path);
		if(path.matches(Constants.NO_INTERCEPTOR_PATH)){
			return true;
		}else{
			HttpSession session = request.getSession();
			UserModel user = (UserModel)session.getAttribute(Constants.SESSION_USER);
			System.out.println(user);System.out.println("from interceptor");
			if(user!=null){
				return true;
			}else{
				response.sendRedirect(request.getContextPath()+"/index");
				return false;
			}
		}
	}
}
