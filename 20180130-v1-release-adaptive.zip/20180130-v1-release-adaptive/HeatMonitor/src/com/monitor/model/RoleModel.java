package com.monitor.model;

import java.util.Arrays;

public class RoleModel {
	private String role_id;
	private String name;
	private String des;
	private String active;
	private String[] role_ids;
	private String menu_id;
	private String menu_name;
	private String menu_pid;
	private String user_id;
	private String roletype;//user中的roletype
	
	@Override
	public String toString() {
		return "RoleModel [role_id=" + role_id + ", name=" + name + ", des="
				+ des + ", active=" + active + ", role_ids="
				+ Arrays.toString(role_ids) + ", menu_id=" + menu_id
				+ ", menu_name=" + menu_name + ", menu_pid=" + menu_pid
				+ ", user_id=" + user_id + ", roletype=" + roletype + "]";
	}

	public String getRoletype() {
		return roletype;
	}

	public void setRoletype(String roletype) {
		this.roletype = roletype;
	}
	
	public RoleModel(String role_id, String name, String des, String active,
			String[] role_ids, String menu_id, String menu_name,
			String menu_pid, String user_id, String roletype) {
		super();
		this.role_id = role_id;
		this.name = name;
		this.des = des;
		this.active = active;
		this.role_ids = role_ids;
		this.menu_id = menu_id;
		this.menu_name = menu_name;
		this.menu_pid = menu_pid;
		this.user_id = user_id;
		this.roletype = roletype;
	}

	public RoleModel() {
		super();
	}

	public RoleModel(String role_id) {
		super();
		this.role_id = role_id;
	}

	public String getUser_id() {
		return user_id;
	}
	public void setUser_id(String user_id) {
		this.user_id = user_id;
	}
	public String getMenu_pid() {
		return menu_pid;
	}
	public void setMenu_pid(String menu_pid) {
		this.menu_pid = menu_pid;
	}
	public String getMenu_id() {
		return menu_id;
	}
	public void setMenu_id(String menu_id) {
		this.menu_id = menu_id;
	}
	public String getMenu_name() {
		return menu_name;
	}
	public void setMenu_name(String menu_name) {
		this.menu_name = menu_name;
	}
	public String[] getRole_ids() {
		return role_ids;
	}
	public void setRole_ids(String[] role_ids) {
		this.role_ids = role_ids;
	}
	public String getRole_id() {
		return role_id;
	}
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}

	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	public String getActive() {
		return active;
	}
	public void setActive(String active) {
		this.active = active;
	}
}
