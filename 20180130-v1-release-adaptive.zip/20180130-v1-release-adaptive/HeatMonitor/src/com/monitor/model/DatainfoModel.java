package com.monitor.model;

import java.util.Date;

public class DatainfoModel {
	private Integer id;
	private String equipmentid;
	private String state1;
	private String state2;
	private String state3;
	private String state4;
	private String state5;
	private String state6;
	private String state7;
	private String state8;
	private String state9;
	private String state10;
	private Double state11;
	private Double state12;
	private Double state13;
	private Double state14;
	private Double state15;
	private Double state16;
	private Double state17;
	private Double state18;
	private Double state19;
	private Double state20;
	private Date data_date;
	private Integer status;
	private String companyname;
	private String companyid;
	public DatainfoModel(Integer id, String equipid, String state1, String cname, String cid){
		super();
		this.companyid = cid;
		this.companyname = cname;
		this.id = id;
		this.equipmentid = equipid;
		this.state1 = state1;
	}
	@Override
	public String toString() {
		return "DatainfoModel [id=" + id + ", equipmentid=" + equipmentid
				+ ", state1=" + state1
				+ ", state2=" + state2 + ", state3=" + state3
				+ ", state4=" + state4 + ", state5=" + state5
				+ ", state6=" + state6 + ", state7=" + state7
				+ ", state8=" + state8 + ", state9=" + state9
				+ ", state10=" + state10 + ", state11=" + state11
				+ ", state12=" + state12 + ", state13=" + state13
				+ ", state14=" + state14 + ", state15=" + state15
				+ ", state16=" + state16 + ", state17=" + state17
				+ ", state18=" + state18 + ", state19=" + state19
				+ ", state20=" + state20 + ", data_date=" + data_date
				+ ", status=" + status + ", companyname=" + companyname
				+ ", companyid=" + companyid + "]";
	}
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getEquipmentid() {
		return equipmentid;
	}
	public void setEquipmentid(String equipmentid) {
		this.equipmentid = equipmentid;
	}
	public String getState1() {
		return state1;
	}
	public void setState1(String state1) {
		this.state1 = state1;
	}
	public String getState2() {
		return state2;
	}
	public void setState2(String state2) {
		this.state2 = state2;
	}
	public String getState3() {
		return state3;
	}
	public void setState3(String state3) {
		this.state3 = state3;
	}
	public String getState4() {
		return state4;
	}
	public void setState4(String state4) {
		this.state4 = state4;
	}
	public String getState5() {
		return state5;
	}
	public void setState5(String state5) {
		this.state5 = state5;
	}
	public String getState6() {
		return state6;
	}
	public void setState6(String state6) {
		this.state6 = state6;
	}
	public String getState7() {
		return state7;
	}
	public void setState7(String state7) {
		this.state7 = state7;
	}
	public String getState8() {
		return state8;
	}
	public void setState8(String state8) {
		this.state8 = state8;
	}
	public String getState9() {
		return state9;
	}
	public void setState9(String state9) {
		this.state9 = state9;
	}
	public String getState10() {
		return state10;
	}
	public void setState10(String state10) {
		this.state10 = state10;
	}
	public Double getState11() {
		return state11;
	}
	public void setState11(Double state11) {
		this.state11 = state11;
	}
	public Double getState12() {
		return state12;
	}
	public void setState12(Double state12) {
		this.state12 = state12;
	}
	public Double getState13() {
		return state13;
	}
	public void setState13(Double state13) {
		this.state13 = state13;
	}
	public Double getState14() {
		return state14;
	}
	public void setState14(Double state14) {
		this.state14 = state14;
	}
	public Double getState15() {
		return state15;
	}
	public void setState15(Double state15) {
		this.state15 = state15;
	}
	public Double getState16() {
		return state16;
	}
	public void setState16(Double state16) {
		this.state16 = state16;
	}
	public Double getState17() {
		return state17;
	}
	public void setState17(Double state17) {
		this.state17 = state17;
	}
	public Double getState18() {
		return state18;
	}
	public void setState18(Double state18) {
		this.state18 = state18;
	}
	public Double getState19() {
		return state19;
	}
	public void setState19(Double state19) {
		this.state19 = state19;
	}
	public Double getState20() {
		return state20;
	}
	public void setState20(Double state20) {
		this.state20 = state20;
	}
	public Date getData_date() {
		return data_date;
	}
	public void setData_date(Date data_date) {
		this.data_date = data_date;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getCompanyid() {
		return companyid;
	}
	public void setCompanyid(String companyid) {
		this.companyid = companyid;
	}
	public DatainfoModel() {
		super();
	}
	public DatainfoModel(Integer id) {
		super();
		this.id = id;
	}
	
}
