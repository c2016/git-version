package com.monitor.model;

import java.util.Date;

public class EquipStatusModel {
	private String areaname;
	private Integer areaid;
	private String nodeid;
	private String nodename;
	private String address;
	private String telephone;
	private Date start_date;
	private String gpspos; 
	private String companycode; 
	private String companyname; 
	private Integer dataid;
	private String pkid;
	private Date data_date;
	private Double degree1;
	private Double degree2;
	private String data1;
	private String data2;
	private String selfcode;//绘图使用的自定义排序自左向右，第一列从上到下，第二列从上到下......
	private String usercode;//用户实际排序
	private Double temperature;//水箱温度
	private Integer partid;
	private String partstatus;//表格使用中文，canvas使用数值型
	private String colcode;
	
	
	
	
	public String getPartstatus() {
		return partstatus;
	}
	public void setPartstatus(String partstatus) {
		this.partstatus = partstatus;
	}
	public String getAreaname() {
		return areaname;
	}
	public void setAreaname(String areaname) {
		this.areaname = areaname;
	}
	public Integer getAreaid() {
		return areaid;
	}
	public void setAreaid(Integer areaid) {
		this.areaid = areaid;
	}
	public String getNodeid() {
		return nodeid;
	}
	public void setNodeid(String nodeid) {
		this.nodeid = nodeid;
	}
	public String getNodename() {
		return nodename;
	}
	public void setNodename(String nodename) {
		this.nodename = nodename;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	public Integer getDataid() {
		return dataid;
	}
	public void setDataid(Integer dataid) {
		this.dataid = dataid;
	}
	public String getPkid() {
		return pkid;
	}
	public void setPkid(String pkid) {
		this.pkid = pkid;
	}
	public Date getData_date() {
		return data_date;
	}
	public void setData_date(Date data_date) {
		this.data_date = data_date;
	}
	public Double getDegree1() {
		return degree1;
	}
	public void setDegree1(Double degree1) {
		this.degree1 = degree1;
	}
	public Double getDegree2() {
		return degree2;
	}
	public void setDegree2(Double degree2) {
		this.degree2 = degree2;
	}
	public String getData1() {
		return data1;
	}
	public void setData1(String data1) {

		this.data1 = data1;
	}
	public String getData2() {
		return data2;
	}
	public void setData2(String data2) {
		this.data2 = data2;
	}
	
	
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	public String getGpspos() {
		return gpspos;
	}
	public void setGpspos(String gpspos) {
		this.gpspos = gpspos;
	}
	public String getCompanycode() {
		return companycode;
	}
	public void setCompanycode(String companycode) {
		this.companycode = companycode;
	}
	public String getCompanyname() {
		return companyname;
	}
	public void setCompanyname(String companyname) {
		this.companyname = companyname;
	}
	public String getSelfcode() {
		return selfcode;
	}
	public void setSelfcode(String selfcode) {
		this.selfcode = selfcode;
	}
	public String getUsercode() {
		return usercode;
	}
	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}
	
	
	public Double getTemperature() {
		return temperature;
	}
	public void setTemperature(Double temperature) {
		this.temperature = temperature;
	}
	public Integer getPartid() {
		return partid;
	}
	public void setPartid(Integer partid) {
		this.partid = partid;
	}
	
	public String getColcode() {
		return colcode;
	}
	public void setColcode(String code) {
		this.colcode = code;
	}
	
	@Override
	public String toString() {
		return "EquipStatusModel [areaname=" + areaname + ", areaid=" + areaid
				+ ", nodeid=" + nodeid + ", nodename=" + nodename
				+ ", address=" + address + ", telephone=" + telephone
				+ ", start_date=" + start_date + ", gpspos=" + gpspos
				+ ", companycode=" + companycode + ", companyname="
				+ companyname + ", dataid=" + dataid + ", pkid=" + pkid
				+ ", data_date=" + data_date + ", degree1=" + degree1
				+ ", degree2=" + degree2 + ", data1=" + data1 + ", data2="
				+ data2 + ", selfcode=" + selfcode + ", usercode=" + usercode
				+ ", temperature=" + temperature + ", partid=" + partid
				+ ", partstatus=" + partstatus + ", colcode=" + colcode + "]";
	}
	public EquipStatusModel(String areaname, Integer partid, String nodeid,
			String nodename, String address, String telephone, Integer dataid,
			String pkid, Date data_date, Double degree1, Double degree2,
			String data1, String data2) {
		super();
		this.areaname = areaname;
		this.partid = partid;
		this.nodeid = nodeid;
		this.nodename = nodename;
		this.address = address;
		this.telephone = telephone;
		this.dataid = dataid;
		this.pkid = pkid;
		this.data_date = data_date;
		this.degree1 = degree1;
		this.degree2 = degree2;
		this.data1 = data1;
		this.data2 = data2;
	}
	public EquipStatusModel() {
		super();
	}

	public EquipStatusModel(String areaname, Integer areaid, String nodeid,
			String nodename, String address, String telephone, Date start_date,
			String gpspos, String companycode, String companyname, 
			Integer dataid, String pkid, Date data_date, Double degree1,
			Double degree2, String data1, String data2, 
			String selfcode, String usercode, Double temperature, Integer partid) {
		super();
		this.areaname = areaname;
		this.areaid = areaid;
		this.nodeid = nodeid;
		this.nodename = nodename;
		this.address = address;
		this.telephone = telephone;
		this.start_date = start_date;
		this.gpspos = gpspos;
		this.companycode = companycode;
		this.companyname = companyname;
		this.dataid = dataid;
		this.pkid = pkid;
		this.data_date = data_date;
		this.degree1 = degree1;
		this.degree2 = degree2;
		this.data1 = data1;
		this.data2 = data2;
		this.selfcode = selfcode;
		this.usercode = usercode;
		this.temperature = temperature;
		this.partid = partid;
	}
	public EquipStatusModel(String areaname, Integer areaid, String nodeid,
			String nodename, String address, String telephone, Date start_date,
			String gpspos, String companycode, String companyname,
			Integer dataid, String pkid, Date data_date, Double degree1,
			Double degree2, String data1, String data2, String selfcode,
			String usercode, Double temperature, Integer partid,
			String partstatus) {
		super();
		this.areaname = areaname;
		this.areaid = areaid;
		this.nodeid = nodeid;
		this.nodename = nodename;
		this.address = address;
		this.telephone = telephone;
		this.start_date = start_date;
		this.gpspos = gpspos;
		this.companycode = companycode;
		this.companyname = companyname;
		this.dataid = dataid;
		this.pkid = pkid;
		this.data_date = data_date;
		this.degree1 = degree1;
		this.degree2 = degree2;
		this.data1 = data1;
		this.data2 = data2;
		this.selfcode = selfcode;
		this.usercode = usercode;
		this.temperature = temperature;
		this.partid = partid;
		this.partstatus = partstatus;
	}
	public EquipStatusModel(String areaname, Integer areaid, String nodeid,
			String nodename, String address, String telephone, Date start_date,
			String gpspos, String companycode, String companyname,
			Integer dataid, String pkid, Date data_date, Double degree1,
			Double degree2, String data1, String data2, String selfcode,
			String usercode, Double temperature, Integer partid,
			String partstatus, String colcode) {
		super();
		this.areaname = areaname;
		this.areaid = areaid;
		this.nodeid = nodeid;
		this.nodename = nodename;
		this.address = address;
		this.telephone = telephone;
		this.start_date = start_date;
		this.gpspos = gpspos;
		this.companycode = companycode;
		this.companyname = companyname;
		this.dataid = dataid;
		this.pkid = pkid;
		this.data_date = data_date;
		this.degree1 = degree1;
		this.degree2 = degree2;
		this.data1 = data1;
		this.data2 = data2;
		this.selfcode = selfcode;
		this.usercode = usercode;
		this.temperature = temperature;
		this.partid = partid;
		this.partstatus = partstatus;
		this.colcode = colcode;
	}
	public EquipStatusModel( Integer partid, String nodepkid, String  pkid, Date data_date, 
			 String colcode, String selfcode, String usercode, Double temperature  ){
		super();
		this.partid = partid;
		this.pkid = pkid;
		this.data_date = data_date;
		this.selfcode = selfcode;
		this.usercode = usercode;
		this.temperature = temperature;
		this.colcode = colcode;
	}
}
