package com.monitor.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;
@Entity
@Table(name = "equipment", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = { "equipmentid" }) })
public class Equipment {
		private Integer  equipmentid;
		private String pkid;
		private Integer nodeid;
		private String nodepkid;
		private double degreelimit;
		private double rotatespeedlimit;
		@GenericGenerator(name = "generator", strategy = "increment")
		@GeneratedValue(generator = "generator")
		@Column(name = "equipmentid", unique = true, nullable = false)
		@Id
		public Integer getEquipmentid() {
			return equipmentid;
		}
		public void setEquipmentid(Integer equipmentid) {
			this.equipmentid = equipmentid;
		}

		@Column(name = "nodepkid", length = 20)
		public String getNodepkid() {
			return nodepkid;
		}
		public void setNodepkid(String nodepkid) {
			this.nodepkid = nodepkid;
		}
		@Column(name = "pkid", length = 50)
		public String getPkid() {
			return pkid;
		}
		public void setPkid(String pkid) {
			this.pkid = pkid;
		}
		@Column(name = "nodeid")
		public Integer getNodeid() {
			return nodeid;
		}
		public void setNodeid(Integer nodeid) {
			this.nodeid = nodeid;
		}
		@Column(name = "degreelimit")
		public double getDegreelimit() {
			return degreelimit;
		}
		public void setDegreelimit(double degreelimit) {
			this.degreelimit = degreelimit;
		}
		@Column(name = "rotatespeedlimit")
		public double getRotatespeedlimit() {
			return rotatespeedlimit;
		}
		public void setRotatespeedlimit(double rotatespeedlimit) {
			this.rotatespeedlimit = rotatespeedlimit;
		}
		@Override
		public String toString() {
			return "Equipment [equipmentid=" + equipmentid + ", pkid=" + pkid
					+ ", nodepkid=" + nodepkid + ", degreelimit=" + degreelimit
					+ ", rotatespeedlimit=" + rotatespeedlimit
					+ ", getEquipmentid()=" + getEquipmentid() + ", getPkid()="
					+ getPkid() + ", getNodeid()=" + getNodeid()
					+ ", getDegreelimit()=" + getDegreelimit()
					+ ", getRotatespeedlimit()=" + getRotatespeedlimit()
					+ ", getClass()=" + getClass() + ", hashCode()="
					+ hashCode() + ", toString()=" + super.toString() + "]";
		}
		public Equipment(Integer equipmentid, String pkid, String nodeid,
				double degreelimit, double rotatespeedlimit) {
			super();
			this.equipmentid = equipmentid;
			this.pkid = pkid;
			this.nodepkid = nodeid;
			this.degreelimit = degreelimit;
			this.rotatespeedlimit = rotatespeedlimit;
		}
		public Equipment() {
			super();
		}
		public Equipment(Integer equipmentid, String pkid) {
			super();
			this.equipmentid = equipmentid;
			this.pkid = pkid;
		}
		
		
	}
