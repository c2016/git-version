package com.monitor.entity;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "node", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = { "nodename" }) })

public class Node {
	private Integer nodeid;
	private String nodepkid;
	private String nodename;
	private String address;
	private String gpspos;
	private String telephone;
	private Date start_date;
	private Integer areaid;
	private Integer companyid;
	private Integer isactive;
	@GenericGenerator(name = "generator", strategy = "increment")
	@GeneratedValue(generator = "generator")
	@Column(name = "nodeid", unique = true, nullable = false)
	@Id
	public Integer getNodeid() {
		return nodeid;
	}
	public void setNodeid(Integer nodeid) {
		this.nodeid = nodeid;
	}
	
	@Column(name = "nodename", length = 100)
	public String getNodename() {
		return nodename;
	}
	@Column(name = "nodepkid", length = 100)
	public String getNodepkid() {
		return nodepkid;
	}
	public void setNodepkid(String nodepkid) {
		this.nodepkid = nodepkid;
	}
	public void setNodename(String nodename) {
		this.nodename = nodename;
	}
	@Column(name = "address", length = 200)
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Column(name = "gpspos", length = 100)
	public String getGpspos() {
		return gpspos;
	}
	public void setGpspos(String gpspos) {
		this.gpspos = gpspos;
	}
	@Column(name = "telephone", length = 20)
	public String getTelephone() {
		return telephone;
	}
	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}
	@Temporal(TemporalType.TIMESTAMP)
	@Column(name = "start_date")
	public Date getStart_date() {
		return start_date;
	}
	public void setStart_date(Date start_date) {
		this.start_date = start_date;
	}
	@Column(name = "areaid", length = 11)
	public Integer getAreaid() {
		return areaid;
	}
	public void setAreaid(Integer areaid) {
		this.areaid = areaid;
	}
	@Column(name = "companyid", length = 11)
	public Integer getCompanyid() {
		return companyid;
	}
	public void setCompanyid(Integer companyid) {
		this.companyid = companyid;
	}
	@Column(name="isactive", length = 1)
	public Integer getIsactive() {
		return isactive;
	}
	public void setIsactive(Integer isactive) {
		this.isactive = isactive;
	}
	@Override
	public String toString() {
		return "Node [***"+nodepkid+"***, nodeid=" + nodeid + ", nodename=" + nodename
				+ ", address=" + address + ", gpspos=" + gpspos
				+ ", telephone=" + telephone + ", start_date=" + start_date
				+ ", areaid=" + areaid + ", companyid=" + companyid + "]";
	}
	public Node(Integer nodeid, String nodename, String address, String gpspos,
			String telephone, Date start_date, Integer areaid, Integer companyid) {
		super();
		this.nodeid = nodeid;
		this.nodename = nodename;
		this.address = address;
		this.gpspos = gpspos;
		this.telephone = telephone;
		this.start_date = start_date;
		this.areaid = areaid;
		this.companyid = companyid;
	}
	public Node() {
		super();
	}
	public Node(Integer nodeid) {
		super();
		this.nodeid = nodeid;
	}
	public Node(String nodeid, String nodename) {
		super();
		this.nodepkid = nodeid;
		this.nodename = nodename;
	}	
	
}
