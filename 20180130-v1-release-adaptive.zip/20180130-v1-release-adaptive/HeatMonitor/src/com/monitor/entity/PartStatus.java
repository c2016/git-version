package com.monitor.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.UniqueConstraint;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "partstatus", catalog = "db_heat", uniqueConstraints = { @UniqueConstraint(columnNames = { "partstatusid" }) })

public class PartStatus {
	private String pkid;
	private String colcode;
	private String selfcode;
	private String usercode;
	private String partstatus;
	private Integer partid;//deprecated

	@Column(name="pkid", length = 50)
	public String getPkid() {
		return pkid;
	}
	public void setPkid(String pkid) {
		this.pkid = pkid;
	}
	@Column(name="colcode", length = 10)
	public String getColcode() {
		return colcode;
	}
	public void setColcode(String colcode) {
		this.colcode = colcode;
	}
	@Column(name="selfcode", length = 10)
	public String getSelfcode() {
		return selfcode;
	}
	public void setSelfcode(String selfcode) {
		this.selfcode = selfcode;
	}
	@Column(name="usercode", length = 10)
	public String getUsercode() {
		return usercode;
	}
	public void setUsercode(String usercode) {
		this.usercode = usercode;
	}
	@Column(name="partstatus", length = 2)
	public String getPartstatus() {
		return partstatus;
	}
	public void setPartstatus(String partstatus) {
		this.partstatus = partstatus;
	}
	@GenericGenerator(name = "generator", strategy = "increment")
	@GeneratedValue(generator = "generator")
	@Column(name = "partstatusid", unique = true, nullable = false)
	@Id
	public Integer getPartid() {
		return partid;
	}
	public void setPartid(Integer partid) {
		this.partid = partid;
	}
	@Override
	public String toString() {
		return "PartStatus [colcode=" + colcode + ", selfcode=" + selfcode
				+ ", usercode=" + usercode + ", partstatus=" + partstatus + "]";
	}
	public PartStatus(String pkid, String colcode, String selfcode, 
			String usercode, String partstatus) {
		super();
		this.pkid = pkid;
		this.colcode = colcode;
		this.selfcode = selfcode;
		this.usercode = usercode;
		this.partstatus = partstatus;

	}
	public PartStatus() {
		super();
	}
}
