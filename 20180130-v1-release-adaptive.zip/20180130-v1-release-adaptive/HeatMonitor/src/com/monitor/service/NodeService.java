package com.monitor.service;

import java.util.List;
import java.util.Map;

import com.monitor.entity.Node;
import com.monitor.model.NodeModel;
import com.monitor.model.UserModel;
import com.monitor.util.AjaxResult;

public interface NodeService {
	public void saveNode(Node o);
	public void updateNode(Node o);
	public void deleteNode(Node o);

	public AjaxResult addNode(NodeModel o);
	public AjaxResult updateNode(NodeModel o);//OK
	public AjaxResult deleteNode(String[] o_ids);//OK	
	public AjaxResult checkNode(NodeModel o);	
	
	//public List<NodeModel> listNodess(RegionModel o);
	//public List<NodeModel> listNodess(UserModel user, String areaid);
	public List<Node> listNodes(UserModel user, String provinceid, String cityid, String areaid);
	public List<String> listNodeIDs(UserModel user, String provinceid, String cityid, String areaid);
	public Node getNodeById(int id);
	public AjaxResult checkNodeName(Node node);
	public Map<String, Object> getNodeListByPage(int page, int pz);
	
	
	public AjaxResult listNodes(String areaid, String companyid, String nodeid);
	List<Node> listNodes(String areaid, String companyid);
	
}
