package com.monitor.service;

import java.util.List;

import com.monitor.entity.Area;
import com.monitor.model.UserModel;

public interface AreaService {
	//public List<ProvinceModel> listProvinces(UserModel user);
	//public List<CityModel> listCities(ProvinceModel o);
	//public List<RegionModel> listRegions(CityModel o);
	public List<Area> listAreas(UserModel user);
	public List<Area> listProvinces(UserModel user);
	//public List<Area> listCities(UserModel user, String pid);
	//public List<Area> listRegions(UserModel user, String pid);
	public List<Area> listCities(UserModel user, String pid);
	public List<Area> listRegions(UserModel user, String provinceid, String pid);
	public String loadTotal();
}
