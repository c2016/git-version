package com.monitor.service;

import com.monitor.util.AjaxResult;

public interface PartService {
	public AjaxResult countParts(String nodepkid);
}
