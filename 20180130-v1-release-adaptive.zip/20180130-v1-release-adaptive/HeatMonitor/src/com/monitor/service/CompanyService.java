package com.monitor.service;

import java.util.List;
import java.util.Map;
import com.monitor.entity.Company;
import com.monitor.model.CompanyModel;
//import com.monitor.model.RegionModel;
import com.monitor.model.UserModel;
import com.monitor.util.AjaxResult;

public interface CompanyService {
	public void saveCompany(Company o);
	public void updateCompany(Company o);
	public void deleteCompany(Company o);

	public AjaxResult addCompany(CompanyModel o);
	public AjaxResult updateCompany(CompanyModel o);//OK
	public AjaxResult deleteCompany(String[] o_ids);//OK	
	public AjaxResult checkCompany(CompanyModel o);	
	
	//public List<CompanyModel> listCompanies(RegionModel o);
	//public List<CompanyModel> listCompanies(UserModel user, String areaid);
	public List<Company> listCompanies(UserModel user, String provinceid, String cityid, String areaid);
	public List<String> listCompanyIDs(UserModel user, String provinceid, String cityid, String areaid);
	public Company getCompanyById(int id);
	public AjaxResult checkCompanyName(Company company);
	public Map<String, Object> getCompanyListByPage(int page, int pz);

}
