package com.monitor.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.monitor.dao.BaseDAO;
import com.monitor.entity.Datainfo;
import com.monitor.model.DatainfoModel;
import com.monitor.model.UserModel;
import com.monitor.service.DatainfoService;
import com.monitor.util.AjaxResult;
@Service("datainfoService")
public class DatainfoServiceImpl implements DatainfoService{
	@Resource
	public BaseDAO<Datainfo> datainfoDao;
	@Resource
	public BaseDAO<Object> userDao;
	@Override
	public List<Datainfo> findListBySQL(String sql) {
		return datainfoDao.findListBySQL(sql, Datainfo.class);
	}

	@Override
	public Datainfo getBySQL(String sql) {
		return datainfoDao.getBySQL(sql, Datainfo.class);
	}

	@Override
	public Integer executeSQL(String sql) {
		return datainfoDao.updateBySQL(sql, Datainfo.class);
	}

	@Override
	public Datainfo getByPKID(String id) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct id,equipmentid, status, DATA_DATE, ");
		sql.append("state1,state2, state3, state4, state5, state6, state7, state8, state9, state10, ");
		sql.append("state11,state12, state13, state14, state15, state16, state17, state18, state19, state20 ");
		sql.append("from datainfo where equipmentid = '"+id+"' ORDER BY DATA_DATE desc limit 1 ");	
		return datainfoDao.getBySQL(sql.toString(), Datainfo.class);
	}

	@Override
	public AjaxResult getNewEquipByID(String id) {
		StringBuilder sql = new StringBuilder();		
		sql.append("select t.*, c.companyname from (select a.id, a.equipmentid, a.status, a.state1, a.state2, a.DATA_DATE, b.company_id ");
		sql.append(" from datainfo a  inner join equipment b  on a.equipmentid = '");
		sql.append(id);
		sql.append("' and a.equipmentid = b.equipmentid");
		sql.append(" ORDER BY DATA_DATE desc limit 1) t left JOIN carteringcompany c on t.company_id = c.id  ");
		
		Object[] obj= (Object[]) userDao.getObjectBySQL(sql.toString());
		
		if(obj == null) return new AjaxResult(0, "未找到设备");
		
		DatainfoModel o = new DatainfoModel();
		o.setId(obj[0]==null? -1: Integer.parseInt(obj[0].toString()));
		o.setEquipmentid(obj[1]==null?"":obj[1].toString());
		o.setStatus(obj[2]==null?0:Integer.parseInt(obj[2].toString()));
		o.setState1(obj[3]==null?"":obj[3].toString());
		o.setState2(obj[4]==null?"":obj[4].toString());
		if(obj[5]==null)
			o.setData_date(null);
		else
			o.setData_date((Date)obj[5]);
		o.setCompanyid(obj[6]==null?"":obj[6].toString());
		o.setCompanyname(obj[7]==null?"":obj[7].toString());
		
		return new AjaxResult(1, "查到设备信息", o);
		
	}

	
}
