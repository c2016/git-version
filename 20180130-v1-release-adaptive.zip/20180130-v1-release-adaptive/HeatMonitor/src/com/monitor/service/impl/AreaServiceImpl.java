package com.monitor.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.monitor.dao.BaseDAO;
import com.monitor.entity.Area;
import com.monitor.model.UserModel;
import com.monitor.service.AreaService;
import com.monitor.util.AppUtil;

@Service("areaService")
public class AreaServiceImpl implements AreaService{
	@Resource
	private BaseDAO<Object> baseDao;
	@Resource
	private BaseDAO<Area> areaDao;
	@Override
	public List<Area> listAreas(UserModel user) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<Area> listProvinces(UserModel user) {
		// TODO Auto-generated method stub
		if(user.getUsername().equals("superadmin"))
			return areaDao.findListBySQL("select * from area t where t.id<> 0 and t.pid=0  and isActive = 1", Area.class);
		else{
			StringBuilder sql = new StringBuilder(); 
			sql.append(user.getArea_id().toString().substring(0,2));
			sql.append("0000");
			sql.insert(0, "select * from area t where isActive = 1 and t.id = ");
	System.out.println(sql.toString());		
			return areaDao.findListBySQL(sql.toString(),Area.class);
		}
	}
	@Override
	public List<Area> listCities(UserModel user, String pid) {// pid:provinceid
		// TODO Auto-generated method stub
		String sid = StringUtils.trimToEmpty(pid) ;
System.out.println("listCities: " + sid);			
		Integer id = 0;
		StringBuilder sql = new StringBuilder("");
		if(sid.equals("")){
			return null;
		}else if (sid.equalsIgnoreCase("all")){			
			sql.append("select * from area t where isActive = 1 ");
			return null;
		}else{
			id= Integer.parseInt(pid);			
			sql.append("select * from area t where isActive = 1 and t.pid = " + id );
		}
		return areaDao.findListBySQL(sql.toString(), Area.class);
	}
	@Override
	public List<Area> listRegions(UserModel user, String provinceid, String pid) {
		// TODO Auto-generated method stub
		String sid = StringUtils.trimToEmpty(pid) ;
System.out.println("listRegions: " + sid);		
		Integer id = 0;
		StringBuilder sql = new StringBuilder("");
		if(sid== null){
			return null;
		}else if (sid.equalsIgnoreCase("all")){			
			sql.append("select * from area t where  t.pid = "+pid+"  and t.isActive = 1 ");
			return null;
		}else{
			id= Integer.parseInt(pid);	
			int id1 = id + 1;
			sql.append("select * from area t where (t.pid = " + id + " or t.pid = "+ id1+ ") and t.id<> "+ id1 + " and t.isActive=1 ");
		}
		return areaDao.findListBySQL(sql.toString(), Area.class);
	}
	/*20180129---testing*/
	@Override
	public String loadTotal() {
		HashMap<String, Object> map = new HashMap<String, Object>();
		ArrayList<Area> list = new ArrayList<Area>();
		list.add(new Area(110101, "test1", 110100));
		list.add(new Area(110102, "test2", 110100));
		list.add(new Area(110103, "test3", 110100));
		list.add(new Area(110104, "test4", 110100));
		list.add(new Area(110105, "test5", 110100));
		map.put("total", 5);
		map.put("rows", list);
		System.out.println(AppUtil.object2Json(map));
		return AppUtil.object2Json(map);
	}

}
