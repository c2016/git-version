package com.monitor.service.impl;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.monitor.dao.BaseDAO;
import com.monitor.entity.Equipment;
import com.monitor.entity.Role;
import com.monitor.model.EquipConfModel;
import com.monitor.model.EquipStatusModel;
import com.monitor.model.EquipmentStatusModel;
import com.monitor.model.PartStatusModel;
import com.monitor.model.RuntimeStatusModel;
import com.monitor.model.StatsTemperature;
import com.monitor.service.EquipmentService;
import com.monitor.util.AjaxResult;
import com.monitor.util.AppUtil;
import com.monitor.util.DateComparator;
import com.monitor.util.page.PageResultSet;

@Service("equipmentService")
public class EquipmentServiceImpl implements EquipmentService{
	final static Logger logger = LoggerFactory.getLogger(EquipmentServiceImpl.class);
	@Resource
	private BaseDAO<Object> baseDao;
	@Resource
	private BaseDAO<Equipment> equipDao,equipModelDao;
	@Resource
	private BaseDAO<EquipStatusModel> equipStatusModelDao;
	@Resource 
	public BaseDAO<String> stringDao;
	@Resource
	private BaseDAO<EquipConfModel> equipConfModelDao;
	@Resource
	private BaseDAO<Date> dateDao;;

	@Override
	public Map<String, Object> getEquipmentList(String[] pageInfo, String[] sortInfo) {/*size,page,name,order*/
		int[] pInfo = AppUtil.setStartPage(pageInfo);	
		StringBuilder sql = new StringBuilder("");
		sql.append(" SELECT  e.id, e.equipmentid, e.equipmentname,e.company_id,e.equipment_start_date,e.equipment_discard_date,c.companyid, c.companyname,");
		sql.append(" e.status1,e.status2,e.status3,e.status4,e.status5,e.status6,e.status7,e.status8,e.status9,e.status10,");
		sql.append(" e.status11,e.status12,e.status13,e.status14,e.status15,e.status16,e.status17,e.status18,e.status19,e.status20");
		sql.append(" FROM carteringcompany c");
		sql.append(" INNER JOIN Equipment e");
		sql.append(" ON e.company_id = c.id");
		sql.append(" ORDER BY c.companyname");
		//List<Object> list = baseDao.findBySQL(sql.toString());	
		@SuppressWarnings("unchecked")
		List<Equipment> pageList = equipModelDao.findBySQL(sql.toString(), pInfo[0], pInfo[1]);	
		String hql="from Equipment where id>0";		
		long total = equipDao.count(hql);	//List<Equipment> retList = equipDao.find(hql);
		Map<String, Object> map = new HashMap<String, Object>();	
		/*
		String[] param = new String[0];
		List<Equipment> pageList = equipDao.find(hql, param, 1, 5);
		*/

		map.put("rows", pageList);
		map.put("total", total);
		if(total > 0 ){
			map.put("retcode", 1);
			map.put("currentEquip",pageList.get(0));	System.out.println("currentEquip info = " + pageList.get(0));
		}
		else
			map.put("retcode", 0);

		return map;

	}
	//20171114
	@Override
	public List<String> selectpkid(String areaid) {
		// TODO Auto-generarted method stub
		StringBuffer hql = new StringBuffer("select distinct e.equipmentid from Equipment e where 1=1 ");
		if( !"all".equals(areaid) ){
			hql.append(" and e.equipment_companyid="+areaid+" ");
		}
		return stringDao.find(hql.toString());
	}
	@SuppressWarnings("rawtypes")
	@Override  /*旧版 datainfo*/
	public List<EquipStatusModel> findEquipLatestStatusList(String nodeid){//显示最新的状态****************20171214**************
		StringBuilder sql = new StringBuilder();
		sql.append("select d.areaname, d.areaid, n.nodeid, n.nodepkid, n.nodename, n.address, n.telephone,n.start_date, n.gpspos,  "); 
		//sql.append(" c.companycode, c.companyname,");
		sql.append(" a.dataid, a.pkid, a.data_date, a.degree1, a.degree2, a.data1, a.data2 ");
		
		sql.append(" , a.temperature, p.selfcode, p.usercode, p.partid, p.colcode ");		
		sql.append(" from part p, equipment e,node n, area d, datainfo a ");
		//sql.append(", company c ");
		sql.append(" , (select pkid,max(data_date) data_date from datainfo group by pkid) b ");
		sql.append(" where p.pkid = a.pkid and p.usercode = a.usercode and a.pkid = b.pkid and b.pkid = e.PKID and e.nodepkid = n.nodepkid ");
		//sql.append(" and n.COMPANYID = c.COMPANYID ");
		sql.append(" and n.AREAID = d.AREAID");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and n.nodepkid in(" + nodeid + ") ");
		//sql.append(" #and a.pkid in(select e.pkid from equipment e) ");
		//sql.append(" #and EXISTS(select e.pkid from equipment e where e.pkid = a.pkid) ");
		sql.append(" and a.data_date = b.data_date order by a.pkid, a.data_date, a.selfcode asc ");	
		List modelList = equipStatusModelDao.findBySQL(sql.toString());

		List<EquipStatusModel> list = new ArrayList<EquipStatusModel>();
		for(int i=0; i<modelList.size(); i++){
			Map m = (Map)modelList.get(i);
			String areaname = (String)m.get("areaname");
			Integer areaid = (Integer)m.get("areaid");
			Integer nodeid0 = (Integer)m.get("nodeid");
			String nodeid_ = (String)m.get("nodepkid");
			String nodename = (String)m.get("nodename");
			String address = (String)m.get("address");
			String telephone = (String)m.get("telephone");
			Date start_date = (Date)m.get("start_date");
			String gpspos = (String)m.get("gpspos");
			String companycode = (String)m.get("companycode");
			String companyname = (String)m.get("companyname");
			Integer dataid = (Integer)m.get("dataid");
			String pkid = (String)m.get("pkid");
			Date data_date = (Date)m.get("data_date");
			Double degree1 = (Double)m.get("degree1");
			Double degree2 = (Double)m.get("degree2");
			String data1 = (String)m.get("data1");
			String data2 = (String)m.get("data2");
			Integer partid = (Integer)m.get("partid");
			String colcode = (String)m.get("colcode");
			String selfcode = (String)m.get("selfcode");
			String usercode = (String)m.get("usercode");
			Double temperature= (Double)m.get("temperature");
			EquipStatusModel o = new EquipStatusModel(areaname, areaid, nodeid_,nodename, address, telephone, start_date, gpspos, 
					companycode, companyname, dataid, pkid, data_date, degree1, degree2, data1, data2
					, selfcode, usercode, temperature, partid, null, colcode
					);
			list.add(o);
		}
		
		return list;
	}
	@Override
	public List<EquipStatusModel> findEquipStatusList(String nodeid){
System.out.println("find latest 30 days' EquipStatusList by nodepkid");		
		Date date= new Date(System.currentTimeMillis());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");		//24小时制必须使用大写HH
		java.sql.Date temp = new java.sql.Date(date.getTime() - 30L*24L*60L*60L*1000L);//测试使用n天为条件，此处n= 30
		StringBuilder sql = new StringBuilder();
		sql.append("select d.areaname, d.areaid, b.nodeid,b.nodepkid, b.nodename,b.address, b.telephone,b.start_date, b.gpspos, b.companyid, "); 
		sql.append(" c.companycode, c.companyname, ");
		sql.append(" a.dataid, a.pkid, a.data_date, a.degree1, a.degree2, a.data1, a.data2 ");
		sql.append(" , a.partstatus,  a.selfcode, a.usercode, a.temperature, p.partid ");		
		sql.append(" from part p, equipment e,node b, ");
		//sql.append(" company c, ");
		sql.append(" area d, datainfo a  where 1=1 ");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and b.nodepkid in(" + nodeid + ") ");
		sql.append(" and p.pkid = a.pkid and p.selfcode = a.selfcode and  a.pkid = e.pkid and e.nodepkid = b.nodepkid and d.AREAID =b.AREAID ");
		//sql.append( " and c.COMPANYID = b.COMPANYID ");
		//sql.append(" and a.usercode<>'00' "); 
		sql.append(" and a.data_date >'" + temp + "' "); 
		sql.append(" order by a.DATA_DATE, a.PKID, a.selfcode  asc ");

		
		List modelList = equipStatusModelDao.findBySQL(sql.toString());			
		
		List<EquipStatusModel> list = new ArrayList<EquipStatusModel>();
		for(int i=0; i<modelList.size(); i++){
			Map m = (Map)modelList.get(i);
			String areaname = (String)m.get("areaname");
			Integer areaid = (Integer)m.get("areaid");
			Integer nodeid0 = (Integer)m.get("nodeid");
			String nodeid_ = (String)m.get("nodepkid");
			String nodename = (String)m.get("nodename");
			String address = (String)m.get("address");
			String telephone = (String)m.get("telephone");
			Date start_date = (Date)m.get("start_date");
			String gpspos = (String)m.get("gpspos");
			String companycode = (String)m.get("companycode");
			String companyname = (String)m.get("companyname");
			Integer dataid = (Integer)m.get("dataid");
			String pkid = (String)m.get("pkid");
			Date data_date = (Date)m.get("data_date");
			
			Double degree1 = (Double)m.get("degree1");
			Double degree2 = (Double)m.get("degree2");
			String data1 = (String)m.get("data1");
			String data2 = (String)m.get("data2");
			
			Integer partid = (Integer)m.get("partid");
			String selfcode = (String)m.get("selfcode");
			String usercode = (String)m.get("usercode");
			Double temperature= (Double)m.get("temperature");

			String partstatus = (String)m.get("partstatus");
			
			EquipStatusModel o = new EquipStatusModel(areaname, areaid, nodeid_,nodename, address, telephone, start_date, gpspos, 
					companycode, companyname, dataid, pkid, data_date, degree1, degree2, data1, data2
					, selfcode, usercode, temperature, partid
					);
			String t = "停止";
			if(partstatus!=null){
				if(partstatus.equals("1"))
					t = "运行";
				else if(partstatus.equals("2")){
					t="停止";
				}else if(partstatus.equals("3")){
					t="故障";
				}else{
					t="未知状态";
				}
			}
			o.setPartstatus(t);
			list.add(o);				
		}
		return list;
	}

	@Override /***20171215***/
	public HashMap<String,Object> groupStatusList(String nodeid){	
		List<EquipStatusModel> list = this.findEquipLatestStatusList(nodeid);				
		//查询唯一的pkidList：select e.pkid as col_0_0_ from equipment e where e.nodepkid='210106001001'  group by e.pkid  order by e.pkid asc  
		List<String> pkidList = this.getPKIDsList(nodeid); //stringDao.find("select e.pkid from Equipment e where e.nodepkid = '"+nodeid+"' group by e.pkid order by e.pkid asc ");
		if (pkidList.size()<1)	return null;
		HashMap<String, Object> map = new HashMap<String,Object>();
		map.putAll(getLatestInfo(nodeid));
		map.put("datainfo", map.get("latestInfo"));/*Tester*/
		return map;
	}
	/*group on pkid，colcode *** 20171115***/
	private HashMap<String, Object> groupEquips(List<String> pkidList, List<EquipStatusModel> list){
		HashMap<String,Object> map = new HashMap<String, Object>();
		List groupList = new ArrayList();
		map.put("pkidList", pkidList);
		for(int k =0 ;k< pkidList.size(); k++){		
			String pkid = pkidList.get(k);
			List<EquipStatusModel> subList = new ArrayList<EquipStatusModel>();
/*			List subList = new ArrayList();
			String colcode = list.get(0).getColcode();
			List<EquipStatusModel> partList = new ArrayList<EquipStatusModel>();*/
			for(int i=0; i<list.size(); i++){	
				EquipStatusModel e = list.get(i);
				if(e.getPkid().equals(pkid)){
					subList.add(e);
					list.remove(i);
					i -= 1;
				}else{
					break;  //已经按照pikid排序，不同则是另一组设备//continue;
				}
			}
			if(subList.size()>0){
				System.out.println(subList);
				groupList.add(subList);
			}
		}
	
		if(map.size()>0){
			map.put("latestInfo", groupList);			//map.put("datainfo", test());
			return map;
		}else
			return null;
	}
	private List<EquipmentStatusModel> test(){
		Date d = new Date(System.currentTimeMillis());
		ArrayList<PartStatusModel> partlist = new ArrayList<PartStatusModel>();
		//String colcode, String selfcode, String usercode,	String partstatus, Integer partid
		partlist.add(new PartStatusModel("210105001001", "1","1", "01", "2"));
		partlist.add(new PartStatusModel("210105001001", "1","2", "03", "2"));
		partlist.add(new PartStatusModel("210105001001", "2","3", "04", "1"));
		partlist.add(new PartStatusModel("210105001001", "2","4", "02", "2"));
		partlist.add(new PartStatusModel("210105001001", "2","4", "05", "2"));
		EquipmentStatusModel eM= new EquipmentStatusModel();
		eM.setPkid("210105001001");eM.setTemperature(40.0);eM.setWaterlevel(85d);
		eM.setValvetop("0"); eM.setValvebottom("0"); eM.setData_date(d);
		eM.setPartlist(groupParts(partlist));
		ArrayList<EquipmentStatusModel> eMList = new ArrayList<EquipmentStatusModel>();
		eMList.add(eM); 
		partlist = new ArrayList<PartStatusModel>();
		//String colcode, String selfcode, String usercode,	String partstatus, Integer partid
		partlist.add(new PartStatusModel("210105001002", "1","1", "04", "2"));
		partlist.add(new PartStatusModel("210105001002", "1","2", "03", "2"));
		partlist.add(new PartStatusModel("210105001002", "1","3", "02", "1"));
		partlist.add(new PartStatusModel("210105001002", "2","4", "01", "1"));
		partlist.add(new PartStatusModel("210105001002", "2","4", "05", "2"));
		EquipmentStatusModel eM0= new EquipmentStatusModel();
		eM0.setPkid("210105001002");eM0.setTemperature(70.0);eM0.setWaterlevel(90d);
		eM0.setValvetop("1"); eM0.setValvebottom("1"); eM0.setData_date(d);
		eM0.setPartlist(groupParts(partlist));
		eMList.add(eM0);
		//m.put("datainfo", eMList);
		return eMList;
	}
	private ArrayList groupParts(ArrayList<PartStatusModel> list){
		ArrayList groupedList = new ArrayList();
		String colcode = list.get(0).getColcode();
		List<PartStatusModel> partList = new ArrayList<PartStatusModel>();
		for(int i=0; i<list.size(); i++){	
			PartStatusModel e = list.get(i);
			if (!e.getColcode().equals(colcode)){
				groupedList.add(partList);
				colcode = list.get(i).getColcode();
				partList = new ArrayList<PartStatusModel>();
			}
			partList.add(e);
			list.remove(i);
			i -= 1;
		}
		if(partList.size()>0){
			groupedList.add(partList);
		}
		return groupedList;
	}
	private List<EquipConfModel> getEquipConfModelList(String nodeid){
		StringBuilder sql = new StringBuilder();
		sql.append("select t.nodepkid, t.pkid, t.config_date, t.upboundertemper, t.lowboundtemper, t.convertingtemper, t.idealtemper  ");
		sql.append(" from equipmentconf t , (select pkid,max(config_date) config_date from equipmentconf where nodepkid = ");
		sql.append(nodeid);
		sql.append(" group by pkid) b ");
		sql.append(" where t.config_date = b.config_date and  t.pkid = b.pkid  order by t.pkid");
		List equipConf = equipConfModelDao.findBySQL(sql.toString());
		System.out.println("************Config_data: "+equipConf);
		List<EquipConfModel> list = new ArrayList<EquipConfModel>();
		for(int i=0; i< equipConf.size(); i++){
			Map m = (Map)equipConf.get(i);
			String nid = (String)m.get("nodepkid");
			String pkid = (String)m.get("pkid");
			Date date = (Date)m.get("config_date");
			Double uptemper = (Double)m.get("upboundertemper");
			Double lowtemper = (Double)m.get("lowboundtemper");
			Double convertemper = (Double)m.get("convertingtemper");
			Double idealtemper = (Double)m.get("idealtemper");
			EquipConfModel o = new EquipConfModel(nid, pkid, date,uptemper,lowtemper, convertemper,idealtemper);
			list.add(o);
		}
		return list;
	}
	private int getTemperatureAlarm(JsonNode o, String pkid , double t){
		int ret = 0;
		for(int i=0; i<o.size(); i++){
			JsonNode temp = o.get(i);
			if(pkid.equals(temp.get("pkid").textValue())){
				if(t > temp.get("upboundtemperature").doubleValue()){
					ret = 1; break;
				}
			}
		}
		return ret ;
	}
	@Override
	public HashMap<String, Object> findRuntimeStatus(String nodeid){
		System.out.println("@@@@#######");
		List<String> pkidList = this.getPKIDsList(nodeid);
        if (pkidList.size()<1)	return null;
		
		List<EquipConfModel> confList = this.getEquipConfModelList(nodeid);
		
		ObjectMapper mapper = new ObjectMapper();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
        mapper.setDateFormat(dateFormat); 
		JsonNode jsonNode=null;
		try {
			String strConf = mapper.writeValueAsString(confList);		
			jsonNode = mapper.readTree(strConf);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		RuntimeStatusModel oStatus= new RuntimeStatusModel();
		//HashMap<String, Object> map = new HashMap<String, Object>();
		StringBuilder sql = new StringBuilder();
		sql.append("select d.areaname, d.areaid, n.nodepkid, n.nodename, n.address, n.telephone,n.start_date, n.gpspos,  "); 
		//sql.append(" c.companycode, c.companyname,");
		sql.append(" a.dataid, a.pkid, a.data_date, a.degree1, a.degree2, a.data1, a.data2 ");

		sql.append(" ,  a.first_primary_pump_freq, a.first_assistant_pump_freq, a.second_primary_pump_freq, a.second_assistant_pump_freq ");
		sql.append(" ,  a.partstatus, a.temperature, p.partid, p.colcode , p.selfcode, p.usercode ");
		sql.append(" ,  a.runningstatus, a.alarmstatus, a.firstsupplytemper, a.firstbacktemper, a.secondsupplytemper, a.secondbacktemper, a.shifting ");
		
		sql.append(" from part p, equipment e,node n, area d, datainfo a ");
		//sql.append(" ,company c ");
		sql.append(" ,(select pkid,max(data_date) data_date from datainfo group by pkid) b ");
		sql.append(" where p.pkid = a.pkid and p.usercode = a.usercode and a.pkid = b.pkid and b.pkid = e.PKID and e.nodepkid = n.nodepkid ");
		//sql.append(" and n.COMPANYID = c.COMPANYID ");
		sql.append(" and n.AREAID = d.AREAID");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and n.nodepkid in(" + nodeid + ") ");
		//sql.append(" #and a.pkid in(select e.pkid from equipment e) ");
		//sql.append(" #and EXISTS(select e.pkid from equipment e where e.pkid = a.pkid) ");
		sql.append(" and a.data_date = b.data_date order by a.pkid, a.data_date, a.selfcode asc ");	

		List modelList = equipStatusModelDao.findBySQL(sql.toString());
System.out.println("modelList before list: "+modelList);		
		List<EquipStatusModel> list = new ArrayList<EquipStatusModel>();
		for(int i=0; i<modelList.size(); i++){
			Map m = (Map)modelList.get(i);
			String areaname = (String)m.get("areaname");
			Integer areaid = (Integer)m.get("areaid");
			String nodeid_ = (String)m.get("nodepkid");
			String nodename = (String)m.get("nodename");
			String address = (String)m.get("address");
			String telephone = (String)m.get("telephone");
			Date start_date = (Date)m.get("start_date");
			String gpspos = (String)m.get("gpspos");
			String companycode = (String)m.get("companycode");
			String companyname = (String)m.get("companyname");
			Integer dataid = (Integer)m.get("dataid");
			String pkid = (String)m.get("pkid");
			Date data_date = (Date)m.get("data_date");
			
			Double degree1 = (Double)m.get("degree1");
			Double degree2 = (Double)m.get("degree2");
			String data1 = (String)m.get("data1");
			String data2 = (String)m.get("data2");
			
			Integer partid = (Integer)m.get("partid");
			String colcode = (String)m.get("colcode");
			String selfcode = (String)m.get("selfcode");
			String usercode = (String)m.get("usercode");
			Double temperature= (Double)m.get("temperature");

			Double freq_primary1 = (Double)m.get("first_primary_pump_freq");
			Double freq_assistant1 = (Double)m.get("first_assistant_pump_freq");
			Double freq_primary2 = (Double)m.get("second_primary_pump_freq");
			Double freq_assistant2 = (Double)m.get("second_assistant_pump_freq");
			
			String partstatus = (String)m.get("partstatus");
			
			EquipStatusModel o = new EquipStatusModel(areaname, areaid, nodeid_,nodename, address, telephone, start_date, gpspos, 
					companycode, companyname, dataid, pkid, data_date, degree1, degree2, data1, data2
					, selfcode, usercode, temperature, partid, null, colcode);
			
			o.setPartstatus(partstatus);  //return integer number to canvas
			list.add(o);
			
			if(i==0){
				Double supply1 = (Double)m.get("firstsupplytemper");
				Double supply2 = (Double)m.get("secondsupplytemper");
				Double back1 = (Double)m.get("firstbacktemper");
				Double back2 = (Double)m.get("secondbacktemper");
				Integer shift = (Integer)m.get("shifting");
				oStatus = new RuntimeStatusModel(supply1, back1,supply2, back2);
				oStatus.setFreqs(freq_primary1, freq_assistant1, freq_primary2, freq_assistant2);	
				oStatus.setShifting(shift);
			}
			Integer runningstatus = (Integer)m.get("runningstatus");
			System.out.println("runningstatus = " + runningstatus);
			String alarmstatus = (String)m.get("alarmstatus");
			
			//根据需求调整
			if (runningstatus !=null && runningstatus != 1)
				oStatus.setRunningstatus(runningstatus);
			if(alarmstatus!=null)
				oStatus.setPartalarm(1);
			int temperAlarm = this.getTemperatureAlarm(jsonNode, pkid, temperature);		
			if(temperAlarm != 0)
				oStatus.setTemperalarm(1);			
		}	
		HashMap<String, Object> map = this.groupEquips(pkidList, list);
		map.put("runtimeStatus", oStatus);
		map.put("confParams", confList);
		return map;
	}
	private List<String> getPKIDsList(String nodeid){
		return stringDao.find("select e.pkid from Equipment e where e.nodepkid = '"+nodeid+"' group by e.pkid order by e.pkid asc ");		
	}
	@Override
	public HashMap<String, Object> findEquipStatusTableItems(String nodeid){//全部，不分页
		List<EquipStatusModel> list = this.findEquipStatusList(nodeid);	
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("total", list.size());
		map.put("rows", list);
		return map;
	}
	
	public static String getTime(String user_time) {  
		String re_time = null;  
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");// HH:mm:ss");  
		Date d;  
		try { 
			d = sdf.parse(user_time);  
			long l = d.getTime();  
			String str = String.valueOf(l);  
			re_time = str.substring(0, 10);    
		  
		} catch (ParseException e) { 
			e.printStackTrace();  
		}  
		return re_time;  
		}  
	@Override
	public AjaxResult findDatainfoSet(String pkid, String beginTime, String endTime){
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
try {
	System.out.println(beginTime + " *********" + sdf.parse(beginTime).getTime());
} catch (ParseException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
try {
	System.out.println(endTime + "************" + sdf.parse(endTime).getTime());
} catch (ParseException e1) {
	// TODO Auto-generated catch block
	e1.printStackTrace();
}
		StringBuilder sql = new StringBuilder("");
		/*sql.append("select a.* from datainfo a where a.data_date>'");		sql.append("2017-11-21");		sql.append("' and a.data_date<'");		sql.append("2017-11-23");		sql.append("' and a.pkid = '");		sql.append("2101010002");		sql.append("'");*/
		//sql.append("select a.dataid, a.pkid, a.data_date, a.temperature ");
		//sql.append(" from datainfo a, equipment e , node n , company c, area d ");
		sql.append("select  ps.pkid, ps.temperature, ps.data_date from equipmentstatus ps ");
		sql.append(" where ps.data_date>'");
		sql.append(beginTime);
		sql.append("' and ps.data_date<'");
		sql.append(endTime);
		sql.append("' and ps.pkid = '");
		sql.append(pkid);
		sql.append("'  order by ps.data_date asc , ps.pkid asc ");
		List<StatsTemperature> list = baseDao.findBySQL(sql.toString());
		Set<StatsTemperature> set = new HashSet<StatsTemperature>();
		if(list.size()>0){
			for(int i=0; i<list.size(); i++){
				Map m = (Map)list.get(i);
				String strpkid = (String)m.get("pkid");
				Double temperature = (Double)m.get("temperature");
				Date date = (Date)m.get("data_date");
				set.add(new StatsTemperature(strpkid, temperature, date));				
			}
			list.clear();   
			list.addAll(set);
			Collections.sort(list, new DateComparator());
			return new AjaxResult(1, "指定时间范围内数据已找到，请等待显示", list);
		}
		return new AjaxResult("未找到数据，请确认后重新查看");		
	}

	@Override
	public List<String> listEquipIDs(String areaid, String companyid,
			String nodeid) {
		StringBuilder sql =  new StringBuilder("select pkid from equipment where 1 = 1 ");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and nodepkid = " + Integer.parseInt(nodeid.trim()));
		List<String> list = stringDao.findBySQL(sql.toString());
		return list;
		//return stringDao.findBySQL(sql.toString());
	}

	@Override
	public List<Equipment> listEquips(String areaid, String companyid,	String nodeid) {
		StringBuilder sql =  new StringBuilder("select new Equipment(e.equipmentid, e.pkid) from Equipment e where 1 = 1 ");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and e.nodepkid = " + nodeid.trim());
		List<Equipment> list = equipDao.find(sql.toString());	//findBySQL(sql.toString());
		return list;											//return equipDao.findBySQL(sql.toString());
	}
	
	/*********** read from datainfodetail *************/
	@Override  		/*Deprecated*//*分页显示状态*/
	public HashMap<String, Object> findEquipStatusTableItems0(String nodeid, String[] pageInfo, String[] sortInfo){
		System.out.println("################pagesize, pageno: " + Arrays.toString(pageInfo));		
		Date date= new Date(System.currentTimeMillis());
		java.sql.Date temp = new java.sql.Date(date.getTime() - 30L*24L*60L*60L*1000L);//测试使用n天为条件，此处n= 30
		StringBuilder sql0 = new StringBuilder();
		StringBuilder sql1 = new StringBuilder(" select count(p.partid) ");
		StringBuilder sql2 = new StringBuilder();
		sql2.append("select d.areaname, d.areaid, b.nodepkid, b.nodename,b.address, b.telephone,b.start_date, b.gpspos, b.companyid, "); 
		sql2.append(" c.companycode, c.companyname, a.dataid, a.pkid, a.data_date, a.degree1, a.degree2, a.data1, a.data2 ");
		sql2.append(" , a.partstatus,  a.usercode, a.temperature, p.partid, p.colcode, p.selfcode ");			
		sql0.append(" from part p, equipment e,node b, company c, area d, datainfo a  where 1=1 ");
		if(!StringUtils.isBlank(nodeid))
			sql0.append(" and b.nodepkid in(" + nodeid + ") ");
		sql0.append(" and p.pkid = a.pkid and p.usercode = a.usercode and  a.pkid = e.pkid and e.nodepkid = b.nodepkid and d.AREAID =b.AREAID and c.COMPANYID = b.COMPANYID ");
		sql0.append(" and a.data_date >'" + temp + "' "); 
		sql0.append(" order by a.DATA_DATE desc, a.PKID asc, p.colcode asc, a.selfcode asc ");
		
		long total= baseDao.countBySQL(sql1.append(sql0).toString());
		int[] pInfo = AppUtil.setStartPage(pageInfo);			
		List modelList = equipStatusModelDao.findBySQL(sql2.append(sql0).toString(), pInfo[0], pInfo[1]);	
		List<EquipStatusModel> list = new ArrayList<EquipStatusModel>();
		for(int i=0; i<modelList.size(); i++){
			Map m = (Map)modelList.get(i);
			String areaname = (String)m.get("areaname");
			Integer areaid = (Integer)m.get("areaid");
			String nodeid_ = (String)m.get("nodepkid");
			String nodename = (String)m.get("nodename");
			String address = (String)m.get("address");
			String telephone = (String)m.get("telephone");
			Date start_date = (Date)m.get("start_date");
			String gpspos = (String)m.get("gpspos");
			String companycode = (String)m.get("companycode");
			String companyname = (String)m.get("companyname");
			Integer dataid = (Integer)m.get("dataid");
			String pkid = (String)m.get("pkid");
			Date data_date = (Date)m.get("data_date");
			
			Double degree1 = (Double)m.get("degree1");
			Double degree2 = (Double)m.get("degree2");
			String data1 = (String)m.get("data1");
			String data2 = (String)m.get("data2");
			
			Integer partid = (Integer)m.get("partid");
			String selfcode = (String)m.get("selfcode");
			String colcode = (String)m.get("colcode");
			String usercode = (String)m.get("usercode");
			Double temperature= (Double)m.get("temperature");		
			String partstatus = (String)m.get("partstatus");			
			EquipStatusModel o = new EquipStatusModel(areaname, areaid, nodeid_,nodename, address, telephone, start_date, gpspos, 
					companycode, companyname, dataid, pkid, data_date, degree1, degree2, data1, data2
					, selfcode, usercode, temperature, partid,null, colcode
					);
			String t = "停止";
			if(partstatus!=null){
				if(partstatus.equals("1"))
					t = "运行";
				else if(partstatus.equals("2")){
					t="停止";
				}else if(partstatus.equals("3")){
					t="故障";
				}else{
					t="未知状态";
				}
			}
			o.setPartstatus(t);
			list.add(o);				
		}	
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("total", total);
		map.put("rows", list);
		return map;
	}
	
	//*********************** 20171215 ***********************************
	@Override
	public HashMap<String, Object> findRuntimeStatus0(String nodeid){
		StringBuilder sql = new StringBuilder();
	System.out.println("@@@@@@@@@@@@@");	
		/* node status */
		/* equipment status */
		/* part status*/		
		List<String> pkidList = this.getPKIDsList(nodeid);
        if (pkidList.size()<1)	return null;		
		List<EquipConfModel> confList = this.getEquipConfModelList(nodeid);
		
		ObjectMapper mapper = new ObjectMapper();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
        mapper.setDateFormat(dateFormat); 
		JsonNode jsonNode=null;
		try {
			String strConf = mapper.writeValueAsString(confList);		
			jsonNode = mapper.readTree(strConf);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	
		RuntimeStatusModel oStatus= new RuntimeStatusModel();
		sql = new StringBuilder();
		sql.append("select d.areaname, d.areaid, n.nodepkid, n.nodename, n.address, n.telephone,n.start_date, n.gpspos,  "); 
		sql.append(" c.companycode, c.companyname, a.dataid, a.pkid, a.data_date, a.degree1, a.degree2, a.data1, a.data2 ");

		sql.append(" ,  a.first_primary_pump_freq, a.first_assistant_pump_freq, a.second_primary_pump_freq, a.second_assistant_pump_freq ");
		sql.append(" ,  a.partstatus, a.temperature, p.partid, p.colcode , p.selfcode, p.usercode ");
		sql.append(" ,  a.runningstatus, a.alarmstatus, a.firstsupplytemper, a.firstbacktemper, a.secondsupplytemper, a.secondbacktemper, a.shifting ");
		
		sql.append(" from part p, equipment e,node n, company c, area d, datainfo a, ");
		sql.append(" (select pkid,max(data_date) data_date from datainfo group by pkid) b ");
		sql.append(" where p.pkid = a.pkid and p.usercode = a.usercode and a.pkid = b.pkid and b.pkid = e.PKID and e.nodepkid = n.nodepkid and n.COMPANYID = c.COMPANYID and n.AREAID = d.AREAID");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and n.nodepkid in(" + nodeid + ") ");
		//sql.append(" #and a.pkid in(select e.pkid from equipment e) ");
		//sql.append(" #and EXISTS(select e.pkid from equipment e where e.pkid = a.pkid) ");
		sql.append(" and a.data_date = b.data_date order by a.pkid, a.data_date, a.selfcode asc ");	

		List modelList = equipStatusModelDao.findBySQL(sql.toString());	
		List<EquipStatusModel> list = new ArrayList<EquipStatusModel>();
		for(int i=0; i<modelList.size(); i++){
			Map m = (Map)modelList.get(i);
			String areaname = (String)m.get("areaname");
			Integer areaid = (Integer)m.get("areaid");
			String nodeid_ = (String)m.get("nodepkid");
			String nodename = (String)m.get("nodename");
			String address = (String)m.get("address");
			String telephone = (String)m.get("telephone");
			Date start_date = (Date)m.get("start_date");
			String gpspos = (String)m.get("gpspos");
			String companycode = (String)m.get("companycode");
			String companyname = (String)m.get("companyname");
			Integer dataid = (Integer)m.get("dataid");
			String pkid = (String)m.get("pkid");
			Date data_date = (Date)m.get("data_date");
			
			Double degree1 = (Double)m.get("degree1");
			Double degree2 = (Double)m.get("degree2");
			String data1 = (String)m.get("data1");
			String data2 = (String)m.get("data2");
			
			Integer partid = (Integer)m.get("partid");
			String colcode = (String)m.get("colcode");
			String selfcode = (String)m.get("selfcode");
			String usercode = (String)m.get("usercode");
			Double temperature= (Double)m.get("temperature");

			Double freq_primary1 = (Double)m.get("first_primary_pump_freq");
			Double freq_assistant1 = (Double)m.get("first_assistant_pump_freq");
			Double freq_primary2 = (Double)m.get("second_primary_pump_freq");
			Double freq_assistant2 = (Double)m.get("second_assistant_pump_freq");
			
			String partstatus = (String)m.get("partstatus");
			
			EquipStatusModel o = new EquipStatusModel(areaname, areaid, nodeid_,nodename, address, telephone, start_date, gpspos, 
					companycode, companyname, dataid, pkid, data_date, degree1, degree2, data1, data2
					, selfcode, usercode, temperature, partid, null, colcode);
			
			o.setPartstatus(partstatus);  //return integer number to canvas
			list.add(o);
			
			if(i==0){
				Double supply1 = (Double)m.get("firstsupplytemper");
				Double supply2 = (Double)m.get("secondsupplytemper");
				Double back1 = (Double)m.get("firstbacktemper");
				Double back2 = (Double)m.get("secondbacktemper");
				Integer shift = (Integer)m.get("shifting");
				oStatus = new RuntimeStatusModel( supply1, back1,supply2, back2);
				oStatus.setFreqs(freq_primary1, freq_assistant1, freq_primary2, freq_assistant2);	
				oStatus.setShifting(shift);
			}
			Integer runningstatus = (Integer)m.get("runningstatus");
			String alarmstatus = (String)m.get("alarmstatus");		
			if (runningstatus !=null && runningstatus != 1)
				oStatus.setRunningstatus(runningstatus);
			if(alarmstatus!=null)
				oStatus.setPartalarm(1);
			int temperAlarm = this.getTemperatureAlarm(jsonNode, pkid, temperature);		
			if(temperAlarm != 0)
				oStatus.setTemperalarm(1);
			
		}
		
		HashMap<String, Object> map = this.groupEquips(pkidList, list);
		map.put("runtimeStatus", oStatus);
		map.put("confParams", confList);
		return map;
	}
	/*获取30天数据*/
	
	@SuppressWarnings("unchecked")
	/*获取最新一个站点记录OK*/
	@Override
	public HashMap<String, Object> getLatestInfo(String nodeid){
	/* Node Status*/
		StringBuilder sql = new StringBuilder();
		sql.append("select ns.nodepkid, ns.data_date ");
		sql.append(" , ns.first_primary_pump_freq as freq_primary1, ns.first_assistant_pump_freq as freq_assistant1, ns.second_primary_pump_freq as freq_primary2, ns.second_assistant_pump_freq as freq_assistant2 ");
		sql.append(" , ns.first_supply_temper as firstsupplytemper, ns.first_back_temper as firstbacktemper, ns.second_supply_temper as secondsupplytemper, ns.second_back_temper as secondbacktemp ");
		sql.append(" , ns.runningstatus, ns.automatic as auto, ns.manual, ns.part_alarm, ns.temperature_alarm, ns.pump_alarm, ns.topdown, ns.suddenstop ");
		sql.append(" from nodestatus ns ");
		sql.append(" , (select nodepkid, max(data_date) data_date from nodestatus where nodepkid = '" + nodeid+"' ) b");
		sql.append(" where 1 = 1 ");
		sql.append(" and  ns.nodepkid = b.nodepkid and ns.data_date = b.data_date ");
		List staList = baseDao.findBySQL(sql.toString());
		if(staList.size() == 0) return null;
		/*
		RuntimeStatusModel oStatus = new RuntimeStatusModel();
		Map m = (Map) staList.get(0);
		Date date =((Date) m.get("data_date")); 
		*/
		//*
		Map oStatus = (Map) staList.get(0);
		Date date =((Date) oStatus.get("data_date")); 
		if((System.currentTimeMillis()-date.getTime())> 1000*60L){
			oStatus.put("comm", 0);//数据库接收数据失败
		}
		else
			oStatus.put("comm", 1);
		//*/
		/*
		Double supply1 = (Double)m.get("first_supply_temper");
		Double supply2 = (Double)m.get("second_supply_temper");
		Double back1 = (Double)m.get("first_back_temper");
		Double back2 = (Double)m.get("second_back_temper");
		Double freq_primary1 = (Double)m.get("first_primary_pump_freq");
		Double freq_assistant1 = (Double)m.get("first_assistant_pump_freq");
		Double freq_primary2 = (Double)m.get("second_primary_pump_freq");
		Double freq_assistant2 = (Double)m.get("second_assistant_pump_freq");			
		       		        		
		oStatus = new RuntimeStatusModel(supply1, back1,supply2, back2);
		oStatus.setFreqs(freq_primary1, freq_assistant1, freq_primary2, freq_assistant2);	
		oStatus.setData_date(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(date));//********0180125***OK
		//根据需求调整
		Integer runningstatus = Integer.parseInt(m.get("runningstatus").toString());
		runningstatus = 1;
		Integer shift = (Integer)m.get("shifting");
		shift = 1;
		oStatus.setShifting(shift);
		oStatus.setRunningstatus(runningstatus);*/
		//当前站点所有设备中换能器的最新状态partstatus.partstatus
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); 
		StringBuilder sqlStatus = new StringBuilder("select distinct ps.partstatus from partstatus ps  , equipment e where 1 = 1 ");
		sqlStatus.append("and ps.PKID = e.PKID  and ps.data_date = '");
		sqlStatus.append(dateFormat.format(date));
		sqlStatus.append("' and e.nodepkid = '");
		sqlStatus.append(nodeid);
		sqlStatus.append("'");
		List statusList = baseDao.findBySQL(sqlStatus.toString());
		/****** 20180123   0没有, 1 开 , 2 关闭 , 3 故障   ******/
		/******  运行状态：超过1分钟没有数据视为停止，运行显示灰色  *******/
		/*
		int k = 1;//partstatus->runtimeStatus.partalarm  【2，1，0】 1=green正常，0故障orange， 2停止=grey
		for(int i=0; i<statusList.size(); i++){
			Map map0 = (Map)statusList.get(i); 
			if(!((String)map0.get("partstatus")).toString().equals("1")){
				k = 0;//正常，显示绿色
				break;
			}
		}
		System.out.println("** k= *** " + k); 
		oStatus.setPartalarm(k);		
		
		oStatus.setTemperalarm(1);//(int temperAlarm = this.getTemperatureAlarm(jsonNode, pkid, temperature););
		oStatus.setTopdown(1);
		int auto = 1;
		oStatus.setAuto(auto);
		*/
System.out.println("****** oStatus ****** "+oStatus);			
		/*int temperAlarm = this.getTemperatureAlarm(jsonNode, pkid, temperature);*/	
		/*Equipment Status : distinct 'pkid' record with properties */
		ArrayList tempList = this.getEquipListByNodePKID(nodeid, date);		
		/*Part Status*/
		ArrayList<String> pkidList = new ArrayList<String>();
		ArrayList<EquipmentStatusModel> equipList = new ArrayList();
		StringBuilder t = new StringBuilder("");
		for(int n = 0; n < tempList.size(); n++){
			Map map = (Map) tempList.get(n);
			String pkid = (String)map.get("pkid");
			Double temperature = (Double)map.get("temperature");
			Double waterlevel = (Double)map.get("water_level");
			String valvetop = (String)map.get("valve_top");
			String valvebottom = (String)map.get("valve_bottom");
			EquipmentStatusModel o = new EquipmentStatusModel(date,pkid, temperature,waterlevel,valvetop, valvebottom);
			t.append(pkid + ",");
			pkidList.add(pkid);
			equipList.add(o);
		}
		/*PKID collection to get part list*/
		String pkids = t.substring(0, (t.length()-1));
		tempList = this.getPartListByPKIDs(pkids, date);/* find in partstatus */
		for(int j=0; j<equipList.size(); j++){
			EquipmentStatusModel eO = equipList.get(j);
			pkids = eO.getPkid();
			String colcode0 = null;
			if(tempList != null && tempList.get(0) != null){  /******* 20180122 ******/
				colcode0 =  (String)((Map)tempList.get(0)).get("colcode");
			}else
				break;
			ArrayList subList = new ArrayList();
			List<PartStatusModel> partList = new ArrayList<PartStatusModel>();
			for(int i=0; i<tempList.size(); i++){	
				Map map = (Map)tempList.get(i);
				String pkid = (String)map.get("pkid");
				String colcode = (String)map.get("colcode");
				PartStatusModel o = new PartStatusModel(pkid, colcode, 
						(String)map.get("selfcode"), (String)map.get("usercode"), (String)map.get("partstatus"));				
				if(pkids.equals(pkid)){
					if(!colcode.equals(colcode0)){
						subList.add(partList); 
						colcode0 = colcode;
						partList = new ArrayList<PartStatusModel>();
					}
					partList.add(o); 
					tempList.remove(i);
					i -= 1;
					if(tempList.isEmpty()) {
						subList.add(partList); break;
					}
				}else{
					if(partList.size()>0) { subList.add(partList); }
					break;  //已经按照pikid排序，不同则是另一组设备//continue;
				}
			}
			if(subList.size()>0){
				eO.setPartlist(subList);
			}			
		}
		//return equipList;
		//System.out.println("*** ### @@@ Equipments with GroupedPartList @@@ ### *** \n" + equipList);
		HashMap <String, Object> map= new HashMap<String,Object>();
		map.put("pkidList", pkidList);
		map.put("datainfo", equipList);
		map.put("runtimeStatus", oStatus);
		List<EquipConfModel> confList = this.getEquipConfModelList(nodeid);
		map.put("confParams", confList);
		return map;
	}

	private ArrayList getPartListByPKIDs(String pkids, Date date) {
		StringBuilder sql = new StringBuilder();
		sql.append("select distinct ps.data_date, ps.pkid, ps.usercode, ps.partstatus, p.colcode, p.selfcode ");
		sql.append(" from part p, partstatus ps ");
		sql.append(" where p.pkid = ps.pkid and p.usercode = ps.usercode and ps.data_date = '");
		sql.append(date);
		sql.append("' and ps.pkid in(" + pkids + ") ");
		//sql.append(" #and EXISTS(select e.pkid from equipment e where e.pkid = a.pkid) ");
		
		//sql.append(" order by ps.pkid desc, p.colcode asc, p.selfcode asc ");
		sql.append(" order by ps.pkid asc, p.colcode asc, p.selfcode asc ");
		ArrayList modelList = (ArrayList) baseDao.findBySQL(sql.toString());
		//System.out.println("****** getPartByPKIDs ****** \n"+modelList);
		return modelList;
	}
	private ArrayList getEquipListByNodePKID(String nodeid, Date date) {
		StringBuilder sql = new StringBuilder("");
		sql.append("select distinct es.pkid, es.temperature, es.water_level, es.valve_top, es.valve_bottom, es.data_date ");//增加es.data_date****20180125 
		//sql.append(" c.companycode, c.companyname,");
		sql.append(" from  equipment e,node n, area d, equipmentstatus es ");
		//sql.append(" ,company c ");
		sql.append(" where e.pkid = es.pkid and n.nodepkid = e.nodepkid  ");
		//sql.append(" and n.COMPANYID = c.COMPANYID ");
		sql.append(" and n.AREAID = d.AREAID");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and n.nodepkid in(" + nodeid + ") ");

		//sql.append(" and es.data_date = '"+ date +"' order by es.pkid desc ");
		sql.append(" and es.data_date = '"+ date +"' order by es.pkid asc ");	
		List modelList = baseDao.findBySQL(sql.toString());		
		//System.out.println("****** getEquipByNodePKID ****** \n"+modelList);
		return (ArrayList) modelList;
	}

	@Override
	public AjaxResult countEquips(String nodeid) {
		StringBuilder sql = new StringBuilder("select count(distinct e.pkid) from Equipment e where 1 = 1 ");
		if(!StringUtils.isBlank(nodeid))
			sql.append(" and e.nodepkid = " + nodeid);
		long count = baseDao.countBySQL(sql.toString());
		if(count>0)
			return new AjaxResult(1, "找到设备");
		return new AjaxResult("站点尚未建设完成");
	}
	
	/*从nodeconf， equipmentconf获取配置信息，初始化状态，****** 待修改 ******/
	public void getEquipConfig(String nodeid){
		List<EquipConfModel> confList = this.getEquipConfModelList(nodeid);
		
		ObjectMapper mapper = new ObjectMapper();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");  
	    mapper.setDateFormat(dateFormat); 
		JsonNode jsonNode=null;
		try {
			String strConf = mapper.writeValueAsString(confList);		
			jsonNode = mapper.readTree(strConf);
		} catch (JsonProcessingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		//int temperAlarm = this.getTemperatureAlarm(jsonNode, pkid, temperature);
	}
	/*********** 20180121 *************/
	@Override  							/*分页显示状态 partstatus, equipmentstatus, nodestatus*/
	public HashMap<String, Object> findEquipStatusTableItems(String nodeid, String[] pageInfo, String[] sortInfo){
		Date date= new Date(System.currentTimeMillis());
		List<String> pkidList = this.getPKIDsList(nodeid);
		String pkids = StringUtils.join(pkidList.toArray(), "','");
		long n = 60L;//测试使用n=60天为条件//******************
		java.sql.Date dateTemp = new java.sql.Date(date.getTime() - n*24L*60L*60L*1000L);
		StringBuilder sql0 = new StringBuilder();
		StringBuilder sql1 = new StringBuilder(" select count(ps.partstatusid) ");
		StringBuilder sql2 = new StringBuilder();
		sql2.append("select ps.partstatusid, ps.data_date, p.pkid,p.colcode,p.selfcode,p.usercode,ps.partstatus ");  
		sql2.append(" , es.temperature, es.valve_top,es.valve_bottom ");
		sql0.append(" from partstatus ps, part p, equipmentstatus es "); 
		sql0.append(" where 1=1  and ps.pkid in ('");
		sql0.append(pkids);
		sql0.append("') and ps.data_date>'");
		sql0.append(dateTemp);
		sql0.append("' and p.pkid = ps.pkid and p.usercode = ps.usercode and  es.pkid = p.pkid "); 
		sql0.append(" and ps.data_date = es.data_date ");
		sql0.append(" order by ps.data_date desc, ps.pkid asc, p.colcode asc, p.selfcode asc ");
		
		//List<EquipStatusModel> list = equipStatusModelDao.findBySQL(sql.toString());
		
		long total= baseDao.countBySQL(sql1.append(sql0).toString());
System.out.println("@@@@@@@@@total in table: " + total + "\n pageinfo " + Arrays.toString(pageInfo));

		int[] pInfo = AppUtil.setStartPage(pageInfo);			
		List modelList = equipStatusModelDao.findBySQL(sql2.append(sql0).toString(), pInfo[0], pInfo[1]);		
		//List<EquipStatusModel> list = new ArrayList<EquipStatusModel>();		
System.out.println(modelList.size() + "***************list to be paginated: " + modelList);		
		for(int i=0; i<modelList.size(); i++){
			Map m = (Map)modelList.get(i);
			Double temperature= (Double)m.get("temperature");		
			String partstatus = (String)m.get("partstatus");
			StringBuilder alarm=new StringBuilder("");
			/*String t = "停止";   
			if(partstatus!=null){
				if(partstatus.equals("1")){
					t = "运行"; 
				}
				else if(partstatus.equals("2")){
					t="停止";
				}else if(partstatus.equals("3")){
					t="故障"; alarm.append("换能器报警 ");
				}else{
					t="未知状态";
				}
			}*/
			if(temperature != null){  
				if(temperature > 90){  //****20180122
					alarm.append("\n温度超上限 ");
				}else if(temperature < 20){
					alarm.append("\n温度低于下限 ");
				}
			}
			if(alarm.length() ==0)
				alarm.append("无");

			//m.put("partstatus",t);
			m.put("alarmstatus", alarm);		
		}
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put("total", total);
		map.put("rows", modelList);
		return map;
	}
	public String getEquipStatus(String alarmTime, String vserrflag, String vssts1) {
		long longIntervals = 24*60*60*1000;
		String strStatus = "3";
		Date date= new Date(System.currentTimeMillis());
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");		//24小时制必须使用大写HH
		Date temp =null;
		try{
			temp = formatter.parse(alarmTime);									//数据库中获取的报警时间
			
			if((date.getTime() - temp.getTime()) < longIntervals){    		//当前系统时间与最后一条记录的时间差小于45s,则认为有信号, 替换下面的条件
			//if((date.getTime() - temp.getTime()) > 0){			//时间差<45，认为detail为最后状态，否则认为无信号					
				if(!"0".equals(vserrflag))												//故障:轻故障为2，故障为3，无故障为0，两种为1
					strStatus = "2";
				else{
					if(true)//DataToStatus.valueOnBitPos(vssts1,0).equals("1"))				//VSSTS1的bit0
						strStatus = "0";												//运行
					else
						strStatus = "1";												//停止
				}
			}			
			else{
				System.out.println("无信号");
			}
		}catch(ParseException e){
			e.printStackTrace();
		} 
		return strStatus;
	}
}
