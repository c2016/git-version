package com.monitor.controller;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.monitor.entity.Area;
import com.monitor.entity.Equipment;
import com.monitor.entity.Menu;
import com.monitor.model.UserModel;
import com.monitor.service.AreaService;
import com.monitor.service.UserService;
import com.monitor.util.Constants;

@Controller
@RequestMapping("/sys")
public class SysController {
	@Resource
	UserService userService;
	@Resource
	AreaService areaService;
	/*test begin*/
	@RequestMapping(value="/testing", method=RequestMethod.GET)
	public String testingPage(){
		return "node/TestJsp";
	}
	@RequestMapping(value="/loadTotal", method=RequestMethod.POST)
	public @ResponseBody String testingTable(){
		return areaService.loadTotal();
	}
	/*test end*/
	@RequestMapping(value = "/loadNavigation", method = RequestMethod.POST)
	public @ResponseBody List<Menu> loadNavigator(HttpSession session){
		UserModel user = (UserModel)session.getAttribute(Constants.SESSION_USER);//读session获取用户名
	System.out.println(user);
		if( user != null ){	
			return userService.findMenuList(user);
		}
		return null;
	}
	@RequestMapping(value="/home", method= { RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getHomepage(UserModel user,ModelAndView mv, HttpSession session, HttpServletRequest request){
		
		//HashMap<String, String> mapArea = new HashMap<String, String>();
		user = (UserModel) session.getAttribute(Constants.SESSION_USER);
		if(user != null){
			if(user.getUsername().equals("superadmin")){				
				List<Area> provinces = areaService.listProvinces(user);
				mv.addObject("provinces", provinces);
			}
			else{
				List<Area> provinces = areaService.listProvinces(user);
				String provID = provinces.get(0).getAreaid().toString();
				List<Area> cities = areaService.listCities(user, provID);
				String cityID = cities.get(0).getAreaid().toString();
				List<Area> regions = areaService.listRegions(user, provID, cityID);
				mv.addObject("provinces", provinces);
				mv.addObject("cities", cities);
				mv.addObject("regions", regions);
			}
			mv.addObject("currentUser", request.getSession().getAttribute(Constants.SESSION_USER));
			mv.setViewName("sys/default");
		}
		else{
			mv.setViewName(request.getContextPath()+"/index");
		}
		return mv;
	}
	@RequestMapping(value = "/viewEquipList", method = {RequestMethod.GET, RequestMethod.POST})
	public ModelAndView loadHomeHead(ModelAndView mv, HttpServletRequest request){
		mv.addObject("provinceid", request.getParameter("provinceid"));
		mv.addObject("cityid", request.getParameter("cityid"));
		mv.addObject("regionid", request.getParameter("regionid")) ;
		mv.setViewName("equipment/equipmentstatus");
		return mv;
	}
	@ResponseBody
	@RequestMapping(value = "/getcities", method = {RequestMethod.GET, RequestMethod.POST})
	public List<Area> loadCityList(@RequestParam String id, HttpSession session, UserModel user){
		return areaService.listCities(user, id);
	}
	@ResponseBody
	@RequestMapping(value = "/getregions", method = {RequestMethod.GET, RequestMethod.POST})
	public List<Area> loadRegionList(@RequestParam String provinceid, @RequestParam String id, HttpSession session, UserModel user){
		return areaService.listRegions(user, provinceid, id);
	}
	@ResponseBody
	@RequestMapping(value = "/loadMarks", method = {RequestMethod.GET, RequestMethod.POST})
	public List<Equipment> loadMardList(@RequestParam("provinceid") String provinceid, @RequestParam("cityid") String cityid,
			@RequestParam("regionid") String regionid, @RequestParam("companyid") String companyid, HttpSession session, UserModel user){
		
		return null;//companyService.listMarks(user, provinceid, cityid, regionid, companyid);
	}
	@RequestMapping(value = "/mark", method =  {RequestMethod.GET, RequestMethod.POST})
	public String loadMark(){		
		return "sys/mark";
	}
}
