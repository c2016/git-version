package com.monitor.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.monitor.service.PartService;
import com.monitor.util.AjaxResult;

@Controller
@RequestMapping("/part")
public class PartControlller {
	@Resource
	PartService partService;
	
	@RequestMapping(value = "/getCount" , method = {RequestMethod.GET, RequestMethod.POST})
	public @ResponseBody AjaxResult getCount(@RequestParam String nodeid){
		return partService.countParts(nodeid);
	}
	
}
