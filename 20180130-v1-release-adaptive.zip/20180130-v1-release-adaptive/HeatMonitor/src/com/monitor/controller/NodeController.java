package com.monitor.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.monitor.model.EquipmentStatusModel;
import com.monitor.model.NodeModel;
import com.monitor.model.PartStatusModel;
import com.monitor.service.AreaService;
import com.monitor.service.CompanyService;
import com.monitor.service.EquipmentService;
import com.monitor.service.NodeService;
import com.monitor.service.UserService;
import com.monitor.util.AjaxResult;
import com.monitor.util.AppUtil;

@Controller
public class NodeController {
	@Resource
	UserService userService;
	@Resource
	AreaService areaService;
	@Resource
	CompanyService companyService;
	@Resource
	NodeService nodeService;
	@Resource
	EquipmentService equipmentService;
	
	@ResponseBody
	@RequestMapping(value="node/getNodes", method=RequestMethod.POST)
	public AjaxResult getNodes(HttpServletRequest request, HttpServletResponse response){
		System.out.println("get nodes!");
		String areaid = request.getParameter("areaid");
		String companyid = request.getParameter("companyid");
		String nodeid = request.getParameter("nodeid");
		return nodeService.listNodes(areaid, companyid, nodeid);
		//return new AjaxResult("加载储热节点失败，请联系管理员");
	}
	@ResponseBody
	@RequestMapping(value="node/getStatus",  method= { RequestMethod.GET, RequestMethod.POST})
	public ModelAndView getStatus(ModelAndView mv, HttpServletRequest request, HttpServletResponse response){
		System.out.println("get status page!");
		String nodeid = request.getParameter("nodeid");
		String nodename = request.getParameter("nodename");
		String areaid = request.getParameter("areaid"); 
		String companyid = request.getParameter("companyid");
	//返回所有有设备信息的地图显示的节点信息
		mv.addObject("nodeList", nodeService.listNodes(null, null));//完整的节点信息
long d1 = System.currentTimeMillis();
		mv.addAllObjects(equipmentService.getLatestInfo(nodeid));
		long d2 = System.currentTimeMillis();
		System.out.println("It spends "+(d2-d1)+". @@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@");
		
		mv.setViewName("node/status");
		return mv;
	}
	@ResponseBody
	@RequestMapping(value="node/latestInfo",  method= { RequestMethod.GET, RequestMethod.POST})
	public String getLatestInfo(Model model, HttpServletRequest request, HttpServletResponse response){
		System.out.println("get latest status!");
		String nodeid = request.getParameter("nodeid");
		String nodename = request.getParameter("nodename");
		String areaid = request.getParameter("areaid"); 
		String companyid = request.getParameter("companyid");
	long d1 = System.currentTimeMillis();
		HashMap map = equipmentService.getLatestInfo(nodeid);
System.out.println("### 新版 ### \n" +AppUtil.object2Json(map));
	long d2 = System.currentTimeMillis();
System.out.println("It spends "+(d2-d1)+". *****************************************************");
		return AppUtil.object2Json(map);
	}
}
