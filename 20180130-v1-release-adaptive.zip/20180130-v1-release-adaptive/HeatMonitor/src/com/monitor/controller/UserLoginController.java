package com.monitor.controller;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.shiro.SecurityUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.monitor.entity.User;
import com.monitor.model.UserModel;
import com.monitor.service.UserService;
import com.monitor.util.AjaxResult;
import com.monitor.util.Constants;
import com.monitor.util.Util;

@Controller
public class UserLoginController {

	@Resource
	private UserService userService;

	@RequestMapping(value="/index", method={RequestMethod.POST, RequestMethod.GET})
	public ModelAndView index(UserModel user, HttpSession session) {
		//用户验证
				ModelAndView mv = new ModelAndView();		
				String errorInfo = "";				
				if(user.getUsername()==null){
					user = (UserModel)session.getAttribute(Constants.SESSION_USER);
					if( user == null){
						mv.addObject("errorInfo", "您尚未登录！请登录后使用本系统。");
						mv.setViewName("index");//mv.setViewName("../../login");
						return mv;
					}
				}
				else  
					user.setPassword( Util.encryptMD5(user.getPassword()));				
				//User user0 = userService.getLoginuser(user.getUsername().trim());
				UserModel user0 = userService.getLoginuser(user.getUsername().trim());
System.out.println("Login:user0:model:  " + user0);				
				if(user0 == null)
					errorInfo = "用户不存在，请重新输入！";
				else{ 
					if(!user0.getPassword().equals(user.getPassword()))
						errorInfo = "密码不正确，请重新输入！";
					else{
						errorInfo = "";
						/*if(user.getUsername().equals("superadmin")){	errorInfo = "";		}
						else{
							boolean result = userService.checkUserRole(user0);//检查是否有权限
							if(result)		errorInfo = "";
							else			errorInfo = "你目前还没有使用本系统的权限，<br>请联系管理员！";
						}*/
					}
				}
				if(errorInfo.isEmpty()){					
					session.setAttribute(Constants.SESSION_USER, user0);//写入session
					session.removeAttribute(Constants.SESSION_SECURITY_CODE);
					Constants.LOGIN_USER = user0.getUsername();
					//mv.addObject("companyID", user0.getCompanyid());
					//UserModel->session
					mv.addObject("user", user0);
					mv.setViewName("default");
				}
				else{
					mv.addObject("errorInfo", errorInfo);
					mv.setViewName("index");//("redirect:" + basePath);
				}
				return mv;
	}	
	@RequestMapping("/changeuser")//密码修改窗口
	public String changeUser(Model model, HttpSession session) throws IOException{
		return "user/changeuser";
	}
	@RequestMapping("/userChanged")//密码修改窗口
	public AjaxResult userChanged(Model model, HttpSession session) throws IOException{
		session.setAttribute(Constants.LOGIN_USER, "");
		session.setAttribute(Constants.SESSION_USER, null);
		session.invalidate(); 
		Constants.LOGIN_USER = "";
		return new AjaxResult("To do");
	}
	@RequestMapping("/modpassword")//密码修改窗口
	public String modPassword(Model model, HttpSession session) throws IOException{
		//String uname = new String(request.getParameter("username").getBytes("iso-8859-1"), "utf-8");
		UserModel u =  ((UserModel) session.getAttribute(Constants.SESSION_USER));
		String uname = u.getUsername();
		model.addAttribute("username", uname);	
		model.addAttribute("user", u);
		return "user/modpassword";
	}
	@RequestMapping(value="/modifyPW", method = RequestMethod.POST)//写数据库operator窗口
	public @ResponseBody AjaxResult  modifyPW(HttpServletRequest request, HttpSession session) throws IOException{
		String pw = request.getParameter("password1").trim();
		String password = request.getParameter("password2").trim();
		UserModel user;
		user = (UserModel) session.getAttribute(Constants.SESSION_USER);
		AjaxResult res = new AjaxResult("网络异常，请联系管理员");
		if(user != null){			
			if(Util.encryptMD5(pw).equals(user.getPassword())){
				//修改密码
				res = userService.updatePassword(user, password);
				if(res.getRetcode() == 1){
					session.removeAttribute(Constants.SESSION_USER);
					user.setPassword(Util.encryptMD5(password));
					session.setAttribute(Constants.SESSION_USER, user);
				}
				return res;
			}
			else
				res.setRetmsg("原密码错误");
		}
		return res;	
	}
	@RequestMapping(value="/checkPW", method = RequestMethod.POST)
	public @ResponseBody AjaxResult checkPW(HttpServletRequest request, HttpSession session){
		String pw = request.getParameter("password1").trim();
		if(Util.encryptMD5(pw).equals(((UserModel)session.getAttribute(Constants.SESSION_USER)).getPassword())){
			return new AjaxResult(1, "原密码正确");
		}
		else{
			return new AjaxResult("原密码错误");
		}
	}

	//session用户不为空，则删除
	@RequestMapping(value="/logout", method = RequestMethod.POST)//注销用户
	public @ResponseBody Map<String, Object> logoutUser(HttpServletRequest request, HttpSession session,HttpServletResponse response) throws IOException{
		// 清除session		
		if(session.getAttribute(Constants.SESSION_USER) != null){
			//更新Operator的ISONLINE = false;
			UserModel user = (UserModel) session.getAttribute(Constants.SESSION_USER);
			if(user !=  null){				
				userService.updateOperatorStatus(user.getUser_id(), false);			
				//session.removeAttribute(Constants.SESSION_USER);
				Enumeration<String> em = request.getSession().getAttributeNames();
			    while (em.hasMoreElements()) {			 
			    	String strSession = em.nextElement().toString();
					request.getSession().removeAttribute(strSession);
				}
				request.getSession().invalidate();
				Constants.LOGIN_USER ="";
				System.out.println("exit......");
				response.sendRedirect(request.getContextPath()+"/index.jsp");
			}
		}
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("logout","已退出系统");
		return map;		
		//return "../../login";			
	}
	
	/*@RequestMapping("/logout")
	public void logout(HttpServletRequest request, HttpServletResponse response) throws IOException {
		//退出权限验证
		//SecurityUtils.getSubject().logout();
		//销毁session
		request.getSession().invalidate(); 
		response.sendRedirect(request.getContextPath()+"/index.jsp");
	}*/
}
