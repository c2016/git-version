package com.monitor.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.monitor.model.UserModel;
import com.monitor.service.AreaService;
import com.monitor.service.EquipmentService;
import com.monitor.service.NodeService;
import com.monitor.service.UserService;
import com.monitor.util.Constants;

@Controller
public class NavigationContoller {
	//final Logger logger = LoggerFactory.getLogger(NavigationContoller.class);
	@Resource
	UserService userService;
	@Resource
	AreaService areaService;
	@Resource
	NodeService nodeService;
	@Resource
	EquipmentService equipmentService;

	//#############################
	@RequestMapping(value="node/status", method=RequestMethod.GET)
	public String gotoStatus(){
		System.out.println("goto status page!");
		return "forward:/node/getStatus";//没有节点参数，则列出所有节点信息
	}
	@RequestMapping(value="node/chart", method=RequestMethod.GET)
	public String gotoChart(Model model){
		System.out.println("goto chart page!");		
		model.addAttribute("nodeList", nodeService.listNodes(null,null));
		//无法foreach？？？
		model.addAttribute("equipList", equipmentService.listEquips(null,null,null));
		return "node/chart";
	}
	@RequestMapping(value="sys/default",  method= { RequestMethod.GET, RequestMethod.POST})
	public ModelAndView gogoDefaultHomePage(UserModel user, ModelAndView mv,HttpSession session){
		user = (UserModel) session.getAttribute(Constants.LOGIN_USER);
        if(user == null){//################################
        	mv.setViewName("index");//mv.setViewName(request.getContextPath()+"/index");
        }
		mv.addObject("user", user);
		//mv.setViewName( "node/default" );
		mv.setViewName( "node/mark" );//使用mark不显示
		return mv;
	}
	//############################
	//*******************************************************************************
	@RequestMapping(value="sys/help", method= { RequestMethod.GET, RequestMethod.POST})
	public String getSysHelp(){
		System.out.println("goto sys/help.jsp page!");
		return "sys/help";
	}
	@RequestMapping(value="assist/statistic", method= { RequestMethod.GET, RequestMethod.POST})
	public String getStatistic(){
		System.out.println("goto statistic.jsp page!");
		return "assist/statistic";
	}
	@RequestMapping(value="equipment/template", method= { RequestMethod.GET, RequestMethod.POST})
	public String getTemplateList(){
		System.out.println("goto template.jsp page!");
		return "equipment/template";
	}
	@RequestMapping(value="issue/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getIssueList(){
		System.out.println("goto inspectormanage.jsp page!");
		return "fault/issuemanage";
	}
	@RequestMapping(value="inspector/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getInspectorList(){
		System.out.println("goto inspectormanage.jsp page!");
		return "inspector/inspectormanage";
	}
	@RequestMapping(value="company/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getCompanyList(){
		System.out.println("goto companymanage.jsp page!");
		return "company/companymanage";
	}
	@RequestMapping(value="check/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getCheckList(){
		System.out.println("goto checkmanage.jsp page!");
		return "check/checkmanage";
	}
	@RequestMapping(value="fault/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getFaultList(){
		System.out.println("goto faultmanage.jsp page!");
		return "fault/faultmanage";
	}
	@RequestMapping(value="favourite/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getFavouriteList(){
		System.out.println("goto favoritemanage.jsp page!");
		return "favourite/favoritemanage";
	}
	@RequestMapping(value="/equipment/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getEquipmentList(){
		System.out.println("goto equipmentmanage.jsp page!");
		return "equipment/equipmentmanage";
	}
	/*由主页点击导航栏，加载usermanage页面*/
	@RequestMapping(value="/user/manage", method= { RequestMethod.GET, RequestMethod.POST})
	public String getUserPage(){
		System.out.println("goto user.jsp page!");
		return "user/usermanage";
	}	
	/*由主页点击导航栏，加载rolemanage页面*/
	@RequestMapping(value="/user/authority", method= { RequestMethod.GET, RequestMethod.POST})
	public String getRolePage(){
		System.out.println("goto rolemanage.jsp page!***");
		return "user/rolemanage";
	}
	
}
//##################################################################
