
	function errorLogin(id,strMsg){
		$(id).empty().append("<strong></strong>" + strMsg).fadeIn();
		setTimeout(function(){$(id).fadeOut();},3000);
	}
	var flag_code = 0;
  	function checkInfo()
	{
  		if(flag_code==0)
		{
		alert("验证码错误，请重新输入!");
		document.getElementById("inputSign").focus();
		return false;
		}
		if(document.getElementById("userName").value==""){
			alert("用户名不能为空!");
			document.getElementById("userName").focus();
			return false;
		}
		if(document.getElementById("inputPassword").value==""){
			alert("密码不能为空!");
			document.getElementById("inputPassword").focus();
			return false;
		}
	}
  	function changeValidateCode(obj){            
  		var timeNow = new Date().getTime();
  		obj.src="checkCode/service.do?time="+timeNow;
  		$("#inputSign").val("");
        $("#falseImage").css("display", "none");
		$("#trueImage").css("display", "none") ;              
  	}	
  	function checkThis(obj){
  		$.ajax( {  
    		type : "get",  
    		url : "checkCode/checkSign",
    		dataType: "json",  
    		success : function(data) { 
    			var val = obj.value;
  				if(val.toLowerCase() == data[0]){
  					document.getElementById("falseImage").style.display="none";
  					document.getElementById("trueImage").style.display="block";
  					flag_code = 1;
  				}
  				else{
  					document.getElementById("trueImage").style.display="none";
  					document.getElementById("falseImage").style.display="block"; 
  					$("#inputSign").value="";		
  					flag_code = 0;		
  				}

    		},  
    		error :function(){  
    			warningmessage("网络连接出错！");  
    		} 
		});
		return false;
  	}

  	function clean() {
		//refreshCode();
		document.getElementById("inputPassword").value = "";
		document.getElementById("userName").value = "";
		document.getElementById("userName").focus();
	}
  	function refreshCode(){
  		var obj = document.getElementById("imgCode");  	
  		changeValidateCode(obj);
  	}

  	$(document).ready(function(){  		  		
 
  		$("#closeBtn").hover(function(){
			console.log("over");
			$("#closeBtn").removeClass("glyphicon-remove").addClass("glyphicon-remove-circle").css("font-size","14px");
		},function(){			
			;$("#closeBtn").removeClass("glyphicon-remove-circle").addClass("glyphicon-remove").css("font-size","8px");		
		});
  		$("#eyestatus")
  		.mousedown(function(){
	  		$("#eyestatus").removeClass("glyphicon-eye-close");
	  		$("#eyestatus").addClass("glyphicon-eye-open");
	  		$("#inputPassword").attr("type", "text");
	  	})
	  	.mouseup(function(){
	  		$("#eyestatus").removeClass("glyphicon-eye-open");
	  		$("#eyestatus").addClass("glyphicon-eye-close");
	  		$("#inputPassword").attr("type", "password");
	  		
	  	})
	  	.mouseleave(function(){
	  		$("#eyestatus").removeClass("glyphicon-eye-open");
	  		$("#eyestatus").addClass("glyphicon-eye-close");
	  		$("#inputPassword").attr("type", "password");
	  		
	  	})
	  	.hover(function(){
	  		$("#eyestatus").css("cursor", "pointer");
	  	},function(){
	  		$("#eyestatus").css("cursor", "default");	  		
	  	});
  		$("#removename").mousedown(function(){
  			$("#userName").val("");
  		})
	  	.hover(function(){
	  		$("#removename").css("cursor", "pointer");
	  	},function(){
	  		$("#removename").css("cursor", "default");	  		
	  	});
  		
  		$("#falseImage").hover(function(){
	  		$("#falseImage").css("cursor", "pointer");
	  	},function(){
	  		$("#falseImage").css("cursor", "default");	  		
	  	})
	  	.click(function(){
	  		$("#inputSign").val("");
	  	});
  	}); 	

  	
  	