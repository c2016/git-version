$(document).ready(function(){
	/*htmlobj=$.ajax({url:"/jquery/test1.txt",async:false});
	$("#myhead").html(htmlobj.responseText);
	*/
	//$("#myhead").load("myHnav.html");

		$(window).resize(function(){
			console.log(document.body.clientWidth);
			if(document.body.clientWidth>850){
				$("#topNav .second").css("display","block");
				$("#topNav .first").css("display","block");
			}
			else if(document.body.clientWidth<650){
				$("#topNav .first").css("display","block");
				$("#topNav .second").css("display","none");
			}
			else {
				$("#topNav .first").css("display","none");
				$("#topNav .second").css("display","block");
			}
			});
	});