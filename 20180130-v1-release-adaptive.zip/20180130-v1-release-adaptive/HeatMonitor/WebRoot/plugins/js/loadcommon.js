var SUCCESS_MSG = "<i class='fa fa-check'></i>成功";
var FAIL_MSG = "<i class='fa fa-check'></i>失败";
function loadPage(reqUrl, displayID, modalID){
	var htmlobj = $.ajax({
			url: reqUrl,
			async:false,
		});
		$("div"+displayID).empty().html(htmlobj.responseText);
		$(modalID).modal('show');
}
function refreshTableToPageOne(tableID){
  	$(tableID).bootstrapTable('selectPage', 1).bootstrapTable('refresh');
}
function getIdSelections(tableId) {
	return $.map($(tableId).bootstrapTable('getSelections'), function(row) {
		return row.id;
	});
}
function deleteRecords(tableId, requestUrl,ids){
	if(undefined == ids){
			ids = getIdSelections(tableId);
			if(ids.length==0) {
				dlgInfo('系统消息', '请选择待删除项！', BootstrapDialog.TYPE_INFO);
				return false;
			} 
		}
	var title='系统消息', message='确定删除选中记录吗?', msgType=BootstrapDialog.TYPE_PRIMARY;   		
	//dlgConfirm('系统消息', '确定删除选中记录吗?', BootstrapDialog.TYPE_PRIMARY, requestUrl + ids, tableId);
	BootstrapDialog.confirm(
            {  title: title,
                message: message,
                type: msgType,
                size : BootstrapDialog.SIZE_SMALL,
                closable: true,
                draggable: true,
                btnCancelLabel: '取消',
                btnOKLabel: '确定', 
                btnOKClass: 'btn-warning',
                callback: function (result) {
                    if (result) {
         				//fnButtonSubmitAjax(requestUrl, tableId, dataParam, dlgId);	
         				$.ajax({
         					url: requestUrl+ids,
         					method: "post"})
         					.done( function (req){
         						if (req.retcode == 1) {
          							//$(tableId).bootstrapTable('refresh');
          							$(tableId).bootstrapTable('refreshOptions',{pageNumber:1,pageSize:10});
         							//refreshTableToPageOne(tableId);
         							//promptMessage("success","成功", req.retmsg);
          							showMessageSuccess("success","成功", req.retmsg);
         							
         			            } else {
         							//dlgInfo('系统消息', req.retmsg, BootstrapDialog.TYPE_WARNING);
         			            	promptMessage("danger","失败", req.retmsg);
         						}
         					})
         					.fail(function(req){	
         						//dlgInfo('系统消息', '网络连接问题，请联系管理员', BootstrapDialog.TYPE_WARNING);
         						promptMessage("danger","失败",'网络连接问题，请联系管理员: reqajax');
         					});
         				
                    }
                }
            });      
}
//success,warning,danger,info
/*function promptMessage(msgType, cnType, msg) {
	var htmlString = 
		'<div class="alert alert-' + msgType + '" id="popMsg">' +
			'<strong>'+cnType+'！&nbsp;&nbsp;</strong><i class=""></i>' + msg + 
		'!</div>';
	$("#messagePrompt").html(htmlString);			
	window.setTimeout(function(){$("#popMsg").alert('close').fadeOut();},2000);
}*/
//promptMessage("success","成功", "修改成功");
function promptMessage(msgType, cnType, msg, id) {
	var popId = "popMsg";
	var msgId = "messagePrompt";
	if(id != null){  popId += id;  msgId += id; }
	var htmlString = 
		'<div class="alert alert-' + msgType + '" id="'+popId+'">' +
			'<strong>******'+cnType+'！&nbsp;&nbsp;</strong><i class=""></i>' + msg + 
		'!</div>';
	$("#"+msgId).html(htmlString);			
	window.setTimeout(function(){$("#"+ popId).alert('close').fadeOut();},2000);
}
//showMessage("success","成功", "操作成功", null);
function showMessageSuccess(msgType, cnType, msg, id) {
	var popMsgID = "#"+msgType+"_";	
	if(id!=null) popMsgID += id;	
	$(popMsgID).empty().append("<strong><i class='fa fa-check fa-fw'></i>成功！</strong>"+msg).fadeIn();
	setTimeout(function(){$(popMsgID).fadeOut();},2000);
}
function showMessageFail(msgType, cnType, msg, id) {
	var popMsgID = "#"+msgType+"_";	
	if(id!=null) popMsgID += id;	
	$(popMsgID).empty().append("<strong><i class='fa fa-times fa-fw'></i>失败！</strong>"+msg).fadeIn();
	setTimeout(function(){$(popMsgID).fadeOut();},3000);
}

//promptMessage("success","成功", "修改成功");
/*验证电话号码*/
	function isValidTelephone(id){
		var $this = $("#"+id);
		var tel = $this.val().trim();
  		var reg = /^\d{1,11}$/;	
		if(!reg.test(tel)){
			$this.val(tel.replace(/[^\d]/g,''));
			return {"retcode": false,"retmsg":"您只能输入0-9的数字"};
		}
  		if(tel.length > 11){
  			result.retcode = false; result.retmsg = "电话号码长度不能超过11！";
  			$this.val(tel.substr(0,11));
  			return {"retcode": false,"retmsg":"电话号码长度不能超过11！"};
  		}
  		return {"retcode":true, "retmsg":""};
  	}
function isEmptyInput(id, promptText){
	var  $this = $("#"+id);
	if($this.val().trim() == ""){
		//alert(promptText + "不能为空！");
		dlgInfo("系统消息", promptText + "不能为空！", BootstrapDialog.TYPE_WARNING);
		$this.focus();
		return true;
	}
	return false;
}

function dlgForm(title, msgType, loadUrl,formId, requestUrl, tableId, verifyUrl){

	BootstrapDialog.show({
        title: title,
        type: msgType,
        message: function (dialog) {
            var $message = $('<div></div>');
            var pageToLoad = dialog.getData('pageToLoad');
            $message.load(pageToLoad);
            return $message;
        },
        size: BootstrapDialog.SIZE_SMALL,//SIZE_WIDE,
        cssClass: "fade",
        closeable: true,
        data: {
            'pageToLoad': loadUrl
        },
        buttons: [{
            label: '<i class="fa fa-times"></i> 取消',
            action: function (dialog) {
                dialog.close();
            }
        }, {
            label: '<i class="fa fa-check"></i> 确定',
            cssClass: 'btn btn-primary',
            action: function (dialog) {
                //success(dialog);            	
            	//if(verifyUrl !=null && !isValidParams(verifyUrl, $("#"+formId).serialize())) return;
            	fnButtonSubmitAjax(requestUrl, tableId, $("#"+formId).serialize(), null);
            	dialog.close();   
            }
        }]
    });
}
function dlgConfirm(title, message, msgType, requestUrl, tableId, dataParam, dlgId, msgDisplayID){
	BootstrapDialog.confirm(
            {
                title: title,
                message: message,
                type: msgType,
                size : BootstrapDialog.SIZE_SMALL,
                closable: true,
                draggable: true,
                btnCancelLabel: '取消',
                btnOKLabel: '确定', 
                btnOKClass: 'btn-warning',
                callback: function (result) {
                    if (result) {
         				fnButtonSubmitAjax(requestUrl, tableId, dataParam, dlgId, msgDisplayID);	
                    }
                }
            });      
}
function dlgInfo(title, message, msgType){
	BootstrapDialog.alert({
       type: msgType,
       title: title,
       message: message,
       draggable : true,
       size : BootstrapDialog.SIZE_SMALL,
       buttonLabel: "确定"
   });
}
//valid params checking ajax ,if success return true e.g. name is usable 
function isValidParams(verifyUrl, dataParam){
	var retval=false;
	$.ajax({
			url: verifyUrl,
			dataType: "json",
			type: "post",
			async: false,
			data: dataParam,
			success: function (req){
				if (req.retcode == 1) retval = true;	
				else
					promptMessage("danger","FAIL", req.retmsg);
			},
			error: function(req){	
				promptMessage("danger","失败",'网络连接问题，请联系管理员: valid params');
			}
		});

	return retval;
}

//add, delete, update
function fnButtonSubmitAjax(requestUrl, tableId, dataParam, dlgId, msgDisplayID){
	$.ajax({url: requestUrl,  method: "post",data: dataParam})
	 .done( function (req){
		if (req.retcode == 1) {
			if(dlgId != null)	$(dlgId).modal('hide');	
			showMessageSuccess("success", SUCCESS_MSG, req.retmsg);
			//promptMessage("success", SUCCESS_MSG, req.retmsg);
			if(tableId != null) $(tableId).bootstrapTable('refresh');
			
        } else {
        	//promptMessage("danger", FAIL_MSG, req.retmsg, msgDisplayID);
        	showMessageFail("danger", FAIL_MSG, req.retmsg, msgDisplayID);
		}
	})
	.fail(function(req){
		if(dlgId != null)	$(dlgId).modal('hide');	
		promptMessage("danger",FAIL_MSG,'网络连接问题，请联系管理员: reqajax');
	});
}

function getCityList(id){
	 $.ajax({url:"sys/getcities?id="+id, method:"get"})
	 .done(function(data){
	 	$("#equipment_city_id").empty(); 
  			$("#equipment_city_id").append("<option value='all'>全部</option>");
  			if(data.length == 0){
  				alert("该省份未查询到城市信息，请核对后载查询!");
  				return false;
  			}
  			//document.getElementById("equipment_city_id").disabled = false;
	            for(var i=0;i<data.length;i++) 
	            	$("#equipment_city_id").append("<option value='"+data[i].areaid+"'>"+data[i].areaname+"</option>");
	 })
	 .fail(function(data){
	 })
	 .complete(function(){ console.log("loading cities is over.");});
}